import tkinter,os,types,importlib
from tkinter.constants import *
from tkinter import ttk

import const_func
importlib.reload(const_func)





window_stack = []

def on_close(main_win, second_window : tkinter.Frame, button1 : tkinter.Frame) :
    window_stack.remove(second_window)
    second_window.destroy()
    window_stack[-1].pack()
    main_win.focus_input = window_stack[-1].input1
    if len(window_stack) == 2 : pass
    for i in button1.winfo_children() :
        if isinstance(i,tkinter.Button) : i.config(text=button1.rawtext_conpoment["annotation"])

def add_topic(on_toplevel_open : types.FunctionType) :
    second_window = tkinter.Frame(window_stack[0])
    on_toplevel_open(second_window)
    window_stack[-1].pack_forget()
    window_stack.append(second_window)
    second_window.pack()

def save_button_text(button1 , input2 : tkinter.Text) : 
    button1.rawtext_conpoment['json_list'] = const_func.Text_get_content(input2)



def add_score_button(main_win , msg=None) :
    if not isinstance(main_win.focus_input,tkinter.Text) : return None
    if not hasattr(main_win.focus_input,"rawtext_sign") : return None
    frame1 = tkinter.Frame(main_win.focus_input)
    left1 = tkinter.Label(frame1,text=" ",fg='black',font=('Arial',10),width=1,height=1)
    left1.bind("<Button-1>",lambda a : see_TEXT_index(main_win,frame1,0))
    left1.pack(side=LEFT)
    button1 = tkinter.Button(frame1, text="scores", font=('Arial',9))
    button1.config(command=lambda : spawn_score_ui(frame1,main_win))
    button1.pack(side=LEFT)
    frame1.rawtext_conpoment = msg if msg else {"annotation" : "scores" , "type" : "score" , "scoreboard" : "" , "name" : ""}
    button1.config(text=frame1.rawtext_conpoment["annotation"])
    right1 = tkinter.Label(frame1,text=" ",fg='black',font=('Arial',10),width=1,height=1)
    right1.bind("<Button-1>",lambda a : see_TEXT_index(main_win,frame1,1))
    right1.pack(side=LEFT)
    main_win.focus_input.window_create(INSERT, window=frame1)

def spawn_score_ui(button1: tkinter.Frame, main_win) : 
    def set_subwin(second_window : tkinter.Frame) :
        tkinter.Label(second_window,text="注释",fg='black',font=('Arial',12),width=20,height=1).pack()
        input0 = tkinter.Entry(second_window,font=('Arial',12),justify='center',width=20)
        input0.insert(END,button1.rawtext_conpoment['annotation'])
        input0.pack()

        tkinter.Label(second_window,text="",fg='black',font=('Arial',6),width=15,height=1).pack()
        tkinter.Label(second_window,text="计分板名称",fg='black',font=('Arial',12),width=20,height=1).pack()
        input1 = tkinter.Entry(second_window,font=('Arial',12),justify='center',width=20)
        input1.bind("<FocusIn>",lambda a : main_win.set_focus_input(a,input1)) 
        input1.insert(END,button1.rawtext_conpoment['scoreboard'])
        main_win.set_focus_input(1,input1)
        input1.pack()

        tkinter.Label(second_window,text="",fg='black',font=('Arial',6),width=15,height=1).pack()
        tkinter.Label(second_window,text="假名或目标选择器",fg='black',font=('Arial',12),width=20,height=1).pack()
        input2 = tkinter.Entry(second_window,font=('Arial',12),justify='center',width=20)
        input2.bind("<FocusIn>",lambda a : main_win.set_focus_input(a,input2)) 
        input2.insert(END,button1.rawtext_conpoment['name'])
        input2.pack()

        def update0() : button1.rawtext_conpoment['annotation'] = input0.get()
        def update1() : button1.rawtext_conpoment['scoreboard'] = input1.get()
        def update2() : button1.rawtext_conpoment['name'] = input2.get()
        tkinter.Label(second_window,text="",fg='black',font=('Arial',10),width=15,height=1).pack()
        tkinter.Button(second_window,text='确    定',font=('Arial',10),bg='aquamarine',width=9,height=1,
                       command=lambda : [update0(),update1(),update2(),on_close(main_win,second_window,button1)]).pack()
        
        second_window.input1 = input1
        main_win.focus_input = input1
        
    add_topic(set_subwin)
    


def add_selector_button(main_win,msg=None) :
    if not isinstance(main_win.focus_input,tkinter.Text) : return None
    if not hasattr(main_win.focus_input,"rawtext_sign") : return None
    frame1 = tkinter.Frame(main_win.focus_input)
    left1 = tkinter.Label(frame1,text=" ",fg='black',font=('Arial',10),width=1,height=1)
    left1.bind("<Button-1>",lambda a : see_TEXT_index(main_win,frame1,0))
    left1.pack(side=LEFT)
    button1 = tkinter.Button(frame1, text="selector", font=('Arial',9))
    button1.config(command=lambda : spawn_selector_ui(frame1,main_win))
    button1.pack(side=LEFT)
    frame1.rawtext_conpoment = msg if msg else {"annotation" : "selector" , "type" : "selector" , "name" : ""}
    button1.config(text=frame1.rawtext_conpoment["annotation"])
    right1 = tkinter.Label(frame1,text=" ",fg='black',font=('Arial',10),width=1,height=1)
    right1.bind("<Button-1>",lambda a : see_TEXT_index(main_win,frame1,1))
    right1.pack(side=LEFT)
    main_win.focus_input.window_create(INSERT, window=frame1)

def spawn_selector_ui(button1 : tkinter.Frame, main_win) : 
    def set_subwin(second_window : tkinter.Frame) :
        tkinter.Label(second_window,text="注释",fg='black',font=('Arial',12),width=20,height=1).pack()
        input0 = tkinter.Entry(second_window,font=('Arial',12),justify='center',width=20)
        input0.insert(END,button1.rawtext_conpoment['annotation'])
        input0.pack()
        
        tkinter.Label(second_window,text="",fg='black',font=('Arial',20),width=15,height=1).pack()
        tkinter.Label(second_window,text="目标选择器或玩家名",fg='black',font=('Arial',12),width=20,height=1).pack()
        input1 = tkinter.Entry(second_window,font=('Arial',12),justify='center',width=22)
        input1.bind("<FocusIn>",lambda a : main_win.set_focus_input(a,input1)) 
        input1.insert(END,button1.rawtext_conpoment['name'])
        input1.pack()

        def update0() : button1.rawtext_conpoment['annotation'] = input0.get()
        def update1() : button1.rawtext_conpoment['name'] = input1.get()
        tkinter.Label(second_window,text="",fg='black',font=('Arial',10),width=15,height=1).pack()
        tkinter.Button(second_window,text='确    定',font=('Arial',10),bg='aquamarine',width=9,height=1,
                       command=lambda : [update0(),update1(),on_close(main_win,second_window,button1)]).pack()
        
        second_window.input1 = input1
        main_win.focus_input = input1

    add_topic(set_subwin)



def add_translate_button(main_win , msg = None) :
    if not isinstance(main_win.focus_input,tkinter.Text) : return None
    if not hasattr(main_win.focus_input,"rawtext_sign") : return None
    frame1 = tkinter.Frame(main_win.focus_input)
    left1 = tkinter.Label(frame1,text=" ",fg='black',font=('Arial',10),width=1,height=1)
    left1.bind("<Button-1>",lambda a : see_TEXT_index(main_win,frame1,0))
    left1.pack(side=LEFT)

    button1 = tkinter.Button(frame1, text="translate", font=('Arial',9))
    button1.config(command=lambda : spawn_translate_ui(frame1,main_win))
    frame1.rawtext_conpoment = msg if msg else {"annotation" : "translate" , "type" : "translate" , "text":"" , "json_list": []}
    button1.config(text=frame1.rawtext_conpoment["annotation"])
    button1.pack(side=LEFT)
    right1 = tkinter.Label(frame1,text=" ",fg='black',font=('Arial',10),width=1,height=1)
    right1.bind("<Button-1>",lambda a : see_TEXT_index(main_win,frame1,1))
    right1.pack(side=LEFT)
    main_win.focus_input.window_create(INSERT, window=frame1)

def spawn_translate_ui(button1 : tkinter.Frame, main_win) : 
    def set_subwin(second_window : tkinter.Frame) :
        tkinter.Label(second_window,text="注释",fg='black',font=('Arial',12),width=20,height=1).pack()
        input0 = tkinter.Entry(second_window,font=('Arial',12),justify='center',width=20)
        input0.insert(END,button1.rawtext_conpoment['annotation'])
        input0.pack()
        
        tkinter.Label(second_window,text="",fg='black',font=('Arial',1),width=15,height=1).pack()
        tkinter.Label(second_window,text="基本内容",fg='black',font=('Arial',12),width=20,height=1).pack()
        frame_m10 = tkinter.Frame(second_window)
        sco1 = tkinter.Scrollbar(frame_m10,orient='vertical')
        input1 = tkinter.Text(frame_m10,font=('Arial',12),width=20,height=7,yscrollcommand=sco1.set)
        input1.bind("<FocusIn>",lambda a : main_win.set_focus_input(a,input1)) 
        input1.insert(END,button1.rawtext_conpoment['text'])
        sco1.config(command=input1.yview)
        input1.grid() ; sco1.grid(row=0,column=1,sticky=tkinter.N+tkinter.S)
        frame_m10.pack()
        
        tkinter.Label(second_window,text="",fg='black',font=('Arial',1),width=15,height=1).pack()
        tkinter.Label(second_window,text="附加with(一行一个元素)",fg='black',font=('Arial',12),width=20,height=1).pack()
        frame_m10 = tkinter.Frame(second_window)
        sco1 = tkinter.Scrollbar(frame_m10,orient='vertical')
        input2 = tkinter.Text(frame_m10,font=('Arial',12),width=20,height=7,yscrollcommand=sco1.set)
        main_win.set_focus_input(1,input2) ; input2.rawtext_sign = ''
        input2.bind("<FocusIn>",lambda a : main_win.set_focus_input(a,input2))
        const_func.content_to_component(main_win,button1.rawtext_conpoment['json_list'])
        sco1.config(command=input2.yview)
        input2.grid() ; sco1.grid(row=0,column=1,sticky=tkinter.N+tkinter.S)
        frame_m10.pack()

        def update0() : button1.rawtext_conpoment['annotation'] = input0.get()
        def update1() : button1.rawtext_conpoment['text'] = input1.get("0.0",END)[:-1]
        tkinter.Label(second_window,text="",fg='black',font=('Arial',6),width=15,height=1).pack()
        tkinter.Button(second_window,text='确    定',font=('Arial',10),bg='aquamarine',width=9,height=1,
                       command=lambda : [update0(),update1(),save_button_text(button1 , input2),
                                         on_close(main_win,second_window,button1)]).pack(side="bottom")
        
        second_window.input1 = input1
        main_win.focus_input = input1

    add_topic(set_subwin)


def batch_add_button(main_win) :
    def add(second_window : tkinter.Toplevel) :
        second_window.title('setting')
        focus_comp = main_win.focus_input

        tkinter.Label(second_window,text="",fg='black',font=('Arial',3),width=15,height=1).pack()
        frame_m11 = tkinter.Frame(second_window)
        tkinter.Label(frame_m11,text="按钮类型",bg="#b0b0b0",fg='black',font=('Arial',12),width=10,height=1).pack(side=LEFT)
        input0 = ttk.Combobox(frame_m11, font=('Arial',13), width=6, state='readonly', justify='center')
        input0["value"] = ("分数", "实体", "翻译")
        input0.current(0)
        input0.pack(side=LEFT) ; frame_m11.pack()

        tkinter.Label(second_window,text="",fg='black',font=('Arial',3),width=15,height=1).pack()
        frame_m11 = tkinter.Frame(second_window)
        tkinter.Label(frame_m11,text="按钮数量",bg="#b0b0b0",fg='black',font=('Arial',12),width=10,height=1).pack(side=LEFT)
        input1 = tkinter.Entry(frame_m11,font=('Arial',12),justify='center',width=11)
        input1.bind("<FocusIn>",lambda a : main_win.set_focus_input(a,input1)) 
        input1.insert(END,"5")
        input1.pack(side=LEFT) ; frame_m11.pack()

        tkinter.Label(second_window,text="",fg='black',font=('Arial',3),width=15,height=1).pack()
        tkinter.Label(second_window,text="按钮间分隔字符",bg="#b0b0b0",fg='black',font=('Arial',12),width=16,height=1).pack()
        input2 = tkinter.Text(second_window,font=('Arial',12),width=20,height=2)
        input2.bind("<FocusIn>",lambda a : main_win.set_focus_input(a,input2))
        input2.pack()
        
        def update0() : 
            main_win.focus_input = focus_comp
            try : 
                if int(input1.get()) < 1 : raise Exception
            except : 
                aaa.config(text="按钮数量应为正整数",fg="red")
            else :
                times = int(input1.get())
                for i in range(times) :
                    if input0.current() == 0 : add_score_button(main_win)
                    elif input0.current() == 1 : add_selector_button(main_win)
                    elif input0.current() == 2 : add_translate_button(main_win)
                    if (i < (times - 1)) : main_win.focus_input.insert(INSERT,input2.get("0.0",END)[:-1])
                second_window.destroy()
        tkinter.Label(second_window,text="",fg='black',font=('Arial',3),width=15,height=1).pack()
        aaa = tkinter.Label(second_window,text="按下确认按钮生成",fg='black',font=('Arial',12),width=20,height=1)
        aaa.pack()
        tkinter.Label(second_window,text="",fg='black',font=('Arial',3),width=15,height=1).pack()
        tkinter.Button(second_window,text='确    定',font=('Arial',10),bg='aquamarine',width=9,height=1,
                       command=lambda : update0()).pack(side="bottom")

    main_win.add_topic(add)



def see_TEXT_index(main_win, frame1:tkinter.Frame, add_value:int) :
    if not isinstance(main_win.focus_input,tkinter.Text) : return None
    if not hasattr(main_win.focus_input,"rawtext_sign") : return None
    button_content = main_win.focus_input.dump("0.0", END, window=True)
    button_content_text = [i[1] for i in button_content]
    if str(frame1) not in button_content_text : return None
    index1 = button_content_text.index(str(frame1))
    list1 = button_content[index1][2].split(".")
    list1[1] = str(int(list1[1]) + add_value)
    main_win.focus_input.focus_set()
    main_win.focus_input.mark_set(INSERT,".".join(list1))












"""
def add_all_display_menu_button(main_win , msg = None) :
    if not isinstance(main_win.focus_input,tkinter.Text) : return None
    if not hasattr(main_win.focus_input,"rawtext_sign") : return None
    button1 = tkinter.Button(main_win.focus_input, text="translate", font=('Arial',9))
    button1.config(command=lambda : spawn_all_display_menu_ui(button1,main_win))
    button1.rawtext_conpoment = msg if msg else {"annotation" : "All Menu" , "type" : "all_display_menu" , "scoreboard" : "" , "select_color" : "" ,
                                                  "unselect_color" : "" ,"roll_or_column":0 , "json_list": []}
    button1.config(text=button1.rawtext_conpoment["annotation"])
    main_win.focus_input.window_create(INSERT, window=button1)

def spawn_all_display_menu_ui(button1 : tkinter.Button, main_win) : 
    def set_subwin(second_window : tkinter.Frame) :
        tkinter.Label(second_window,text="注释",fg='black',font=('Arial',12),width=20,height=1).pack()
        input0 = tkinter.Entry(second_window,font=('Arial',12),justify='center',width=20)
        input0.insert(END,button1.rawtext_conpoment['annotation'])
        input0.pack()
        
        tkinter.Label(second_window,text="",fg='black',font=('Arial',1),width=15,height=1).pack()
        tkinter.Label(second_window,text="计分板名称",fg='black',font=('Arial',12),width=20,height=1).pack()
        input1 = tkinter.Entry(second_window,font=('Arial',12),justify='center',width=20)
        input1.bind("<FocusIn>",lambda a : main_win.set_focus_input(a,input1))
        input1.insert(END,button1.rawtext_conpoment['scoreboard'])
        input1.pack() 
        
        tkinter.Label(second_window,text="",fg='black',font=('Arial',1),width=15,height=1).pack()
        frame_m11 = tkinter.Frame(second_window)
        frame_m12 = tkinter.Frame(frame_m11)
        tkinter.Label(frame_m12,text="选中颜色",fg='black',font=('Arial',12),width=11,height=1).pack()
        input2 = tkinter.Entry(frame_m12,font=('Arial',12),justify='center',width=11)
        input2.bind("<FocusIn>",lambda a : main_win.set_focus_input(a,input2)) 
        input2.insert(END,button1.rawtext_conpoment['select_color'])
        input2.pack() ; frame_m12.pack(side=LEFT)
        
        frame_m13 = tkinter.Frame(frame_m11)
        tkinter.Label(frame_m13,text="未选中颜色",fg='black',font=('Arial',12),width=11,height=1).pack()
        input3 = tkinter.Entry(frame_m13,font=('Arial',12),justify='center',width=11)
        input3.bind("<FocusIn>",lambda a : main_win.set_focus_input(a,input3)) 
        input3.insert(END,button1.rawtext_conpoment['unselect_color'])
        input3.pack() ; frame_m13.pack(side=LEFT)
        frame_m11.pack()

        tkinter.Label(second_window,text="",fg='black',font=('Arial',3),width=15,height=1).pack()
        frame_m11 = tkinter.Frame(second_window)
        tkinter.Label(frame_m11,text="横竖类型",bg="#b0b0b0",fg='black',font=('Arial',12),width=10,height=1).pack(side=LEFT)    
        input4 = ttk.Combobox(frame_m11, font=('Arial',13), width=6, state='readonly', justify='center')
        input4["value"] = ("竖向", "横向")
        input4.current(button1.rawtext_conpoment['roll_or_column'])
        input4.pack(side=LEFT) ; frame_m11.pack()
        
        tkinter.Label(second_window,text="",fg='black',font=('Arial',3),width=15,height=1).pack()
        tkinter.Label(second_window,text="一行一个菜单元素",fg='black',font=('Arial',12),width=20,height=1).pack()
        frame_m10 = tkinter.Frame(second_window)
        sco1 = tkinter.Scrollbar(frame_m10,orient='vertical')
        input5 = tkinter.Text(frame_m10,font=('Arial',12),width=20,height=8,yscrollcommand=sco1.set)
        main_win.set_focus_input(1,input5) ; input5.rawtext_sign = ''
        input5.bind("<FocusIn>",lambda a : main_win.set_focus_input(a,input5))
        const_func.content_to_component_with_lines(main_win,button1.rawtext_conpoment['json_list'])
        sco1.config(command=input5.yview)
        input5.grid() ; sco1.grid(row=0,column=1,sticky=tkinter.N+tkinter.S)
        frame_m10.pack()

        def update0() : 
            button1.rawtext_conpoment['annotation'] = input0.get()
            button1.rawtext_conpoment['scoreboard'] = input1.get()
            button1.rawtext_conpoment['select_color'] = input2.get()
            button1.rawtext_conpoment['unselect_color'] = input3.get()
            button1.rawtext_conpoment['roll_or_column'] = input4.current()
        tkinter.Label(second_window,text="",fg='black',font=('Arial',6),width=15,height=1).pack()
        tkinter.Button(second_window,text='确    定',font=('Arial',10),bg='aquamarine',width=9,height=1,
                       command=lambda : [update0(),save_button_text(button1 , input5),
                                         on_close(main_win,second_window,button1)]).pack(side="bottom")
        
        second_window.input1 = input1
        main_win.focus_input = input1

    add_topic(set_subwin)



def add_roll_display_menu_button(main_win , msg = None) :
    if not isinstance(main_win.focus_input,tkinter.Text) : return None
    if not hasattr(main_win.focus_input,"rawtext_sign") : return None
    button1 = tkinter.Button(main_win.focus_input, text="translate", font=('Arial',9))
    button1.config(command=lambda : spawn_roll_display_menu_ui(button1,main_win))
    button1.rawtext_conpoment = msg if msg else {"annotation" : "Roll Menu" , "type" : "roll_display_menu" , "scoreboard" : "" , "select_color" : "" ,
                                                  "unselect_color" : "" ,"roll_or_column":0 , "json_list": []}
    button1.config(text=button1.rawtext_conpoment["annotation"])
    main_win.focus_input.window_create(INSERT, window=button1)

def spawn_roll_display_menu_ui(button1 : tkinter.Button, main_win) : 
    def set_subwin(second_window : tkinter.Frame) :
        tkinter.Label(second_window,text="注释",fg='black',font=('Arial',12),width=20,height=1).pack()
        input0 = tkinter.Entry(second_window,font=('Arial',12),justify='center',width=20)
        input0.insert(END,button1.rawtext_conpoment['annotation'])
        input0.pack()
        
        tkinter.Label(second_window,text="",fg='black',font=('Arial',1),width=15,height=1).pack()
        tkinter.Label(second_window,text="计分板名称",fg='black',font=('Arial',12),width=20,height=1).pack()
        input1 = tkinter.Entry(second_window,font=('Arial',12),justify='center',width=20)
        input1.bind("<FocusIn>",lambda a : main_win.set_focus_input(a,input1))
        input1.insert(END,button1.rawtext_conpoment['scoreboard'])
        input1.pack() 
        
        tkinter.Label(second_window,text="",fg='black',font=('Arial',1),width=15,height=1).pack()
        frame_m11 = tkinter.Frame(second_window)
        frame_m12 = tkinter.Frame(frame_m11)
        tkinter.Label(frame_m12,text="选中颜色",fg='black',font=('Arial',12),width=11,height=1).pack()
        input2 = tkinter.Entry(frame_m12,font=('Arial',12),justify='center',width=11)
        input2.bind("<FocusIn>",lambda a : main_win.set_focus_input(a,input2)) 
        input2.insert(END,button1.rawtext_conpoment['select_color'])
        input2.pack() ; frame_m12.pack(side=LEFT)
        
        frame_m13 = tkinter.Frame(frame_m11)
        tkinter.Label(frame_m13,text="未选中颜色",fg='black',font=('Arial',12),width=11,height=1).pack()
        input3 = tkinter.Entry(frame_m13,font=('Arial',12),justify='center',width=11)
        input3.bind("<FocusIn>",lambda a : main_win.set_focus_input(a,input3)) 
        input3.insert(END,button1.rawtext_conpoment['unselect_color'])
        input3.pack() ; frame_m13.pack(side=LEFT)
        frame_m11.pack()

        tkinter.Label(second_window,text="",fg='black',font=('Arial',3),width=15,height=1).pack()
        frame_m11 = tkinter.Frame(second_window)
        tkinter.Label(frame_m11,text="横竖类型",bg="#b0b0b0",fg='black',font=('Arial',12),width=10,height=1).pack(side=LEFT)    
        input4 = ttk.Combobox(frame_m11, font=('Arial',13), width=6, state='readonly', justify='center')
        input4["value"] = ("竖向", "横向")
        input4.current(button1.rawtext_conpoment['roll_or_column'])
        input4.pack(side=LEFT) ; frame_m11.pack()
        
        tkinter.Label(second_window,text="",fg='black',font=('Arial',3),width=15,height=1).pack()
        tkinter.Label(second_window,text="一行一个菜单元素",fg='black',font=('Arial',12),width=20,height=1).pack()
        frame_m10 = tkinter.Frame(second_window)
        sco1 = tkinter.Scrollbar(frame_m10,orient='vertical')
        input5 = tkinter.Text(frame_m10,font=('Arial',12),width=20,height=8,yscrollcommand=sco1.set)
        main_win.set_focus_input(1,input5) ; input5.rawtext_sign = ''
        input5.bind("<FocusIn>",lambda a : main_win.set_focus_input(a,input5))
        const_func.content_to_component_with_lines(main_win,button1.rawtext_conpoment['json_list'])
        sco1.config(command=input5.yview)
        input5.grid() ; sco1.grid(row=0,column=1,sticky=tkinter.N+tkinter.S)
        frame_m10.pack()

        def update0() : 
            button1.rawtext_conpoment['annotation'] = input0.get()
            button1.rawtext_conpoment['scoreboard'] = input1.get()
            button1.rawtext_conpoment['select_color'] = input2.get()
            button1.rawtext_conpoment['unselect_color'] = input3.get()
            button1.rawtext_conpoment['roll_or_column'] = input4.current()
        tkinter.Label(second_window,text="",fg='black',font=('Arial',6),width=15,height=1).pack()
        tkinter.Button(second_window,text='确    定',font=('Arial',10),bg='aquamarine',width=9,height=1,
                       command=lambda : [update0(),save_button_text(button1 , input5),
                                         on_close(main_win,second_window,button1)]).pack(side="bottom")
        
        second_window.input1 = input1
        main_win.focus_input = input1

    add_topic(set_subwin)



def add_roll_column_display_menu_button(main_win , msg = None) :
    if not isinstance(main_win.focus_input,tkinter.Text) : return None
    if not hasattr(main_win.focus_input,"rawtext_sign") : return None
    button1 = tkinter.Button(main_win.focus_input, text="translate", font=('Arial',9))
    button1.config(command=lambda : spawn_roll_column_display_menu_ui(button1,main_win))
    button1.rawtext_conpoment = msg if msg else {"annotation" : "ColumnMenu" , "type" : "roll_column_display_menu" , "scoreboard" : "" , "select_color" : "" ,
                                                  "unselect_color" : "" ,"column":"1" , "json_list": []}
    button1.config(text=button1.rawtext_conpoment["annotation"])
    main_win.focus_input.window_create(INSERT, window=button1)

def spawn_roll_column_display_menu_ui(button1 : tkinter.Button, main_win) : 
    def set_subwin(second_window : tkinter.Frame) :
        tkinter.Label(second_window,text="注释",fg='black',font=('Arial',12),width=20,height=1).pack()
        input0 = tkinter.Entry(second_window,font=('Arial',12),justify='center',width=20)
        input0.insert(END,button1.rawtext_conpoment['annotation'])
        input0.pack()
        
        tkinter.Label(second_window,text="",fg='black',font=('Arial',1),width=15,height=1).pack()
        tkinter.Label(second_window,text="计分板名称",fg='black',font=('Arial',12),width=20,height=1).pack()
        input1 = tkinter.Entry(second_window,font=('Arial',12),justify='center',width=20)
        input1.bind("<FocusIn>",lambda a : main_win.set_focus_input(a,input1))
        input1.insert(END,button1.rawtext_conpoment['scoreboard'])
        input1.pack() 
        
        tkinter.Label(second_window,text="",fg='black',font=('Arial',1),width=15,height=1).pack()
        frame_m11 = tkinter.Frame(second_window)
        frame_m12 = tkinter.Frame(frame_m11)
        tkinter.Label(frame_m12,text="选中颜色",fg='black',font=('Arial',12),width=11,height=1).pack()
        input2 = tkinter.Entry(frame_m12,font=('Arial',12),justify='center',width=11)
        input2.bind("<FocusIn>",lambda a : main_win.set_focus_input(a,input2)) 
        input2.insert(END,button1.rawtext_conpoment['select_color'])
        input2.pack() ; frame_m12.pack(side=LEFT)
        
        frame_m13 = tkinter.Frame(frame_m11)
        tkinter.Label(frame_m13,text="未选中颜色",fg='black',font=('Arial',12),width=11,height=1).pack()
        input3 = tkinter.Entry(frame_m13,font=('Arial',12),justify='center',width=11)
        input3.bind("<FocusIn>",lambda a : main_win.set_focus_input(a,input3)) 
        input3.insert(END,button1.rawtext_conpoment['unselect_color'])
        input3.pack() ; frame_m13.pack(side=LEFT)
        frame_m11.pack()

        tkinter.Label(second_window,text="",fg='black',font=('Arial',3),width=15,height=1).pack()
        frame_m11 = tkinter.Frame(second_window)
        tkinter.Label(frame_m11,text="菜单列数",bg="#b0b0b0",fg='black',font=('Arial',12),width=10,height=1).pack(side=LEFT)
        input4 = tkinter.Entry(frame_m11,font=('Arial',12),justify='center',width=11)
        input4.bind("<FocusIn>",lambda a : main_win.set_focus_input(a,input4)) 
        input4.insert(END,button1.rawtext_conpoment['column'])
        input4.pack(side=LEFT) ; frame_m11.pack()
        
        tkinter.Label(second_window,text="",fg='black',font=('Arial',3),width=15,height=1).pack()
        tkinter.Label(second_window,text="一行一个菜单元素",fg='black',font=('Arial',12),width=20,height=1).pack()
        frame_m10 = tkinter.Frame(second_window)
        sco1 = tkinter.Scrollbar(frame_m10,orient='vertical')
        input5 = tkinter.Text(frame_m10,font=('Arial',12),width=20,height=8,yscrollcommand=sco1.set)
        main_win.set_focus_input(1,input5) ; input5.rawtext_sign = ''
        input5.bind("<FocusIn>",lambda a : main_win.set_focus_input(a,input5))
        const_func.content_to_component_with_lines(main_win,button1.rawtext_conpoment['json_list'])
        sco1.config(command=input5.yview)
        input5.grid() ; sco1.grid(row=0,column=1,sticky=tkinter.N+tkinter.S)
        frame_m10.pack()

        def update0() : 
            button1.rawtext_conpoment['annotation'] = input0.get()
            button1.rawtext_conpoment['scoreboard'] = input1.get()
            button1.rawtext_conpoment['select_color'] = input2.get()
            button1.rawtext_conpoment['unselect_color'] = input3.get()
            button1.rawtext_conpoment['column'] = input4.get()
        tkinter.Label(second_window,text="",fg='black',font=('Arial',6),width=15,height=1).pack()
        tkinter.Button(second_window,text='确    定',font=('Arial',10),bg='aquamarine',width=9,height=1,
                       command=lambda : [update0(),save_button_text(button1 , input5),
                                         on_close(main_win,second_window,button1)]).pack(side="bottom")
        
        second_window.input1 = input1
        main_win.focus_input = input1

    add_topic(set_subwin)
"""