import tkinter,importlib,re
from tkinter.constants import *
import const_obj
importlib.reload(const_obj)


def clone_widget(widget, master=None):
        """
        Create a cloned version o a widget

        Parameters
        ----------
        widget : tkinter widget
            tkinter widget that shall be cloned.
        master : tkinter widget, optional
            Master widget onto which cloned widget shall be placed. If None, same master of input widget will be used. The
            default is None.

        Returns
        -------
        cloned : tkinter widget
            Clone of input widget onto master widget.

        """
        # Get main info
        parent = master if master else widget.master
        cls = widget.__class__

        # Clone the widget configuration
        cfg = {key: widget.cget(key) for key in widget.configure()}
        cloned = cls(parent, **cfg)

        # Clone the widget's children
        for child in widget.winfo_children():
            child_cloned = clone_widget(child, master=cloned)
            if child.grid_info():
                grid_info = {k: v for k, v in child.grid_info().items() if k not in {'in'}}
                child_cloned.grid(**grid_info)
            elif child.place_info():
                place_info = {k: v for k, v in child.place_info().items() if k not in {'in'}}
                child_cloned.place(**place_info)
            else:
                pack_info = {k: v for k, v in child.pack_info().items() if k not in {'in'}}
                child_cloned.pack(**pack_info)

        return cloned
    


def Text_get_content(text_obj : tkinter.Text) : 
    button_list = text_obj.winfo_children() ; button_content = text_obj.dump("0.0", END, window=True)
    start = "1.0" ; result_list = []
    button_list_text = [str(i) for i in button_list]
    button_list = [button_list[button_list_text.index(i[1])] for i in button_content]

    for i in range(len(button_content)) :
        get_text = text_obj.get(start,button_content[i][2])
        if get_text != "" : result_list.append(get_text)
        result_list.append(button_list[i].rawtext_conpoment)
        start = button_content[i][2]
    get_text = text_obj.get(start,END)[:-1]
    if get_text != "" : result_list.append(get_text)

    return result_list



def content_to_component(main_win , content_list : list) : 
    if not(isinstance(main_win.focus_input,tkinter.Text) and hasattr(main_win.focus_input,'rawtext_sign')) : return None
    main_win.focus_input.delete("0.0",END)
    for i in content_list :
        if isinstance(i,type("")) : main_win.focus_input.insert(END,i)
        elif isinstance(i,type({})) and i['type'] == "score" : const_obj.add_score_button(main_win,i)
        elif isinstance(i,type({})) and i['type'] == "selector" : const_obj.add_selector_button(main_win,i)
        elif isinstance(i,type({})) and i['type'] == "translate" : const_obj.add_translate_button(main_win,i)
        """
        elif isinstance(i,type({})) and i['type'] == "all_display_menu" : const_obj.add_all_display_menu_button(main_win,i)
        elif isinstance(i,type({})) and i['type'] == "roll_display_menu" : const_obj.add_roll_display_menu_button(main_win,i)
        elif isinstance(i,type({})) and i['type'] == "roll_column_display_menu" : const_obj.add_roll_column_display_menu_button(main_win,i)
        """



def find_return_str(str1 : str) -> list :
    l = list(re.finditer("[\\\\]+n",str1))
    l.reverse()
    return l



def replace_str(base : str,start : int,end : int,replace : str) -> str:
    return "".join([ base[:start] , replace , base[end:] ])



def change_to_text(rawtext_comp : str) :
    return {"text" : rawtext_comp}

def change_to_score(rawtext_comp : dict) :
    return {"score" : {"name": rawtext_comp['name'], "objective": rawtext_comp['scoreboard']}}

def change_to_selector(rawtext_comp : dict) :
    return {"selector" : rawtext_comp['name']}

def change_to_translate(rawtext_comp : dict) :
    return {"translate" : rawtext_comp['text'], "with" : translate_result(rawtext_comp['json_list'])}
    
def translate_result(rawtext_list : list) -> dict:
    base_json = {"rawtext":[]} ; base_translate = {"translate" : "", "with" : {"rawtext":[]}}

    lines_all = [] ; lines_comp = []
    for rawtext_comp in rawtext_list :
        if type(rawtext_comp) == type("") : 
            split_text = rawtext_comp.split("\n")
            for i in range(len(split_text)) :
                if (i+1) == len(split_text) : 
                    list_1 = find_return_str(split_text[i])
                    for iter1 in list_1 :
                        count1 = iter1.group().count("\\")
                        if count1 == 1 : lines_comp.append(replace_str(split_text[i] , iter1.start() , iter1.end() , "\n"))
                        elif count1 > 1 : lines_comp.append(replace_str(split_text[i] , iter1.start() , iter1.end() , "\\" * (count1 - 1) + "n"))
                    if len(list_1) == 0 : lines_comp.append(split_text[i])
                else : 
                    list_1 = find_return_str(split_text[i])
                    for iter1 in find_return_str(split_text[i]) :
                        count1 = iter1.group().count("\\")
                        if count1 == 1 : lines_comp.append(replace_str(split_text[i] , iter1.start() , iter1.end() , "\n"))
                        elif count1 > 1 : lines_comp.append(replace_str(split_text[i] , iter1.start() , iter1.end() , "\\" * (count1 - 1) + "n"))
                    if len(list_1) == 0 : lines_comp.append(split_text[i])
                    lines_all.append(lines_comp)
                    lines_comp = []
        else : lines_comp.append(rawtext_comp)
    lines_all.append(lines_comp)

    for lines in lines_all :
        while ("" in lines) : lines.remove("")
        for rawtext_comp in lines :
            if len(lines) == 1 :
                if type(rawtext_comp) == type("") : base_json['rawtext'].append(change_to_text(rawtext_comp))
                if type(rawtext_comp) == type({}) and rawtext_comp['type'] == 'score' : 
                    base_json['rawtext'].append(change_to_score(rawtext_comp))
                if type(rawtext_comp) == type({}) and rawtext_comp['type'] == 'selector' : 
                    base_json['rawtext'].append(change_to_selector(rawtext_comp))
                if type(rawtext_comp) == type({}) and rawtext_comp['type'] == 'translate' : 
                    base_json['rawtext'].append(change_to_translate(rawtext_comp))
            else :
                if type(rawtext_comp) == type("") : base_translate['translate'] += rawtext_comp
                if type(rawtext_comp) == type({}) and rawtext_comp['type'] == 'score' : 
                    base_translate['translate'] += '%%s'
                    m1 = {"translate" : "%%s", "with" : {"rawtext":[{"text":""}]}}
                    m1['with']['rawtext'].insert(0,change_to_score(rawtext_comp))
                    base_translate['with']['rawtext'].append(m1)
                if type(rawtext_comp) == type({}) and rawtext_comp['type'] == 'selector' : 
                    base_translate['translate'] += '%%s'
                    m1 = {"translate" : "%%s", "with" : {"rawtext":[{"text":""}]}}
                    m1['with']['rawtext'].insert(0,change_to_selector(rawtext_comp))
                    base_translate['with']['rawtext'].append(m1)
                if type(rawtext_comp) == type({}) and rawtext_comp['type'] == 'translate' : 
                    base_translate['translate'] += '%%s'
                    m1 = {"translate" : "%%s", "with" : {"rawtext":[{"text":""}]}}
                    m1['with']['rawtext'].insert(0,change_to_translate(rawtext_comp))
                    base_translate['with']['rawtext'].append(m1)
        if len(lines) > 1 :
            if len(lines) == 1 : base_translate['with'] = []
            base_json['rawtext'].append(base_translate)
            base_translate = {"translate" : "", "with" : {"rawtext":[]}}
    
    return base_json


"""
def test_rawtext_json_and_get_variable(rawtext_json : str) -> dict :
    try : 
        json1 = json.loads(rawtext_json)
    except : return {}
    else :
        return find_all_variable(json1)

def find_all_variable(rawtext_json : dict) -> dict :
    vars = {"scoreboard":{},"selector":{}}
    for json1 in rawtext_json['rawtext'] :
        if 'score' in json1 : 

"""




