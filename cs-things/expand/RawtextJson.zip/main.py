import tkinter,os,pickle,sys,re,random,threading,time,string,json,webbrowser,tkinter.font,importlib,traceback
sys.path.append(os.path.realpath(os.path.join(__file__, os.pardir)))
base_path = os.path.dirname(os.path.abspath(__file__))
from tkinter.constants import *
from tkinter import ttk
from types import *

import const_obj
importlib.reload(const_obj)
import const_func
importlib.reload(const_func)

os.makedirs(os.path.join(base_path,'import'),exist_ok=True)
os.makedirs(os.path.join(base_path,'export'),exist_ok=True)

main_win = None

class pack_class : 

    def __init__(self) -> None : 
        try : 
            with open(os.path.join(base_path,'rawtext_saves'), 'rb') as f: self.save_data = pickle.load(f)
        except : 
            with open(os.path.join(base_path,'rawtext_saves'), 'wb') as f: pickle.dump([], f)
            with open(os.path.join(base_path,'rawtext_saves'), 'rb') as f: self.save_data = pickle.load(f)
        self.delete_times = 0
        self.times_up = 3
        self.last_save_hash_1 = -1
        self.last_save_hash_2 = -1
        self.save_time_count = 0
        self.template_choose = None


    def set_threading(self) :
        def saves(self) :
            self.times_up = 3
            while self.times_up : 
                time.sleep(1) ; self.times_up -= 1
            self.save_file(False)
        if self.times_up == 0 : threading.Thread(target=saves,args=(self,)).start()
        else : self.times_up = 3


    def check_file(self,data_list) :
        for i in data_list :
            if type(i) not in [type({}),type('')] : raise Exception
            if type(i) == type({}) and (('type' not in i) or ('annotation' not in i) or (type(i['annotation']) != type(""))) : raise Exception
            if type(i) == type({}) and i['type'] not in ("score",'selector','translate','all_display_menu','roll_display_menu','roll_column_display_menu') : raise Exception
            if type(i) == type({}) and i['type'] == "score" and (type(i['scoreboard']) != type("") or type(i['name']) != type("")) : raise Exception
            if type(i) == type({}) and i['type'] == "selector" and (type(i['name']) != type("")) : raise Exception
            if type(i) == type({}) and i['type'] == "translate" and (type(i['text']) != type("")) : raise Exception
            if type(i) == type({}) and i['type'] in ('all_display_menu','roll_display_menu','roll_column_display_menu') :
                if (type(i['scoreboard']) != type("")) : raise Exception
                if (type(i['select_color']) != type("")) : raise Exception
                if (type(i['unselect_color']) != type("")) : raise Exception
                if i['type'] in ('all_display_menu','roll_display_menu') and (type(i['roll_or_column']) != type(0)) : raise Exception
                if i['type'] in ('roll_column_display_menu') and (type(i['column']) != type("")) : raise Exception
            if type(i) == type({}) and i['type'] in ('translate','all_display_menu','roll_display_menu','roll_column_display_menu') :
                if (type(i['json_list']) != type([])) : raise Exception
                self.check_file(i['json_list'])


    def import_file(self) : 
        f_l = list(os.walk(os.path.join(base_path,'import')))[0]
        success1,faile1 = 0,0
        for i in f_l[2] :
            try : 
                f1 = open(os.path.join(f_l[0],i),"r",encoding="utf-8")
                json1 = json.loads(f1.read())
                if ('name' not in json1) or ('text_to_json' not in json1) or (
                    type(json1['name']) != type("") or type(json1['text_to_json']) != type([])
                ) : raise Exception
                self.check_file(json1)
                self.save_data.append(json1)
                self.save_file(False)
            except : faile1 += 1 ; f1.close() ; traceback.print_exc()
            else : success1 += 1 ; f1.close() ; os.remove(os.path.join(f_l[0],i))
        self.tk_component['open_list'].delete(0,END)
        for i in self.save_data : self.tk_component['open_list'].insert(END,i['name'])
        self.debug_windows.modify_state("已导入import文件夹中的文件\n%s成功 %s失败"%(success1,faile1,),want_record=False)

    def export_file(self) : 
        if not self.get_selecting_template() : return None
        select = self.save_data[self.tk_component['open_list'].curselection()[0]]
        f1 = open(os.path.join(base_path,'export',select['name'] + ".json"),"w+",encoding="utf-8")
        f1.write(json.dumps(select))
        f1.close()
        self.debug_windows.modify_state("已导出在export文件夹导出\n模板 %s"%(select['name'],),want_record=False)


    def save_file(self,dispaly=True) :
        with open(os.path.join(base_path,'rawtext_saves'), 'wb') as f: pickle.dump(self.save_data,f)
        if dispaly : self.debug_windows.modify_state("已成功保存rawtext内容",want_record=False,want_display=True)


    def creat_new_rawtext(self) : 
        self.tk_component['open_list'].delete(0,END)
        self.save_data.append({'name': 'Json模板'+str(random.randint(0,100000)), "text_to_json": []}) 
        # str -> text ; 
        # {"annotation" : "" , "type" : "score" , "scoreboard" : "" , "name" : ""} ; 
        # {"annotation" : "" , "type" : "selector" , "name" : ""}
        # {"annotation" : "" , "type" : "translate" , "text":"" , "json_list": []} ; 
        # {"annotation" : "" , "type" : "all_display_menu" , "scoreboard" : "" , "select_color" : "" , "unselect_color" : "" ,"roll_or_column":0 , "json_list": []}
        # {"annotation" : "" , "type" : "roll_display_menu" , "scoreboard" : "" , "select_color" : "" , "unselect_color" : "" ,"roll_or_column":0 , "json_list": []}
        # {"annotation" : "" , "type" : "roll_column_display_menu" , "scoreboard" : "" , "select_color" : "" , "unselect_color" : "" ,"column":"1" , "json_list": []}
        for i in self.save_data : self.tk_component['open_list'].insert(END,i['name'])
        self.save_file()
        self.debug_windows.modify_state("已成功创建Json模板",want_record=False)

    def get_selecting_rawtext(self):
        # 获取当前选择拓展包的uuid
        select = self.tk_component['open_list'].curselection()
        if len(select) == 0 : self.debug_windows.modify_state("错误：你没有选择Json模板","error"); return False
        else : return True

    def delete_rawtext(self) :
        if not self.get_selecting_rawtext() : return None
        if self.delete_times <= 2 : 
            self.debug_windows.modify_state("第%s次确认\n是否删除该模板？"%(self.delete_times+1,),want_record=False)
            self.delete_times += 1
        else :
            del self.save_data[self.tk_component['open_list'].curselection()[0]]
            self.tk_component['open_list'].delete(0,END)
            for i in self.save_data: self.tk_component['open_list'].insert(END,i['name'])
            self.delete_times = 0 ; self.save_file()
            self.debug_windows.modify_state("已删除Json模板",want_record=False)

    def get_selecting_template(self):
        # 获取当前选择拓展包的uuid
        select = self.tk_component['open_list'].curselection()
        if len(select) == 0 :
            self.debug_windows.modify_state("错误：你没有选择模板","error")
            return False
        else : return True

    def open_rawtext(self):
        self.last_save_hash_1 = -1 ; self.last_save_hash_2 = -1
        if not self.get_selecting_template() : return None
        middle1 = self.tk_component['open_list'].curselection()[0]
        self.template_choose = middle2 = self.save_data[middle1]
        self.tk_component["Json_title"].delete("0",END)
        self.tk_component["Json_title"].insert(END,middle2["name"])
        self.tk_component["expand_input_1"].delete("0.0",END)
        self.debug_windows.focus_input = self.tk_component["expand_input_1"]
        const_func.content_to_component(self.debug_windows,middle2["text_to_json"])
        self.open_win('edit_frame')
        self.debug_windows.modify_state("已打开JSON模板\n%s"%(middle2['name'],),want_record=False)

    def open_win(self,win_id = 'main_frame') : 
        for i in self.tk_component['frame'].keys() :
            if i == win_id : self.tk_component['frame'][i].pack()
            else : self.tk_component['frame'][i].pack_forget()


    def save_title(self):
        self.template_choose["name"] = self.tk_component['Json_title'].get()
        self.set_threading()

    def save_content(self):
        self.template_choose["text_to_json"] = const_func.Text_get_content(self.tk_component['expand_input_1'])
        self.set_threading()


    def loop_method(self) :
        middle1 = const_func.Text_get_content(self.tk_component['expand_input_1'])
        if self.last_save_hash_1 != hash(str(middle1)) and self.template_choose != None :
            self.last_save_hash_1 = hash(str(middle1))
            self.tk_component['expand_output_1'].config(state=NORMAL)
            self.tk_component['expand_output_1'].delete("0.0",END)
            self.tk_component['expand_output_1'].insert(END,json.dumps(self.update_json_result(middle1),ensure_ascii=False))
            self.tk_component['expand_output_1'].see(END)
            self.tk_component['expand_output_1'].config(state=DISABLED)
        self.save_time_count += 1
        if self.save_time_count > 15 : self.save_time_count = 0
        #print(self.save_time_count)

        if self.save_time_count == 15 and self.template_choose != None and self.last_save_hash_2 != self.last_save_hash_1 : 
            self.last_save_hash_2 = self.last_save_hash_1
            self.template_choose["text_to_json"] = const_func.Text_get_content(self.tk_component['expand_input_1'])
            self.save_file(False)
            #print(23123123123123)

    def update_json_result(self,data_list) :
        base_json = {"rawtext":[]}
        for rawtext_comp in data_list :
            if type(rawtext_comp) == type("") : base_json['rawtext'].append(const_func.change_to_text(rawtext_comp))
            if type(rawtext_comp) == type({}) and rawtext_comp['type'] == 'score' : base_json['rawtext'].append(const_func.change_to_score(rawtext_comp))
            if type(rawtext_comp) == type({}) and rawtext_comp['type'] == 'selector' : base_json['rawtext'].append(const_func.change_to_selector(rawtext_comp))
            if type(rawtext_comp) == type({}) and rawtext_comp['type'] == 'translate' : base_json['rawtext'].append(const_func.change_to_translate(rawtext_comp))

        return base_json






def Menu_set(Menu1 : tkinter.Menu): 
    Menu1.add_separator()
    Menu1.add_command(label="添加显示分数" , command=lambda : const_obj.add_score_button(main_win))
    Menu1.add_command(label="添加显示名字" , command=lambda : const_obj.add_selector_button(main_win))
    Menu1.add_command(label="添加翻译组件" , command=lambda : const_obj.add_translate_button(main_win))
    Menu1.add_separator()
    Menu1.add_command(label="批量添加按钮" , command=lambda : const_obj.batch_add_button(main_win))
    """
    Menu1.add_command(label="添加全显菜单" , command=lambda : const_obj.add_all_display_menu_button(main_win))
    Menu1.add_command(label="添加滚动菜单" , command=lambda : const_obj.add_roll_display_menu_button(main_win))
    Menu1.add_command(label="添加行列菜单" , command=lambda : const_obj.add_roll_column_display_menu_button(main_win))
    """



def UI_set(self):
    global main_win
    main_win = self

    main_frame = tkinter.Frame(self.expand_pack_ui_frame)
    tkinter.Label(main_frame,text="Rawtext Json",fg='black',font=('Arial',20),width=15,height=1).pack()
    
    tkinter.Canvas(main_frame,width=2000,height=10).pack()
    frame_m10 = tkinter.Frame(main_frame)
    sco1 = tkinter.Scrollbar(frame_m10,orient='vertical')
    file_select = tkinter.Listbox(frame_m10,font=('Arial',12),selectmode=SINGLE,height=15,width=24,yscrollcommand=sco1.set)
    file_select.grid()
    sco1.config(command=file_select.yview)
    sco1.grid(row=0,column=1,sticky=tkinter.N+tkinter.S)
    frame_m10.pack()
    tkinter.Canvas(main_frame,width=10,height=10).pack()

    frame_m6 = tkinter.Frame(main_frame)
    tkinter.Button(frame_m6,text='新建',font=('Arial', 12),bg='#9ae9d1' ,width=5, height=1,command=self.expand_pack_class.creat_new_rawtext).pack(side='left')
    tkinter.Canvas(frame_m6,width=15, height=5).pack(side='left')
    tkinter.Button(frame_m6,text='删除',font=('Arial', 12),bg='#9ae9d1' ,width=5, height=1,command=self.expand_pack_class.delete_rawtext).pack(side='left')
    tkinter.Canvas(frame_m6,width=15, height=5).pack(side='left')
    tkinter.Button(frame_m6,text='打开',font=('Arial', 12),bg='#9ae9d1' ,width=5, height=1,command=self.expand_pack_class.open_rawtext).pack(side='left')
    frame_m6.pack()

    tkinter.Label(main_frame, text="",fg='black',font=('Arial', 1), width=15, height=1).pack()
    frame_m6 = tkinter.Frame(main_frame)
    tkinter.Button(frame_m6,text='导入',font=('Arial', 12),bg='#9ae9d1' ,width=5, height=1,command=self.expand_pack_class.import_file).pack(side='left')
    tkinter.Canvas(frame_m6,width=15, height=5).pack(side='left')
    tkinter.Button(frame_m6,text='导出',font=('Arial', 12),bg='#9ae9d1' ,width=5, height=1,command=self.expand_pack_class.export_file).pack(side='left')
    tkinter.Canvas(frame_m6,width=15, height=5).pack(side='left')
    tkinter.Button(frame_m6,text='帮助',font=('Arial', 12),bg='#7fc8ff' ,width=5, height=1,command=lambda: webbrowser.open("http://localhost:32323/tutorial/ExpandPack.html")).pack(side='left')
    frame_m6.pack()
    main_frame.pack()
    
    
    font1 = tkinter.font.Font(family='Courier New', size=10)
    edit_frame = tkinter.Frame(self.expand_pack_ui_frame)

    Json_title = tkinter.Entry(edit_frame,font=('Arial',13),width=18,justify='center')
    Json_title.event_add("<<update-status>>","<KeyRelease>", "<ButtonRelease>")
    Json_title.bind("<<update-status>>", lambda a : self.expand_pack_class.save_title())
    Json_title.bind("<FocusIn>",lambda a : self.set_focus_input(a,Json_title))
    Json_title.pack()
    tkinter.Label(edit_frame, text="",fg='black',font=('Arial', 6), width=15, height=1).pack()

    frame_m10 = tkinter.Frame(edit_frame)
    sco1 = tkinter.Scrollbar(frame_m10,orient='vertical')
    sco2 = tkinter.Scrollbar(frame_m10,orient="horizontal")
    expand_input_1 = tkinter.Text(frame_m10,show=None,wrap=NONE,height=10,width=30,font=('Arial', 10),undo=True,yscrollcommand=sco1.set,xscrollcommand=sco2.set)
    expand_input_1.grid()
    expand_input_1.bind("<FocusIn>",lambda a : self.set_focus_input(a,expand_input_1))
    expand_input_1.rawtext_sign = ''
    sco1.config(command=expand_input_1.yview)
    sco2.config(command=expand_input_1.xview)
    expand_input_1.event_add("<<update-status>>","<KeyRelease>", "<ButtonRelease>")
    expand_input_1.bind("<<update-status>>", lambda a : self.expand_pack_class.save_content())
    sco1.grid(row=0,column=1,sticky=tkinter.N+tkinter.S)
    sco2.grid(sticky=tkinter.W+tkinter.E)
    frame_m10.pack()

    frame_m10 = tkinter.Frame(edit_frame)
    sco1 = tkinter.Scrollbar(frame_m10,orient='vertical')
    expand_output_1 = tkinter.Text(frame_m10,show=None,height=10,width=26,font=font1,yscrollcommand=sco1.set)
    expand_output_1.grid()
    expand_output_1.config(state="disabled")
    sco1.config(command=expand_output_1.yview)
    sco1.grid(row=0,column=1,sticky=tkinter.N+tkinter.S)
    frame_m10.pack()

    def save_and_quit() :
        self.expand_pack_class.save_title()
        self.expand_pack_class.save_content()
        self.expand_pack_class.save_file()
        self.expand_pack_class.open_win()
        self.expand_pack_class.template_choose = None
        file_select.delete(0,END)
        for i in self.expand_pack_class.save_data : file_select.insert(END,i['name'])
    def copy_text() :
        entry1 = tkinter.Entry()
        entry1.insert(END, expand_output_1.get("0.0",END)[:-1])
        entry1.selection_range("0",END)
        entry1.event_generate("<<Copy>>")
        main_win.modify_state("Json 复制成功")
    tkinter.Label(edit_frame, text="",fg='black',font=('Arial', 6), width=15, height=1).pack()
    frame_m6 = tkinter.Frame(edit_frame)
    tkinter.Button(frame_m6,text='退出',font=('Arial', 12),bg='#00ffff' ,width=5, height=1,command=save_and_quit).pack(side='left')
    tkinter.Canvas(frame_m6,width=15, height=5).pack(side='left')
    tkinter.Button(frame_m6,text='复制结果',font=('Arial', 12),bg='#00ffff' ,width=9, height=1,command=copy_text).pack(side='left')
    """
    tkinter.Canvas(frame_m6,width=15, height=5).pack(side='left')
    tkinter.Button(frame_m6,text='测试',font=('Arial', 12),bg='#00ffff' ,width=5, height=1,command=self.expand_pack_class).pack(side='left')
    """
    frame_m6.pack()


    test_frame = tkinter.Frame(self.expand_pack_ui_frame)
    frame_m10 = tkinter.Frame(test_frame)
    sco1 = tkinter.Scrollbar(frame_m10,orient='vertical')
    expand_test_1 = tkinter.Text(frame_m10,show=None,height=13,width=26,font=font1,wrap=NONE,yscrollcommand=sco1.set,state="disabled")
    expand_test_1.grid()
    sco1.config(command=expand_test_1.yview)
    sco1.grid(row=0,column=1,sticky=tkinter.N+tkinter.S)
    frame_m10.pack()
    
    self.expand_pack_class.tk_component = {"frame":{"main_frame": main_frame,"edit_frame": edit_frame,"test_frame": test_frame}, 
    "open_list": file_select, "Json_title": Json_title, "expand_input_1": expand_input_1, "expand_output_1": expand_output_1,
    "expand_test_1": expand_test_1}
    for i in self.expand_pack_class.save_data : file_select.insert(END,i['name'])
    const_obj.window_stack.append(self.expand_pack_ui_frame)
    const_obj.window_stack.append(edit_frame)
    edit_frame.input1 = expand_input_1