import tkinter,os,threading,copy,json,re,math,types,sys,webbrowser,nbtlib
sys.path.append(os.path.realpath(os.path.join(__file__, os.pardir)))
base_path = os.path.dirname(os.path.abspath(__file__))
from BDXfile import *
from tkinter.constants import *
import numpy as np
from string import Template
from tkinter import ttk


exec(open(os.path.join("main_source","constant.py"),"r",encoding='utf-8').read(),None,globals())
exec(open(os.path.join("main_source","glob_class.py"),"r",encoding='utf-8').read(),None,globals())
exec(open(os.path.join("main_source","game_class.py"),"r",encoding='utf-8').read(),None,globals())
exec(open(os.path.join("main_source","error_class.py"),"r",encoding='utf-8').read(),None,globals())
file_IO = file_operation()
exec(file_IO.read_a_file(bedrock_command_class_main_path),globals())
os.makedirs(os.path.join(base_path,'input'),exist_ok=True)
os.makedirs(os.path.join(base_path,'output'),exist_ok=True)

class pack_class : 
    def __init__(self) -> None : 
        self.check_selector = command_class.selector_system([1,19,0])
        self.tk_box = None
        self.block_state = json.loads(file_IO.read_a_file(os.path.join(bedrock_command_thing_path,"block_state")))
        self.enter_times = 0
    
    def test_setblock(self,command_text) :
        Token1 = command_class.Command_Tokenizer(command_text,0)

        command_token0 = Token1.match_command(True)
        if check_response(command_token0) == 0 or command_token0[0] != "setblock" : return None
        
        command_token1 = Token1.match_pos(True)
        if check_response(command_token1) == 0 : return None

        command_token2 = Token1.match_ID(True)
        if check_response(command_token2) == 0 : return None
        
        command_token3 = Token1.match_int(False,[0,32767])
        if check_response(command_token3) == 0 : return None
        if command_token3[0] == "" : command_token3 = (0,command_token3[1])

        command_token4 = Token1.match_normal(False,["destroy","keep","replace"])
        if check_response(command_token4) == 0 : return None
        if command_token4[0] == "" : command_token4 = ("replace",command_token4[1])

        command_token5 = Token1.match_end()
        if check_response(command_token5) == 0 : return None

        blockstate1 = self.find_block_state(command_token2[0],command_token3[0])
        all_list  = [command_token0[0]]
        all_list += command_token1[0]
        all_list.append(command_token2[0])
        if blockstate1 : all_list.append(blockstate1)
        all_list.append(command_token4[0])
        return " ".join(all_list)

    def test_testforblock(self,command_text) :
        Token1 = command_class.Command_Tokenizer(command_text,0)

        command_token0 = Token1.match_command(True)
        if check_response(command_token0) == 0 or command_token0[0] != "testforblock" : return None
        
        command_token1 = Token1.match_pos(True)
        if check_response(command_token1) == 0 : return None

        command_token2 = Token1.match_ID(True)
        if check_response(command_token2) == 0 : return None
        
        command_token3 = Token1.match_int(False,[-1,32767])
        if check_response(command_token3) == 0 : return None
        if command_token3[0] == "" : command_token3 = (0,command_token3[1])

        command_token5 = Token1.match_end()
        if check_response(command_token5) == 0 : return None

        blockstate1 = self.find_block_state(command_token2[0],command_token3[0])
        all_list  = [command_token0[0]]
        all_list += command_token1[0]
        all_list.append(command_token2[0])
        if blockstate1 : all_list.append(blockstate1)
        return " ".join(all_list)

    def test_clone(self,command_text) :
        Token1 = command_class.Command_Tokenizer(command_text,0)

        command_token0 = Token1.match_command(True)
        if check_response(command_token0) == 0 or command_token0[0] != "clone" : return None
        
        command_token1 = Token1.match_pos(True)
        if check_response(command_token1) == 0 : return None

        command_token2 = Token1.match_pos(True)
        if check_response(command_token2) == 0 : return None

        command_token3 = Token1.match_pos(True)
        if check_response(command_token3) == 0 : return None
        
        command_token4 = Token1.match_normal(True,['filtered'])
        if check_response(command_token4) == 0 : return None

        command_token5 = Token1.match_normal(True,["normal","move","force"])
        if check_response(command_token5) == 0 : return None

        command_token6 = Token1.match_ID(True)
        if check_response(command_token6) == 0 : return None

        command_token7 = Token1.match_int(False,[0,32767])
        if check_response(command_token7) == 0 : return None
        if command_token7[0] == "" : command_token7 = (0,command_token7[1])

        command_token10 = Token1.match_end()
        if check_response(command_token10) == 0 : return None

        blockstate1 = self.find_block_state(command_token6[0],command_token7[0])
        all_list = [command_token0[0]]
        all_list += command_token1[0]
        all_list += command_token2[0]
        all_list += command_token3[0]
        all_list += [command_token4[0],command_token5[0],command_token6[0]]
        if blockstate1 : all_list.append(blockstate1)
        return " ".join(all_list)

    def test_fill(self,command_text) :
        Token1 = command_class.Command_Tokenizer(command_text,0)

        command_token0 = Token1.match_command(True)
        if check_response(command_token0) == 0 or command_token0[0] != "fill" : return None
        
        command_token1 = Token1.match_pos(True)
        if check_response(command_token1) == 0 : return None

        command_token2 = Token1.match_pos(True)
        if check_response(command_token2) == 0 : return None

        command_token3 = Token1.match_ID(True)
        if check_response(command_token3) == 0 : return None
        
        command_token4 = Token1.match_int(False,[0,32767])
        if check_response(command_token4) == 0 : return None
        if command_token4[0] == "" : command_token4 = (0,command_token4[1])

        command_token5 = Token1.match_normal(False,['replace'])
        if check_response(command_token5) == 0 : return None

        command_token6 = Token1.match_ID(False)
        if check_response(command_token6) == 0 : return None
        
        command_token7 = Token1.match_int(False,[-1,32767])
        if check_response(command_token7) == 0 : return None
        if command_token7[0] == "" : command_token7 = (-1,command_token7[1])

        command_token10 = Token1.match_end()
        if check_response(command_token10) == 0 : return None

        all_list  = [command_token0[0]]
        all_list += command_token1[0]
        all_list += command_token2[0]
        all_list.append(command_token3[0])
        blockstate1 = self.find_block_state(command_token3[0],command_token4[0])
        if blockstate1 : all_list.append(blockstate1)
        if command_token5[0] and command_token6[0] :
            all_list += [command_token5[0],command_token6[0]]
            blockstate1 = self.find_block_state(command_token6[0],command_token7[0])
            if blockstate1 : all_list.append(blockstate1)
        return " ".join(all_list)

    def check_all_block_command(self,command_text) :
        abc = [self.test_setblock,self.test_testforblock,self.test_clone,self.test_fill]
        for test1 in abc :
            test2 = test1(command_text)
            if test2 : return test2
        return command_text

    def check_execute_command(self,execute_var,Token1,Token_list) :
            command_token0 = Token1.match_command(False)
            if check_response(command_token0) == 0 : yield command_token0
            if command_token0[0] != "execute" : 
                Token_list.append(("command",Token1.command_text))
                yield None

            command_token1 = Token1.match_selector(True)
            if check_response(command_token1) == 0 : yield command_token1
            
            if len(command_token1[0]) == 1:
                selector_list1 = self.check_selector.executing(execute_var,command_token1[0][0],only_check=True,is_extra=True)
            else :
                selector_list1 = self.check_selector.executing(execute_var,command_token1[0][0],command_token1[0][1],only_check=True,is_extra=True)
            if check_response(selector_list1) == 0 : yield selector_list1
            Token_list.append(("executer",command_token1[0]))

            command_token2 = Token1.match_pos(True)
            if check_response(command_token2) == 0 : yield command_token2
            Token_list.append(("pos",command_token2[0]))

            command_token3 = Token1.match_command(True)
            if check_response(command_token3) == 0 : yield command_token3
            Token1.back_skip()

            if command_token3[0] == "execute" : yield self.check_execute_command(execute_var,Token1,Token_list)
            elif command_token3[0] not in ["execute","detect"] : 
                Token_list.append(("command",Token1.command_text[command_token2[1]:]))
                yield None
            else : 
                Token1.next_pointer = command_token3[1]
                command_token4 = Token1.match_pos(True)
                if check_response(command_token4) == 0 : yield command_token4
                
                command_token5 = Token1.match_ID(True)
                if check_response(command_token5) == 0 : yield command_token5

                command_token6 = Token1.match_int(True,[-1,32767])
                if check_response(command_token6) == 0 : yield command_token6
                if command_token6[0] == "" : command_token6 = (-1,command_token6[1])
                Token_list.append(("if block",command_token4[0],command_token5[0],command_token6[0]))
                
                command_token7 = Token1.match_command(True)
                if check_response(command_token7) == 0 : yield command_token7
                Token1.back_skip()

                #print((execute_var,command_text[command_token6[1]:],command_token7[1]-command_token6[1]))
                if command_token7[0] == "execute" : 
                    Token1.next_pointer = command_token6[1]
                    yield self.check_execute_command(execute_var,Token1,Token_list)
                else : 
                    Token_list.append(("command",Token1.command_text[command_token6[1]:]))
                    yield None
    
    def find_block_state ( self , block_id , block_state_info={} ) :
        if type(block_state_info) == type(1) :
            if block_id in self.block_state :
                if block_state_info < 0 : return ''
                elif block_state_info == 0 :
                    BlockState = self.block_state[block_id]['default']
                else :
                    try : BlockState = self.block_state[block_id][bin(block_state_info)]
                    except : BlockState = self.block_state[block_id]['default']
            else : return ''
        if self.tk_box["version_choose"].current() == 0 : return '[' + json.dumps(BlockState,separators=(',', ':'))[1:][:-1] + ']'
        elif self.tk_box["version_choose"].current() == 1 : return '[' + json.dumps(BlockState,separators=(',', '='))[1:][:-1] + ']'

    def Token_list_transfor(self,list1) : 
        result1 = []
        if list1[0][0] == 'command' : 
            result1.append(self.check_all_block_command(list1[0][1]))
        else : 
            result1.append("execute")
            for step1 in list1 :
                if step1[0] == 'executer' : 
                    #print(step1)
                    result1.append("as " + step1[1][0] + (("["+",".join(step1[1][1])+"]") if (len(step1[1]) == 2) else "") + " at @s")
                elif step1[0] == 'pos' : 
                    result1.append("positioned " + " ".join(step1[1]))
                elif step1[0] == 'if block' : 
                    if step1[-1] == -1 : result1.append("if block " + " ".join(step1[1]) + " " + step1[2])
                    else : 
                        mmm1 = self.find_block_state(step1[-2],step1[-1])
                        result1.append("if block " + " ".join(step1[1]) + " " + step1[2] + " " + mmm1)
                elif step1[0] == 'command' : result1 += ["run" , self.check_all_block_command(step1[1])]

        return " ".join(result1)

    def exchange_text(self,main_window) :
        result_list,token_list = [],[]
        input_text = self.tk_box["input"].get("1.0","end")
        input_text = input_text[0:len(input_text)-1].split("\n")

        for text1 in input_text :
            token_list.clear()
            Token1 = command_class.Command_Tokenizer(text1,0)

            exe_result = self.check_execute_command({"executer":None,"execute_dimension":"overworld","execute_pos":[0,0,0],
            "execute_roatate":[0,0],"version":[1,19,0]},Token1,token_list)
            while isinstance(exe_result, types.GeneratorType): exe_result = exe_result.__next__()
            #print(token_list)
            if check_response(exe_result) == 0 :
                main_window.modify_state("转换出错，请查看反馈信息",info,want_record=False,want_display=True)
                self.tk_box["output"].delete("1.0",'end')
                self.tk_box["output"].insert('end', text1 + " 发生错误：\n" + exe_result.command_msg)
                return None
            result_list.append(self.Token_list_transfor(token_list))
        
        main_window.modify_state("转换已完成",info,want_record=False,want_display=True)
        self.tk_box["output"].delete("1.0",'end')
        self.tk_box["output"].insert('end', "\n".join(result_list))

    def exchange_dir(self,main_window) : 
        self.tk_box["output"].delete("1.0",'end')
        if self.enter_times == 0 :
            main_window.modify_state("二次确认：是否转换在\ninput文件夹下的所有文件？",info,want_record=False,want_display=True)
            self.enter_times += 1
        else :
            self.enter_times = 0
            main_window.modify_state("转换已经开始",info,want_record=False,want_display=True)
            loop_list = file_IO.file_in_path(os.path.join(main_window.run_expand_path,"input"))
            for file1 in loop_list:
                if not(file1[len(file1)-11:] == ".mcfunction" or file1[len(file1)-4:] == ".txt" or file1[len(file1)-4:] == ".bdx") : continue
                if file1[len(file1)-4:] != ".bdx" :
                    result_list,token_list,lines = [],[],0
                    try : input_text = file_IO.read_a_file(file1).split("\n")
                    except : continue
                    for text1 in input_text :
                        lines += 1
                        token_list.clear()
                        Token1 = command_class.Command_Tokenizer(text1,0)

                        exe_result = self.check_execute_command({"executer":None,"execute_dimension":"overworld","execute_pos":[0,0,0],
                        "execute_roatate":[0,0],"version":[1,19,0]},Token1,token_list)
                        while isinstance(exe_result, types.GeneratorType): exe_result = exe_result.__next__()
                        if check_response(exe_result) == 0 :
                            main_window.modify_state("转换出错，请查看反馈信息",info,want_record=False,want_display=True)
                            self.tk_box["output"].delete("1.0",'end')
                            self.tk_box["output"].insert('end', "文件: " + file1 + (
                            "(第%s行)"%(lines,)) + "\n" + text1 + " 发生错误：\n" + exe_result.command_msg)
                            return None
                        result_list.append(self.Token_list_transfor(token_list))
                    file_IO.write_a_file(file1.replace("input","output",1),"\n".join(result_list))
                else : 
                    try : bdx_obj = BDX_file(file1)
                    except : 
                        main_window.modify_state("转换出错，请查看反馈信息",info,want_record=False,want_display=True)
                        self.tk_box["output"].insert('end', "文件: " + file1 + "发生错误：\n无法识别为bdx文件")
                        return None
                    else :
                        command_dir = bdx_obj.operation_code_filter(0x22,0x23,0x24,0x1a,0x1b,0x29)
                        for keys1 in command_dir.keys() :
                            if command_dir[keys1].dict_code['operation_code'] != 0x29 : 
                                token_list = [] ; comm_dict = command_dir[keys1].dict_code
                                Token1 = command_class.Command_Tokenizer(comm_dict['command'],0)

                                exe_result = self.check_execute_command({"executer":None,"execute_dimension":"overworld","execute_pos":[0,0,0],
                                "execute_roatate":[0,0],"version":[1,19,0]},Token1,token_list)
                                while isinstance(exe_result, types.GeneratorType): exe_result = exe_result.__next__()
                                if check_response(exe_result) != 0 : 
                                    comm_dict['command'] = self.Token_list_transfor(token_list)
                                    command_dir[keys1].dict_to_bytes(comm_dict)
                                else : self.tk_box["output"].insert('end', "文件: " + file1 + "发生错误：\n无法识别为bdx文件\n")
                            else :
                                nbt = command_dir[keys1].dict_code['nbt']
                                if 'id' in nbt and nbt['id'] == nbtlib.tag.String('CommandBlock') and ('Command' in nbt) :
                                    Token1 = command_class.Command_Tokenizer(nbt['Command'],0)
                                    
                                    exe_result = self.check_execute_command({"executer":None,"execute_dimension":"overworld","execute_pos":[0,0,0],
                                    "execute_roatate":[0,0],"version":[1,19,0]},Token1,token_list)
                                    while isinstance(exe_result, types.GeneratorType): exe_result = exe_result.__next__()
                                    if check_response(exe_result) != 0 : 
                                        nbt['Command'] = nbtlib.tag.String(self.Token_list_transfor(token_list))
                                        command_dir[keys1].dict_to_bytes(comm_dict)
                                    else : self.tk_box["output"].insert('end', "文件: " + file1 + "发生错误：\n无法识别为bdx文件\n")
                            bdx_obj.write_to_file(file1.replace("input","output",1))

            main_window.modify_state("转换已完成",info,want_record=False,want_display=True)


def UI_set(self):
    tkinter.Label(self.expand_pack_ui_frame, text="命令输入区" , bg='aqua',fg='black',font=('Arial', 13), width=10, height=1).pack()
    expand_input_1 = tkinter.Text(self.expand_pack_ui_frame,show=None,height=8,width=30,font=('Arial', 10),undo=True)
    expand_input_1.pack()
    expand_input_1.bind("<FocusIn>",lambda a : self.set_focus_input(a,expand_input_1))
    tkinter.Canvas(self.expand_pack_ui_frame,width=2000, height=10).pack()

    expand_ui_2 = tkinter.Frame(self.expand_pack_ui_frame)
    tkinter.Button(expand_ui_2, text='转换输入',font=('Arial',10),bg='orange',width=8,height=1,
    command=lambda: self.expand_pack_class.exchange_text(self)).pack(side='left')
    tkinter.Canvas(expand_ui_2, width=10, height=5).pack(side='left')
    tkinter.Button(expand_ui_2, text='帮助',font=('Arial', 10),bg='#7fc8ff',width=4,height=1,
    command=lambda: webbrowser.open("http://localhost:32323/tutorial/ExpandPack.html")).pack(side='left')
    tkinter.Canvas(expand_ui_2, width=10, height=5).pack(side='left')
    tkinter.Button(expand_ui_2, text='批量转换',font=('Arial', 10),bg='orange',width=8,height=1,
    command=lambda: self.expand_pack_class.exchange_dir(self)).pack(side='left')
    expand_ui_2.pack()

    tkinter.Canvas(self.expand_pack_ui_frame,width=2000, height=10).pack()
    expand_output_1 = tkinter.Text(self.expand_pack_ui_frame,show=None,height=8,width=30,font=('Arial', 10),undo=True)
    expand_output_1.pack()
    expand_output_1.bind("<FocusIn>",lambda a : self.set_focus_input(a,expand_output_1))
    tkinter.Label(self.expand_pack_ui_frame, text="输出区" , bg='aqua',fg='black',font=('Arial', 13), width=10, height=1).pack()

    tkinter.Label(self.expand_pack_ui_frame,text="",fg='black',font=('Arial',3),width=15,height=1).pack()
    frame_m11 = tkinter.Frame(self.expand_pack_ui_frame)
    tkinter.Label(frame_m11,text="命令版本",bg="#b0b0b0",fg='black',font=('Arial',12),width=10,height=1).pack(side=LEFT)
    input0 = ttk.Combobox(frame_m11, font=('Arial',13), width=6, state='readonly', justify='center')
    input0["value"] = ("1.19.50", "1.20.0")
    input0.current(0)
    input0.pack(side=LEFT) ; frame_m11.pack()

    self.expand_pack_class.tk_box = {"input":expand_input_1,"output":expand_output_1,"version_choose" : input0}





    