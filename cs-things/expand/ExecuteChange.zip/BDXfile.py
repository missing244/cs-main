import brotli as btl
import io,os,traceback,toBytes
from parseNBT import parse

base_path = os.path.dirname(os.path.abspath(__file__))

"""
参考文档https://github.com/LNSSPsd/PhoenixBuilder/blob/main/doc/bdump/bdump-cn.md
"""

class BXDFileReadError(Exception): pass
class BXDFileDecodeError(Exception): pass

def IntToByte(int1) : return bytes([int1])
def ByteToInt(byte1) : return bytes([byte1])[0]


class BDX_file:

    __doc__ = """
        BXD_file类需要接受file参数进行实例化，file参数是open函数打开的文件或者路径字符串

        ###对象属性###
        BXD_file().old_bdx_code 解压完成的bdx数据
        BXD_file().operation_code 按照操作码分段的解码函数
        BXD_file().new_bxd_code 按照操作码拆解完成的bdx数据
        BXD_file().author bdx结构作者名

        ###对象方法###
        BXD_file().operation_code_filter() 使用操作码作为筛选条件，返回符合操作码的指令串，格式{index : bdx_code .....}
        BXD_file().modify_bdx_code() 传入 {index : bdx_code .....} 对bdx数据进行修改
        BXD_file().write_to_file(path) 传入路径字符串生成修改完成的bdx文件
    """

    def __init__(self,file) -> None:
        
        self.operation_code = { 0x01 : self.match_CreateConstantString,
                                0x05 : self.match_PlaceBlockWithBlockStates,
                                0x06 : self.match_AddInt16ZValue0,
                                0x07 : self.match_PlaceBlock,
                                0x08 : self.match_AddZValue0,
                                0x09 : self.match_NoOperation,
                                0x0c : self.match_AddInt32ZValue0,
                                0x0d : self.match_PlaceBlockWithBlockStatesDeprecated,
                                0x0e : self.match_AddXValue,
                                0x0f : self.match_SubtractXValue,
                                0x10 : self.match_AddYValue,
                                0x11 : self.match_SubtractYValue,
                                0x12 : self.match_AddZValue,
                                0x13 : self.match_SubtractZValue,
                                0x14 : self.match_AddInt16XValue,
                                0x15 : self.match_AddInt32XValue,
                                0x16 : self.match_AddInt16YValue,
                                0x17 : self.match_AddInt32YValue,
                                0x18 : self.match_AddInt16ZValue,
                                0x19 : self.match_AddInt32ZValue,
                                0x1a : self.match_SetCommandBlockData,
                                0x1b : self.match_PlaceBlockWithCommandBlockData,
                                0x1c : self.match_AddInt8XValue,
                                0x1d : self.match_AddInt8YValue,
                                0x1e : self.match_AddInt8ZValue,
                                0x1f : self.match_UseRuntimeIDPool,
                                0x20 : self.match_PlaceRuntimeBlock,
                                0x21 : self.match_PlaceRuntimeBlockWithUint32RuntimeID,
                                0x22 : self.match_PlaceRuntimeBlockWithCommandBlockData,
                                0x23 : self.match_PlaceRuntimeBlockWithCommandBlockDataAndUint32RuntimeID,
                                0x24 : self.match_PlaceCommandBlockWithCommandBlockData,
                                0x25 : self.match_PlaceRuntimeBlockWithChestData,
                                0x26 : self.match_PlaceRuntimeBlockWithChestDataAndUint32RuntimeID,
                                0x27 : self.match_AssignDebugData,
                                0x28 : self.match_PlaceBlockWithChestData,
                                0x29 : self.match_PlaceBlockWithNbtData,
                                0x5a : self.match_isSigned,
                            }

        if isinstance(file,type("")) : 
            file1 = open(file,"rb") ; self.file_name = file
        elif isinstance(file,io.IOBase) : file1 = file
        self.data0 = data0 = file1.read()
        file1.close()
        
        self.start_zip_data = data0[0:3]
        if self.start_zip_data != (b'BD@') : raise BXDFileReadError("这不是bdx数据文件")

        self.old_bdx_code = btl.decompress(data0[3:])
        self.code_len = len(self.old_bdx_code)
        self.byte_pointer = 0
        self.new_bxd_code = []

        self.bdx_head_bytes = b'BDX\0'
        self.author = b'\0'
        self.decode_bdx()
    
    def decode_bdx(self) -> None: 
        break_times,self.byte_pointer = 600000,0
        self.author = self.match_author()

        try : 
            while self.in_range() : 
                save_1 = self.operation_code[self.get_now_byte()]()
                self.new_bxd_code.append(Format_BDX_code(save_1))
                if self.old_bdx_code[self.byte_pointer:self.byte_pointer+2] == b'XE' : 
                    self.byte_pointer += 2; break
                if self.in_range() and self.get_now_byte() == 88 : self.byte_pointer += 2; break
                break_times -= 1
                if break_times < 1 : raise Exception("超出上限")
        except : 
            print("\n\n########################START  CODE##########################\n\n")
            print(self.file_name + "\n" if hasattr(self,'file_name') else "\n")
            traceback.print_exc()
            print("\n\n#################################################################\n\n")
            for i in self.new_bxd_code[-50:] : print(i)
            print(self.byte_pointer,self.code_len,len(self.new_bxd_code))
            print(save_1)
            print("\n\n#########################END  CODE##############################\n\n")
            raise Exception
        else : pass#print(break_times)


    #BuildIn_function（内建判断函数）
    def in_range(self) -> bool:
        return self.byte_pointer < self.code_len
        
    def out_range(self) -> bool:
        return self.byte_pointer >= self.code_len
    
    def is_pointer_data(self,byte1) -> bool:
        if isinstance(byte1,type(b'')) : byte1 = ByteToInt(byte1)
        return self.old_bdx_code[self.byte_pointer] == byte1
        
    def not_pointer_data(self,byte1) -> bool:
        if isinstance(byte1,type(b'')) : byte1 = ByteToInt(byte1)
        return self.old_bdx_code[self.byte_pointer] != byte1
    
    def get_now_byte(self,index1=0) -> bytes:
        return self.old_bdx_code[self.byte_pointer + index1]


    #match_function（匹配规则）
    def match_string(self) -> bytes:
        last_pointer = self.byte_pointer
        while 1 : 
            if self.is_pointer_data(0) : 
                self.byte_pointer += 1
                break
            self.byte_pointer += 1
        return self.old_bdx_code[last_pointer:self.byte_pointer]

    def match_author(self) -> bytes:
        if self.old_bdx_code[0:4] != (b'BDX\0') : raise BXDFileReadError("这不是bdx数据文件")
        self.byte_pointer = 4
        last_pointer = self.byte_pointer
        while 1 : 
            if self.out_range() or self.is_pointer_data(0) : break
            self.byte_pointer += 1
        self.byte_pointer += 1
        return self.old_bdx_code[last_pointer:self.byte_pointer]
    
    def match_CreateConstantString(self) -> bytes: #起始操作码0x01
        if self.not_pointer_data(1) : raise BXDFileDecodeError("CreateConstantString数据解码错误")
        last_pointer = self.byte_pointer
        self.byte_pointer += 1
        while 1 : 
            if self.out_range() or self.is_pointer_data(0) : break
            self.byte_pointer += 1
        self.byte_pointer += 1
        return self.old_bdx_code[last_pointer:self.byte_pointer]
    
    def match_PlaceBlockWithBlockStates(self) -> bytes: #起始操作码0x05
        if self.not_pointer_data(5) : raise BXDFileDecodeError("PlaceBlockWithBlockStates数据解码错误")
        last_pointer = self.byte_pointer
        self.byte_pointer += 5
        return self.old_bdx_code[last_pointer:self.byte_pointer]

    def match_AddInt16ZValue0(self) -> bytes: #起始操作码0x06
        if self.not_pointer_data(6) : raise BXDFileDecodeError("AddInt16ZValue0数据解码错误")
        last_pointer = self.byte_pointer
        self.byte_pointer += 3
        return self.old_bdx_code[last_pointer:self.byte_pointer]

    def match_PlaceBlock(self) -> bytes: #起始操作码0x07
        if self.not_pointer_data(7) : raise BXDFileDecodeError("PlaceBlock数据解码错误")
        last_pointer = self.byte_pointer
        self.byte_pointer += 5
        return self.old_bdx_code[last_pointer:self.byte_pointer]
    
    def match_AddZValue0(self) -> bytes: #起始操作码0x08
        if self.not_pointer_data(8) : raise BXDFileDecodeError("AddZValue0数据解码错误")
        last_pointer = self.byte_pointer
        self.byte_pointer += 1
        return self.old_bdx_code[last_pointer:self.byte_pointer]
    
    def match_NoOperation(self) -> bytes: #起始操作码0x09
        if self.not_pointer_data(9) : raise BXDFileDecodeError("NoOperation数据解码错误")
        last_pointer = self.byte_pointer
        self.byte_pointer += 1
        return self.old_bdx_code[last_pointer:self.byte_pointer]

    def match_AddInt32ZValue0(self) -> bytes: #起始操作码0x0c
        if self.not_pointer_data(0x0c) : raise BXDFileDecodeError("AddInt32ZValue0数据解码错误")
        last_pointer = self.byte_pointer
        self.byte_pointer += 5
        return self.old_bdx_code[last_pointer:self.byte_pointer]

    def match_PlaceBlockWithBlockStatesDeprecated(self) -> bytes: #起始操作码0x0d
        if self.not_pointer_data(0x0d) : raise BXDFileDecodeError("PlaceBlockWithBlockStatesDeprecated数据解码错误")
        last_pointer = self.byte_pointer
        self.byte_pointer += 3
        self.match_string()
        return self.old_bdx_code[last_pointer:self.byte_pointer]
    
    def match_AddXValue(self) -> bytes: #起始操作码0x0e
        if self.not_pointer_data(0x0e) : raise BXDFileDecodeError("AddXValue数据解码错误")
        last_pointer = self.byte_pointer
        self.byte_pointer += 1
        return self.old_bdx_code[last_pointer:self.byte_pointer]
    
    def match_SubtractXValue(self) -> bytes: #起始操作码0x0f
        if self.not_pointer_data(0x0f) : raise BXDFileDecodeError("SubtractXValue数据解码错误")
        last_pointer = self.byte_pointer
        self.byte_pointer += 1
        return self.old_bdx_code[last_pointer:self.byte_pointer]
    
    def match_AddYValue(self) -> bytes: #起始操作码0x10
        if self.not_pointer_data(0x10) : raise BXDFileDecodeError("AddYValue数据解码错误")
        last_pointer = self.byte_pointer
        self.byte_pointer += 1
        return self.old_bdx_code[last_pointer:self.byte_pointer]
    
    def match_SubtractYValue(self) -> bytes: #起始操作码0x11
        if self.not_pointer_data(0x11) : raise BXDFileDecodeError("SubtractYValue数据解码错误")
        last_pointer = self.byte_pointer
        self.byte_pointer += 1
        return self.old_bdx_code[last_pointer:self.byte_pointer]
    
    def match_AddZValue(self) -> bytes: #起始操作码0x12
        if self.not_pointer_data(0x12) : raise BXDFileDecodeError("AddZValue数据解码错误")
        last_pointer = self.byte_pointer
        self.byte_pointer += 1
        return self.old_bdx_code[last_pointer:self.byte_pointer]
    
    def match_SubtractZValue(self) -> bytes: #起始操作码0x13
        if self.not_pointer_data(0x13) : raise BXDFileDecodeError("SubtractZValue数据解码错误")
        last_pointer = self.byte_pointer
        self.byte_pointer += 1
        return self.old_bdx_code[last_pointer:self.byte_pointer]
    
    def match_AddInt16XValue(self) -> bytes: #起始操作码0x14
        if self.not_pointer_data(0x14) : raise BXDFileDecodeError("AddInt16XValue数据解码错误")
        last_pointer = self.byte_pointer
        self.byte_pointer += 3
        return self.old_bdx_code[last_pointer:self.byte_pointer]
    
    def match_AddInt32XValue(self) -> bytes: #起始操作码0x15
        if self.not_pointer_data(0x15) : raise BXDFileDecodeError("AddInt32XValue数据解码错误")
        last_pointer = self.byte_pointer
        self.byte_pointer += 5
        return self.old_bdx_code[last_pointer:self.byte_pointer]
    
    def match_AddInt16YValue(self) -> bytes: #起始操作码0x16
        if self.not_pointer_data(0x16) : raise BXDFileDecodeError("AddInt16YValue数据解码错误")
        last_pointer = self.byte_pointer
        self.byte_pointer += 3
        return self.old_bdx_code[last_pointer:self.byte_pointer]
    
    def match_AddInt32YValue(self) -> bytes: #起始操作码0x17
        if self.not_pointer_data(0x17) : raise BXDFileDecodeError("AddInt32YValue数据解码错误")
        last_pointer = self.byte_pointer
        self.byte_pointer += 5
        return self.old_bdx_code[last_pointer:self.byte_pointer]
    
    def match_AddInt16ZValue(self) -> bytes: #起始操作码0x18
        if self.not_pointer_data(0x18) : raise BXDFileDecodeError("AddInt16ZValue数据解码错误")
        last_pointer = self.byte_pointer
        self.byte_pointer += 3
        return self.old_bdx_code[last_pointer:self.byte_pointer]
    
    def match_AddInt32ZValue(self) -> bytes: #起始操作码0x19
        if self.not_pointer_data(0x19) : raise BXDFileDecodeError("AddInt32ZValue数据解码错误")
        last_pointer = self.byte_pointer
        self.byte_pointer += 5
        return self.old_bdx_code[last_pointer:self.byte_pointer]

    def match_SetCommandBlockData(self) -> bytes:#起始操作码0x1a 
        if self.not_pointer_data(0x1a) : raise BXDFileDecodeError("PlaceBlockWithCommandBlockData数据解码错误")
        last_pointer = self.byte_pointer
        self.byte_pointer += 5
        self.match_string()
        self.match_string()
        self.match_string()
        self.byte_pointer += 8
        return self.old_bdx_code[last_pointer:self.byte_pointer]

    def match_PlaceBlockWithCommandBlockData(self) -> bytes:#起始操作码0x1b 
        if self.not_pointer_data(0x1b) : raise BXDFileDecodeError("PlaceBlockWithCommandBlockData数据解码错误")
        last_pointer = self.byte_pointer
        self.byte_pointer += 9
        self.match_string()
        self.match_string()
        self.match_string()
        self.byte_pointer += 8
        return self.old_bdx_code[last_pointer:self.byte_pointer]

    def match_AddInt8XValue(self) -> bytes: #起始操作码0x1c
        if self.not_pointer_data(0x1c) : raise BXDFileDecodeError("AddInt8XValue数据解码错误")
        last_pointer = self.byte_pointer
        self.byte_pointer += 2
        return self.old_bdx_code[last_pointer:self.byte_pointer]

    def match_AddInt8YValue(self) -> bytes: #起始操作码0x1d
        if self.not_pointer_data(0x1d) : raise BXDFileDecodeError("AddInt8YValue数据解码错误")
        last_pointer = self.byte_pointer
        self.byte_pointer += 2
        return self.old_bdx_code[last_pointer:self.byte_pointer]

    def match_AddInt8ZValue(self) -> bytes: #起始操作码0x1e
        if self.not_pointer_data(0x1e) : raise BXDFileDecodeError("AddInt8ZValue数据解码错误")
        last_pointer = self.byte_pointer
        self.byte_pointer += 2
        return self.old_bdx_code[last_pointer:self.byte_pointer]

    def match_UseRuntimeIDPool(self) -> bytes: #起始操作码0x1f
        if self.not_pointer_data(0x1f) : raise BXDFileDecodeError("UseRuntimeIDPool数据解码错误")
        last_pointer = self.byte_pointer
        self.byte_pointer += 2
        return self.old_bdx_code[last_pointer:self.byte_pointer]

    def match_PlaceRuntimeBlock(self) -> bytes: #起始操作码0x20
        if self.not_pointer_data(0x20) : raise BXDFileDecodeError("PlaceRuntimeBlock数据解码错误")
        last_pointer = self.byte_pointer
        self.byte_pointer += 3
        return self.old_bdx_code[last_pointer:self.byte_pointer]
    
    def match_PlaceRuntimeBlockWithUint32RuntimeID(self) -> bytes: #起始操作码0x21
        if self.not_pointer_data(0x21) : raise BXDFileDecodeError("PlaceRuntimeBlockWithUint32RuntimeID数据解码错误")
        last_pointer = self.byte_pointer
        self.byte_pointer += 5
        return self.old_bdx_code[last_pointer:self.byte_pointer]

    def match_PlaceRuntimeBlockWithCommandBlockData(self) -> bytes: #起始操作码0x22
        if self.not_pointer_data(0x22) : raise BXDFileDecodeError("PlaceRuntimeBlockWithCommandBlockData数据解码错误")
        last_pointer = self.byte_pointer
        self.byte_pointer += 7
        self.match_string()
        self.match_string()
        self.match_string()
        self.byte_pointer += 8
        return self.old_bdx_code[last_pointer:self.byte_pointer]

    def match_PlaceRuntimeBlockWithCommandBlockDataAndUint32RuntimeID(self) -> bytes:#起始操作码0x23 
        if self.not_pointer_data(0x23) : raise BXDFileDecodeError("PlaceRuntimeBlockWithCommandBlockDataAndUint32RuntimeID数据解码错误")
        last_pointer = self.byte_pointer
        self.byte_pointer += 9
        self.match_string()
        self.match_string()
        self.match_string()
        self.byte_pointer += 8
        return self.old_bdx_code[last_pointer:self.byte_pointer]

    def match_PlaceCommandBlockWithCommandBlockData(self) -> bytes:#起始操作码0x24 
        if self.not_pointer_data(0x24) : raise BXDFileDecodeError("PlaceCommandBlockWithCommandBlockData数据解码错误")
        last_pointer = self.byte_pointer
        self.byte_pointer += 7
        self.match_string()
        self.match_string()
        self.match_string()
        self.byte_pointer += 8
        return self.old_bdx_code[last_pointer:self.byte_pointer]

    def match_PlaceRuntimeBlockWithChestData(self) -> bytes: #起始操作码0x25
        if self.not_pointer_data(0x25) : raise BXDFileDecodeError("PlaceRuntimeBlockWithChestData数据解码错误")
        last_pointer = self.byte_pointer
        self.byte_pointer += 3
        count1 = self.get_now_byte()
        self.byte_pointer += 1
        for i in range(count1) : 
            self.match_string()
            self.byte_pointer += 4
        return self.old_bdx_code[last_pointer:self.byte_pointer]

    def match_PlaceRuntimeBlockWithChestDataAndUint32RuntimeID(self) -> bytes: #起始操作码0x26
        if self.not_pointer_data(0x26) : raise BXDFileDecodeError("PlaceRuntimeBlockWithChestDataAndUint32RuntimeID数据解码错误")
        last_pointer = self.byte_pointer
        self.byte_pointer += 5
        count1 = self.get_now_byte()
        self.byte_pointer += 1
        for i in range(count1) : 
            self.match_string()
            self.byte_pointer += 4
        return self.old_bdx_code[last_pointer:self.byte_pointer]

    def match_AssignDebugData(self) -> bytes: #起始操作码0x27
        if self.not_pointer_data(0x26) : raise BXDFileDecodeError("AssignDebugData数据解码错误")
        last_pointer = self.byte_pointer
        self.byte_pointer += 1
        count1 = self.get_now_byte(0) << 24 + self.get_now_byte(1) << 16 + (
            self.get_now_byte(2) << 8 + self.get_now_byte(3))
        self.byte_pointer += (4 + count1)
        return self.old_bdx_code[last_pointer:self.byte_pointer]

    def match_PlaceBlockWithChestData(self) -> bytes: #起始操作码0x28
        if self.not_pointer_data(0x28) : raise BXDFileDecodeError("PlaceBlockWithChestData数据解码错误")
        last_pointer = self.byte_pointer
        self.byte_pointer += 5
        count1 = self.get_now_byte()
        self.byte_pointer += 1
        for i in range(count1) : 
            self.match_string()
            self.byte_pointer += 4
        return self.old_bdx_code[last_pointer:self.byte_pointer]
    
    def match_PlaceBlockWithNbtData(self) -> bytes :#起始操作码0x29
        if self.not_pointer_data(0x29) : raise BXDFileDecodeError("PlaceBlockWithNbtData数据解码错误")
        last_pointer = self.byte_pointer
        self.byte_pointer += 7
        fileContext = self.old_bdx_code[self.byte_pointer:]
        newReader = io.BytesIO(fileContext) ; parse(newReader)
        self.byte_pointer += newReader.seek(0,1)
        return self.old_bdx_code[last_pointer:self.byte_pointer]
    
    def match_isSigned(self) -> bytes: 
        if self.not_pointer_data(0x5a) : raise BXDFileDecodeError("isSigned数据解码错误")
        last_pointer = self.byte_pointer
        self.byte_pointer += 2
        return self.old_bdx_code[last_pointer:self.byte_pointer]


    #基础函数
    def operation_code_filter(self,*operation_code1 : int) -> dict: #return {index : bdx_code .....}
        json_1 = {}
        for i in range(len(self.new_bxd_code)) :
            if self.new_bxd_code[i].dict_code['operation_code'] in operation_code1 : json_1[i] = self.new_bxd_code[i]
        return json_1

    def modify_bdx_code(self,modify_dir : dict) -> None: #inpute {index : bdx_code .....}
        for key1 in modify_dir.keys() : self.new_bxd_code[key1] = modify_dir[key1]

    

    def write_to_file(self,path1 : str) :
        middle1 = self.bdx_head_bytes + self.author + b''.join([i.bdx_code for i in self.new_bxd_code]) + IntToByte(88)
        file1 = open(path1, 'wb')
        file1.write(self.start_zip_data + btl.compress(middle1,quality=6))
        file1.close()






class Format_BDX_code :

    __doc__ = """
        Format_BDX_code类需要接受bytes或dict参数进行实例化

        ###对象属性###
        BXD_file().bdx_code bdx字节码数据(可读取和修改)
        BXD_file().dict_code bdx字节码对应的可读dict(可读取和修改)

        ###对象方法###
        BXD_file().bytes_to_dict(bytes) 传入bytes后将字节码转换为dict
        BXD_file().dict_to_bytes(dict)  传入dict后将dict转换为bytes
    """

    def __repr__(self) -> str:
        return str(self.dict_code)

    def __init__(self,input_data) -> None:
        self.format_operation = { 0x01 : self.format_CreateConstantString,
                                0x05 : self.format_PlaceBlockWithBlockStates,
                                0x06 : self.format_AddInt16ZValue0,
                                0x07 : self.format_PlaceBlock,
                                0x08 : self.format_AddZValue0,
                                0x09 : self.format_NoOperation,
                                0x0c : self.format_AddInt32ZValue0,
                                0x0d : self.format_PlaceBlockWithBlockStatesDeprecated,
                                0x0e : self.format_AddXValue,
                                0x0f : self.format_SubtractXValue,
                                0x10 : self.format_AddYValue,
                                0x11 : self.format_SubtractYValue,
                                0x12 : self.format_AddZValue,
                                0x13 : self.format_SubtractZValue,
                                0x14 : self.format_AddInt16XValue,
                                0x15 : self.format_AddInt32XValue,
                                0x16 : self.format_AddInt16YValue,
                                0x17 : self.format_AddInt32YValue,
                                0x18 : self.format_AddInt16ZValue,
                                0x19 : self.format_AddInt32ZValue,
                                0x1a : self.format_SetCommandBlockData,
                                0x1b : self.format_PlaceBlockWithCommandBlockData,
                                0x1c : self.format_AddInt8XValue,
                                0x1d : self.format_AddInt8YValue,
                                0x1e : self.format_AddInt8ZValue,
                                0x1f : self.format_UseRuntimeIDPool,
                                0x20 : self.format_PlaceRuntimeBlock,
                                0x21 : self.format_PlaceRuntimeBlockWithUint32RuntimeID,
                                0x22 : self.format_PlaceRuntimeBlockWithCommandBlockData,
                                0x23 : self.format_PlaceRuntimeBlockWithCommandBlockDataAndUint32RuntimeID,
                                0x24 : self.format_PlaceCommandBlockWithCommandBlockData,
                                0x25 : self.format_PlaceRuntimeBlockWithChestData,
                                0x26 : self.format_PlaceRuntimeBlockWithChestDataAndUint32RuntimeID,
                                0x27 : self.format_AssignDebugData,
                                0x28 : self.format_PlaceBlockWithChestData,
                                0x29 : self.format_PlaceBlockWithNbtData,
                                0x5a : self.format_isSigned,
                            }
        
        self.bdx_code = b''
        self.dict_code = {}
        if isinstance(input_data,type(b'')) : 
            self.bdx_code = input_data
            self.byte_pointer = 0
            self.code_len = len(self.bdx_code)
            self.tramsfor(True)
        elif isinstance(input_data,type({})) : 
            self.dict_code = input_data
            self.tramsfor(False)


    def tramsfor(self,Deserialize : bool) :
        if len(self.bdx_code) == 0 : return None
        if Deserialize : self.dict_code = self.format_operation[self.bdx_code[0]](Deserialize)
        else : self.bdx_code = self.format_operation[self.dict_code['operation_code']](Deserialize)


    #BuildIn_function（内建判断函数）
    def in_range(self) :
        return self.byte_pointer < self.code_len
        
    def out_range(self) :
        return self.byte_pointer >= self.code_len
    
    def is_pointer_data(self,byte1):
        if isinstance(byte1,type(b'')) : byte1 = ByteToInt(byte1)
        return self.bdx_code[self.byte_pointer] == byte1
        
    def not_pointer_data(self,byte1):
        if isinstance(byte1,type(b'')) : byte1 = ByteToInt(byte1)
        return self.bdx_code[self.byte_pointer] != byte1
    
    def get_now_byte(self,index1=0) :
        return self.bdx_code[self.byte_pointer + index1]


    def match_string(self) :
        last_pointer = self.byte_pointer
        while 1 : 
            if self.is_pointer_data(0) : 
                self.byte_pointer += 1
                break
            self.byte_pointer += 1
        return self.bdx_code[last_pointer:self.byte_pointer]

    def format_CreateConstantString(self,Deserialize : bool) : #起始操作码0x01
        if Deserialize : 
            if self.not_pointer_data(1) : raise BXDFileDecodeError("CreateConstantString数据解码错误")
            last_pointer = self.byte_pointer
            self.byte_pointer += 1
            while 1 : 
                if self.out_range() or self.is_pointer_data(0) : break
                self.byte_pointer += 1
            result_code = self.bdx_code[last_pointer:self.byte_pointer]
            return {'operation_code': result_code[0], 'means': 'CreateConstantString', 'string': result_code[1:].decode('utf-8')}
        else :
            return IntToByte(self.dict_code['operation_code']) + self.dict_code['string'].encode('utf-8') + b'\0'
    
    def format_PlaceBlockWithBlockStates(self,Deserialize : bool) : #起始操作码0x05
        if Deserialize : 
            if self.not_pointer_data(5) : raise BXDFileDecodeError("PlaceBlockWithBlockStates数据解码错误")
            last_pointer = self.byte_pointer
            self.byte_pointer += 5
            result_code = self.bdx_code[last_pointer:self.byte_pointer]
            return {'operation_code': result_code[0], 'means': 'PlaceBlockWithBlockStates',
                    'blockConstantStringID': int.from_bytes(result_code[1:3],'big',signed=False),
                    'blockStatesConstantStringID': int.from_bytes(result_code[3:5],'big',signed=False)}
        else : 
            return (b'').join([IntToByte(self.dict_code['operation_code']),self.dict_code['blockConstantStringID'].to_bytes(2,'big', signed=False),
                               self.dict_code['blockStatesConstantStringID'].to_bytes(2,'big', signed=False)])

    def format_AddInt16ZValue0(self,Deserialize : bool) : #起始操作码0x06
        if Deserialize : 
            if self.not_pointer_data(6) : raise BXDFileDecodeError("AddInt16ZValue0数据解码错误")
            last_pointer = self.byte_pointer
            self.byte_pointer += 3
            result_code = self.bdx_code[last_pointer:self.byte_pointer]
            return {'operation_code': result_code[0], 'means': 'AddInt16ZValue0',
                    'value': int.from_bytes(result_code[1:3],'big',signed=False)}
        else : 
            return (b'').join([IntToByte(self.dict_code['operation_code']),self.dict_code['value'].to_bytes(2,'big', signed=False)])

    def format_PlaceBlock(self,Deserialize : bool) : #起始操作码0x07
        if Deserialize : 
            if self.not_pointer_data(7) : raise BXDFileDecodeError("PlaceBlock数据解码错误")
            last_pointer = self.byte_pointer
            self.byte_pointer += 5
            result_code = self.bdx_code[last_pointer:self.byte_pointer]
            return {'operation_code': result_code[0], 'means': 'PlaceBlock',
                    'blockConstantStringID': int.from_bytes(result_code[1:3],'big',signed=False),
                    'blockData': int.from_bytes(result_code[1:3],'big',signed=False)}
        else : 
            return (b'').join([IntToByte(self.dict_code['operation_code']),self.dict_code['blockConstantStringID'].to_bytes(2,'big', signed=False),
                               self.dict_code['blockData'].to_bytes(2,'big', signed=False)])
    
    def format_AddZValue0(self,Deserialize : bool) : #起始操作码0x08
        if Deserialize : 
            if self.not_pointer_data(8) : raise BXDFileDecodeError("AddZValue0数据解码错误")
            last_pointer = self.byte_pointer
            self.byte_pointer += 1
            result_code = self.bdx_code[last_pointer:self.byte_pointer]
            return {'operation_code': result_code[0], 'means': 'AddZValue0'}
        else : 
            return (b'').join([IntToByte(self.dict_code['operation_code'])])
    
    def format_NoOperation(self,Deserialize : bool) : #起始操作码0x09
        if Deserialize : 
            if self.not_pointer_data(9) : raise BXDFileDecodeError("NoOperation数据解码错误")
            last_pointer = self.byte_pointer
            self.byte_pointer += 1
            result_code = self.bdx_code[last_pointer:self.byte_pointer]
            return {'operation_code': result_code[0], 'means': 'NoOperation'}
        else : 
            return (b'').join([IntToByte(self.dict_code['operation_code'])])

    def format_AddInt32ZValue0(self,Deserialize : bool) : #起始操作码0x0c
        if Deserialize : 
            if self.not_pointer_data(0x0c) : raise BXDFileDecodeError("AddInt32ZValue0数据解码错误")
            last_pointer = self.byte_pointer
            self.byte_pointer += 5
            result_code = self.bdx_code[last_pointer:self.byte_pointer]
            return {'operation_code': result_code[0], 'means': 'AddInt32ZValue0', 'value': int.from_bytes(result_code[1:5],'big',signed=False)}
        else : 
            return (b'').join([IntToByte(self.dict_code['operation_code']), self.dict_code['value'].to_bytes(4,'big', signed=False)])

    def format_PlaceBlockWithBlockStatesDeprecated(self,Deserialize : bool) : #起始操作码0x0d
        if Deserialize : 
            if self.not_pointer_data(0x0d) : raise BXDFileDecodeError("PlaceBlockWithBlockStatesDeprecated数据解码错误")
            last_pointer = self.byte_pointer
            self.byte_pointer += 3
            string1 = self.match_string()
            result_code = self.bdx_code[last_pointer:self.byte_pointer]
            return {'operation_code': result_code[0], 'means': 'PlaceBlockWithBlockStatesDeprecated', 
                    'blockConstantStringID': int.from_bytes(result_code[1:3],'big',signed=False),
                    'blockStatesString': string1[:-1].decode('utf-8')}
        else : 
            return (b'').join([IntToByte(self.dict_code['operation_code']), self.dict_code['blockConstantStringID'].to_bytes(2,'big', signed=False),
                               self.dict_code['blockStatesString'].encode('utf-8'),b'\0'])
    
    def format_AddXValue(self,Deserialize : bool) : #起始操作码0x0e
        if Deserialize : 
            if self.not_pointer_data(0x0e) : raise BXDFileDecodeError("AddXValue数据解码错误")
            last_pointer = self.byte_pointer
            self.byte_pointer += 1
            result_code = self.bdx_code[last_pointer:self.byte_pointer]
            return {'operation_code': result_code[0], 'means': 'AddXValue'}
        else : 
            return (b'').join([IntToByte(self.dict_code['operation_code'])])
    
    def format_SubtractXValue(self,Deserialize : bool) : #起始操作码0x0f
        if Deserialize :
            if self.not_pointer_data(0x0f) : raise BXDFileDecodeError("SubtractXValue数据解码错误")
            last_pointer = self.byte_pointer
            self.byte_pointer += 1
            result_code = self.bdx_code[last_pointer:self.byte_pointer]
            return {'operation_code': result_code[0], 'means': 'SubtractXValue'}
        else : 
            return (b'').join([IntToByte(self.dict_code['operation_code'])])
    
    def format_AddYValue(self,Deserialize : bool) : #起始操作码0x10
        if Deserialize :
            if self.not_pointer_data(0x10) : raise BXDFileDecodeError("AddYValue数据解码错误")
            last_pointer = self.byte_pointer
            self.byte_pointer += 1
            result_code = self.bdx_code[last_pointer:self.byte_pointer]
            return {'operation_code': result_code[0], 'means': 'AddYValue'}
        else : 
            return (b'').join([IntToByte(self.dict_code['operation_code'])])
    
    def format_SubtractYValue(self,Deserialize : bool) : #起始操作码0x11
        if Deserialize :
            if self.not_pointer_data(0x11) : raise BXDFileDecodeError("SubtractYValue数据解码错误")
            last_pointer = self.byte_pointer
            self.byte_pointer += 1
            result_code = self.bdx_code[last_pointer:self.byte_pointer]
            return {'operation_code': result_code[0], 'means': 'SubtractYValue'}
        else : 
            return (b'').join([IntToByte(self.dict_code['operation_code'])])
    
    def format_AddZValue(self,Deserialize : bool) : #起始操作码0x12
        if Deserialize :
            if self.not_pointer_data(0x12) : raise BXDFileDecodeError("AddZValue数据解码错误")
            last_pointer = self.byte_pointer
            self.byte_pointer += 1
            result_code = self.bdx_code[last_pointer:self.byte_pointer]
            return {'operation_code': result_code[0], 'means': 'AddZValue'}
        else : 
            return (b'').join([IntToByte(self.dict_code['operation_code'])])
    
    def format_SubtractZValue(self,Deserialize : bool) : #起始操作码0x13
        if Deserialize :
            if self.not_pointer_data(0x13) : raise BXDFileDecodeError("SubtractZValue数据解码错误")
            last_pointer = self.byte_pointer
            self.byte_pointer += 1
            result_code = self.bdx_code[last_pointer:self.byte_pointer]
            return {'operation_code': result_code[0], 'means': 'SubtractZValue'}
        else : 
            return (b'').join([IntToByte(self.dict_code['operation_code'])])
    
    def format_AddInt16XValue(self,Deserialize : bool) : #起始操作码0x14
        if Deserialize :
            if self.not_pointer_data(0x14) : raise BXDFileDecodeError("AddInt16XValue数据解码错误")
            last_pointer = self.byte_pointer
            self.byte_pointer += 3
            result_code = self.bdx_code[last_pointer:self.byte_pointer]
            return {'operation_code': result_code[0], 'means': 'AddInt16XValue', 'value':int.from_bytes(result_code[1:3],'big',signed=True)}
        else : 
            return (b'').join([IntToByte(self.dict_code['operation_code']),self.dict_code['value'].to_bytes(2,'big', signed=True)])
    
    def format_AddInt32XValue(self,Deserialize : bool) : #起始操作码0x15
        if Deserialize :
            if self.not_pointer_data(0x15) : raise BXDFileDecodeError("AddInt32XValue数据解码错误")
            last_pointer = self.byte_pointer
            self.byte_pointer += 5
            result_code = self.bdx_code[last_pointer:self.byte_pointer]
            return {'operation_code': result_code[0], 'means': 'AddInt16XValue', 'value':int.from_bytes(result_code[1:5],'big',signed=True)}
        else : 
            return (b'').join([IntToByte(self.dict_code['operation_code']),self.dict_code['value'].to_bytes(4,'big', signed=True)])
    
    def format_AddInt16YValue(self,Deserialize : bool) : #起始操作码0x16
        if Deserialize :
            if self.not_pointer_data(0x16) : raise BXDFileDecodeError("AddInt16YValue数据解码错误")
            last_pointer = self.byte_pointer
            self.byte_pointer += 3
            result_code = self.bdx_code[last_pointer:self.byte_pointer]
            return {'operation_code': result_code[0], 'means': 'AddInt16YValue', 'value':int.from_bytes(result_code[1:3],'big',signed=True)}
        else : 
            return (b'').join([IntToByte(self.dict_code['operation_code']),self.dict_code['value'].to_bytes(2,'big', signed=True)])
    
    def format_AddInt32YValue(self,Deserialize : bool) : #起始操作码0x17
        if Deserialize :
            if self.not_pointer_data(0x17) : raise BXDFileDecodeError("AddInt32YValue数据解码错误")
            last_pointer = self.byte_pointer
            self.byte_pointer += 5
            result_code = self.bdx_code[last_pointer:self.byte_pointer]
            return {'operation_code': result_code[0], 'means': 'AddInt32YValue', 'value':int.from_bytes(result_code[1:5],'big',signed=True)}
        else : 
            return (b'').join([IntToByte(self.dict_code['operation_code']),self.dict_code['value'].to_bytes(4,'big', signed=True)])
    
    def format_AddInt16ZValue(self,Deserialize : bool) : #起始操作码0x18
        if Deserialize :
            if self.not_pointer_data(0x18) : raise BXDFileDecodeError("AddInt16ZValue数据解码错误")
            last_pointer = self.byte_pointer
            self.byte_pointer += 3
            result_code = self.bdx_code[last_pointer:self.byte_pointer]
            return {'operation_code': result_code[0], 'means': 'AddInt16ZValue', 'value':int.from_bytes(result_code[1:3],'big',signed=True)}
        else : 
            return (b'').join([IntToByte(self.dict_code['operation_code']),self.dict_code['value'].to_bytes(2,'big', signed=True)])
    
    def format_AddInt32ZValue(self,Deserialize : bool) : #起始操作码0x19
        if Deserialize :
            if self.not_pointer_data(0x19) : raise BXDFileDecodeError("AddInt32ZValue数据解码错误")
            last_pointer = self.byte_pointer
            self.byte_pointer += 5
            result_code = self.bdx_code[last_pointer:self.byte_pointer]
            return {'operation_code': result_code[0], 'means': 'AddInt32ZValue', 'value':int.from_bytes(result_code[1:5],'big',signed=True)}
        else : 
            return (b'').join([IntToByte(self.dict_code['operation_code']),self.dict_code['value'].to_bytes(4,'big', signed=True)])

    def format_SetCommandBlockData(self,Deserialize : bool) :#起始操作码0x1a 
        if Deserialize :
            if self.not_pointer_data(0x1a) : raise BXDFileDecodeError("PlaceBlockWithCommandBlockData数据解码错误")
            last_pointer = self.byte_pointer
            self.byte_pointer += 5
            command = self.match_string()[:-1].decode('utf-8')
            name = self.match_string()[:-1].decode('utf-8')
            output = self.match_string()[:-1].decode('utf-8')
            self.byte_pointer += 8
            result_code = self.bdx_code[last_pointer:self.byte_pointer]
            return {'operation_code': result_code[0], 'means': 'SetCommandBlockData', 'mode':int.from_bytes(result_code[1:5],'big',signed=True),
                    'command': command, 'name': name, 'output': output, 'delay':int.from_bytes(result_code[-8:-4],'big',signed=True),
                    'executeOnFirstTick':result_code[-4],'trackOutput':result_code[-3],'conditional':result_code[-2],
                    'needsRedstone':result_code[-1],}
        else : 
            return (b'').join([IntToByte(self.dict_code['operation_code']),self.dict_code['mode'].to_bytes(4,'big', signed=False),
                               self.dict_code['command'].encode('utf-8'),b'\0',self.dict_code['name'].encode('utf-8'),b'\0',
                               self.dict_code['output'].encode('utf-8'),b'\0',self.dict_code['delay'].to_bytes(4,'big', signed=True),
                               self.dict_code['executeOnFirstTick'].to_bytes(1,'big', signed=False),
                               self.dict_code['trackOutput'].to_bytes(1,'big', signed=False),
                               self.dict_code['conditional'].to_bytes(1,'big', signed=False),
                               self.dict_code['needsRedstone'].to_bytes(1,'big', signed=False)])

    def format_PlaceBlockWithCommandBlockData(self,Deserialize : bool) :#起始操作码0x1b 
        if Deserialize :
            if self.not_pointer_data(0x1b) : raise BXDFileDecodeError("PlaceBlockWithCommandBlockData数据解码错误")
            last_pointer = self.byte_pointer
            self.byte_pointer += 9
            command = self.match_string()[:-1].decode('utf-8')
            name = self.match_string()[:-1].decode('utf-8')
            output = self.match_string()[:-1].decode('utf-8')
            self.byte_pointer += 8
            result_code = self.bdx_code[last_pointer:self.byte_pointer]
            return {'operation_code': result_code[0], 'means': 'PlaceBlockWithCommandBlockData', 
                    'blockConstantStringID': int.from_bytes(result_code[1:3],'big',signed=False),
                    'blockData': int.from_bytes(result_code[3:5],'big',signed=False),
                    'mode':int.from_bytes(result_code[5:9],'big',signed=False),
                    'command': command, 'name': name, 'output': output, 'delay':int.from_bytes(result_code[-8:-4],'big',signed=True),
                    'executeOnFirstTick':result_code[-4],'trackOutput':result_code[-3],'conditional':result_code[-2],
                    'needsRedstone':result_code[-1],}
        else : 
            return (b'').join([IntToByte(self.dict_code['operation_code']),
                               self.dict_code['blockConstantStringID'].to_bytes(2,'big', signed=False),
                               self.dict_code['blockData'].to_bytes(2,'big', signed=False),
                               self.dict_code['mode'].to_bytes(4,'big', signed=False),
                               self.dict_code['command'].encode('utf-8'),b'\0',self.dict_code['name'].encode('utf-8'),b'\0',
                               self.dict_code['output'].encode('utf-8'),b'\0',self.dict_code['delay'].to_bytes(4,'big', signed=True),
                               self.dict_code['executeOnFirstTick'].to_bytes(1,'big', signed=False),
                               self.dict_code['trackOutput'].to_bytes(1,'big', signed=False),
                               self.dict_code['conditional'].to_bytes(1,'big', signed=False),
                               self.dict_code['needsRedstone'].to_bytes(1,'big', signed=False)])

    def format_AddInt8XValue(self,Deserialize : bool) : #起始操作码0x1c
        if Deserialize :
            if self.not_pointer_data(0x1c) : raise BXDFileDecodeError("AddInt8XValue数据解码错误")
            last_pointer = self.byte_pointer
            self.byte_pointer += 2
            result_code = self.bdx_code[last_pointer:self.byte_pointer]
            return {'operation_code': result_code[0], 'means': 'AddInt8XValue', 'value':int.from_bytes(IntToByte(result_code[1]),'big',signed=True)}
        else : 
            return (b'').join([IntToByte(self.dict_code['operation_code']),self.dict_code['value'].to_bytes(1,'big', signed=True)])

    def format_AddInt8YValue(self,Deserialize : bool) : #起始操作码0x1d
        if Deserialize :
            if self.not_pointer_data(0x1d) : raise BXDFileDecodeError("AddInt8YValue数据解码错误")
            last_pointer = self.byte_pointer
            self.byte_pointer += 2
            result_code = self.bdx_code[last_pointer:self.byte_pointer]
            return {'operation_code': result_code[0], 'means': 'AddInt8YValue', 'value':int.from_bytes(IntToByte(result_code[1]),'big',signed=True)}
        else : 
            return (b'').join([IntToByte(self.dict_code['operation_code']),self.dict_code['value'].to_bytes(1,'big', signed=True)])

    def format_AddInt8ZValue(self,Deserialize : bool) : #起始操作码0x1e
        if Deserialize :
            if self.not_pointer_data(0x1e) : raise BXDFileDecodeError("AddInt8ZValue数据解码错误")
            last_pointer = self.byte_pointer
            self.byte_pointer += 2
            result_code = self.bdx_code[last_pointer:self.byte_pointer]
            return {'operation_code': result_code[0], 'means': 'AddInt8ZValue', 'value':int.from_bytes(IntToByte(result_code[1]),'big',signed=True)}
        else : 
            return (b'').join([IntToByte(self.dict_code['operation_code']),self.dict_code['value'].to_bytes(1,'big', signed=True)])

    def format_UseRuntimeIDPool(self,Deserialize : bool) : #起始操作码0x1f
        if Deserialize :
            if self.not_pointer_data(0x1f) : raise BXDFileDecodeError("UseRuntimeIDPool数据解码错误")
            last_pointer = self.byte_pointer
            self.byte_pointer += 2
            result_code = self.bdx_code[last_pointer:self.byte_pointer]
            return {'operation_code': result_code[0], 'means': 'UseRuntimeIDPool', 'poolId':int.from_bytes(IntToByte(result_code[1]),'big',signed=False)}
        else : 
            return (b'').join([IntToByte(self.dict_code['operation_code']),self.dict_code['poolId'].to_bytes(1,'big', signed=False)])

    def format_PlaceRuntimeBlock(self,Deserialize : bool) : #起始操作码0x20
        if Deserialize :
            if self.not_pointer_data(0x20) : raise BXDFileDecodeError("PlaceRuntimeBlock数据解码错误")
            last_pointer = self.byte_pointer
            self.byte_pointer += 3
            result_code = self.bdx_code[last_pointer:self.byte_pointer]
            return {'operation_code': result_code[0], 'means': 'PlaceRuntimeBlock', 'poolId':int.from_bytes(result_code[1:],'big',signed=False)}
        else : 
            return (b'').join([IntToByte(self.dict_code['operation_code']),self.dict_code['poolId'].to_bytes(2,'big', signed=False)])
    
    def format_PlaceRuntimeBlockWithUint32RuntimeID(self,Deserialize : bool) : #起始操作码0x21
        if Deserialize :
            if self.not_pointer_data(0x21) : raise BXDFileDecodeError("PlaceRuntimeBlockWithUint32RuntimeID数据解码错误")
            last_pointer = self.byte_pointer
            self.byte_pointer += 5
            result_code = self.bdx_code[last_pointer:self.byte_pointer]
            return {'operation_code': result_code[0], 'means': 'PlaceRuntimeBlockWithUint32RuntimeID', 'poolId':int.from_bytes(result_code[1:],'big',signed=False)}
        else : 
            return (b'').join([IntToByte(self.dict_code['operation_code']),self.dict_code['poolId'].to_bytes(4,'big', signed=False)])

    def format_PlaceRuntimeBlockWithCommandBlockData(self,Deserialize : bool) : #起始操作码0x22
        if Deserialize :
            if self.not_pointer_data(0x22) : raise BXDFileDecodeError("PlaceRuntimeBlockWithCommandBlockData数据解码错误")
            last_pointer = self.byte_pointer
            self.byte_pointer += 7
            command = self.match_string()[:-1].decode('utf-8')
            name = self.match_string()[:-1].decode('utf-8')
            output = self.match_string()[:-1].decode('utf-8')
            self.byte_pointer += 8
            result_code = self.bdx_code[last_pointer:self.byte_pointer]
            return {'operation_code': result_code[0], 'means': 'PlaceRuntimeBlockWithCommandBlockData', 
                    'runtimeId': int.from_bytes(result_code[1:3],'big',signed=False),
                    'mode':int.from_bytes(result_code[3:7],'big',signed=False),
                    'command': command, 'name': name, 'output': output, 'delay':int.from_bytes(result_code[-8:-4],'big',signed=True),
                    'executeOnFirstTick':result_code[-4],'trackOutput':result_code[-3],'conditional':result_code[-2],
                    'needsRedstone':result_code[-1],}
        else : 
            return (b'').join([IntToByte(self.dict_code['operation_code']),
                               self.dict_code['runtimeId'].to_bytes(2,'big', signed=False),
                               self.dict_code['mode'].to_bytes(4,'big', signed=False),
                               self.dict_code['command'].encode('utf-8'),b'\0',self.dict_code['name'].encode('utf-8'),b'\0',
                               self.dict_code['output'].encode('utf-8'),b'\0',self.dict_code['delay'].to_bytes(4,'big', signed=True),
                               self.dict_code['executeOnFirstTick'].to_bytes(1,'big', signed=False),
                               self.dict_code['trackOutput'].to_bytes(1,'big', signed=False),
                               self.dict_code['conditional'].to_bytes(1,'big', signed=False),
                               self.dict_code['needsRedstone'].to_bytes(1,'big', signed=False)])

    def format_PlaceRuntimeBlockWithCommandBlockDataAndUint32RuntimeID(self,Deserialize : bool) :#起始操作码0x23 
        if Deserialize :
            if self.not_pointer_data(0x23) : raise BXDFileDecodeError("PlaceRuntimeBlockWithCommandBlockDataAndUint32RuntimeID数据解码错误")
            last_pointer = self.byte_pointer
            self.byte_pointer += 9
            command = self.match_string()[:-1].decode('utf-8')
            name = self.match_string()[:-1].decode('utf-8')
            output = self.match_string()[:-1].decode('utf-8')
            self.byte_pointer += 8
            result_code = self.bdx_code[last_pointer:self.byte_pointer]
            return {'operation_code': result_code[0], 'means': 'PlaceRuntimeBlockWithCommandBlockDataAndUint32RuntimeID', 
                    'runtimeId': int.from_bytes(result_code[1:5],'big',signed=False),
                    'mode':int.from_bytes(result_code[5:9],'big',signed=False),
                    'command': command, 'name': name, 'output': output, 'delay':int.from_bytes(result_code[-8:-4],'big',signed=True),
                    'executeOnFirstTick':result_code[-4],'trackOutput':result_code[-3],'conditional':result_code[-2],
                    'needsRedstone':result_code[-1],}
        else : 
            return (b'').join([IntToByte(self.dict_code['operation_code']),
                               self.dict_code['runtimeId'].to_bytes(4,'big', signed=False),
                               self.dict_code['mode'].to_bytes(4,'big', signed=False),
                               self.dict_code['command'].encode('utf-8'),b'\0',self.dict_code['name'].encode('utf-8'),b'\0',
                               self.dict_code['output'].encode('utf-8'),b'\0',self.dict_code['delay'].to_bytes(4,'big', signed=True),
                               self.dict_code['executeOnFirstTick'].to_bytes(1,'big', signed=False),
                               self.dict_code['trackOutput'].to_bytes(1,'big', signed=False),
                               self.dict_code['conditional'].to_bytes(1,'big', signed=False),
                               self.dict_code['needsRedstone'].to_bytes(1,'big', signed=False)])

    def format_PlaceCommandBlockWithCommandBlockData(self,Deserialize : bool) :#起始操作码0x24 
        if Deserialize :
            if self.not_pointer_data(0x24) : raise BXDFileDecodeError("PlaceCommandBlockWithCommandBlockData数据解码错误")
            last_pointer = self.byte_pointer
            self.byte_pointer += 7
            #print(self.bdx_code[self.byte_pointer:])
            command = self.match_string()[:-1].decode('utf-8')
            name = self.match_string()[:-1].decode('utf-8')
            output = self.match_string()[:-1].decode('utf-8')
            self.byte_pointer += 8
            result_code = self.bdx_code[last_pointer:self.byte_pointer]
            return {'operation_code': result_code[0], 'means': 'PlaceCommandBlockWithCommandBlockData', 
                    'data': int.from_bytes(result_code[1:3],'big',signed=False),
                    'mode':int.from_bytes(result_code[3:7],'big',signed=False),
                    'command': command, 'name': name, 'output': output, 
                    'delay':int.from_bytes(result_code[-8:-4],'big',signed=True),
                    'executeOnFirstTick':result_code[-4],'trackOutput':result_code[-3],'conditional':result_code[-2],
                    'needsRedstone':result_code[-1],}
        else : 
            return (b'').join([IntToByte(self.dict_code['operation_code']),
                               self.dict_code['data'].to_bytes(2,'big', signed=False),
                               self.dict_code['mode'].to_bytes(4,'big', signed=False),
                               self.dict_code['command'].encode('utf-8'),b'\0',self.dict_code['name'].encode('utf-8'),b'\0',
                               self.dict_code['output'].encode('utf-8'),b'\0',self.dict_code['delay'].to_bytes(4,'big', signed=True),
                               self.dict_code['executeOnFirstTick'].to_bytes(1,'big', signed=False),
                               self.dict_code['trackOutput'].to_bytes(1,'big', signed=False),
                               self.dict_code['conditional'].to_bytes(1,'big', signed=False),
                               self.dict_code['needsRedstone'].to_bytes(1,'big', signed=False)])

    def format_PlaceRuntimeBlockWithChestData(self,Deserialize : bool) : #起始操作码0x25
        if Deserialize :
            if self.not_pointer_data(0x25) : raise BXDFileDecodeError("PlaceRuntimeBlockWithChestData数据解码错误")
            last_pointer = self.byte_pointer
            self.byte_pointer += 3
            count1 = self.get_now_byte()
            self.byte_pointer += 1
            item_list = []
            for i in range(count1) : 
                json1 = {}
                json1['item'] = self.match_string()[:-1].decode('utf-8')
                self.byte_pointer += 4
                json1['count'] = self.bdx_code[last_pointer:self.byte_pointer][-4]
                json1['data'] = int.from_bytes(self.bdx_code[last_pointer:self.byte_pointer][-3:-1],'big',signed=False)
                json1['slotID'] = self.bdx_code[last_pointer:self.byte_pointer][-1]
                item_list.append(json1)
            result_code = self.bdx_code[last_pointer:self.byte_pointer]
            return {'operation_code': result_code[0], 'means': 'PlaceRuntimeBlockWithChestData',
                    'runtimeId':int.from_bytes(result_code[1:3],'big',signed=False),
                    'item' : item_list}
        else : 
            return (b'').join([IntToByte(self.dict_code['operation_code']),self.dict_code['runtimeId'].to_bytes(2,'big', signed=False),
                               len(self.dict_code['item']).to_bytes(1,'big', signed=False)] + 
                               [(i['item'].encode('utf-8')+b'\0'+i['count'].to_bytes(1,'big', signed=False)+
                                 i['data'].to_bytes(2,'big', signed=False)+i['slotID'].to_bytes(1,'big', signed=False)) for i in self.dict_code['item']])

    def format_PlaceRuntimeBlockWithChestDataAndUint32RuntimeID(self,Deserialize : bool) : #起始操作码0x26
        if Deserialize :
            if self.not_pointer_data(0x26) : raise BXDFileDecodeError("PlaceRuntimeBlockWithChestDataAndUint32RuntimeID数据解码错误")
            last_pointer = self.byte_pointer
            self.byte_pointer += 5
            count1 = self.get_now_byte()
            self.byte_pointer += 1
            item_list = []
            for i in range(count1) : 
                json1 = {}
                json1['item'] = self.match_string()[:-1].decode('utf-8')
                self.byte_pointer += 4
                json1['count'] = self.bdx_code[last_pointer:self.byte_pointer][-4]
                json1['data'] = int.from_bytes(self.bdx_code[last_pointer:self.byte_pointer][-3:-1],'big',signed=False)
                json1['slotID'] = self.bdx_code[last_pointer:self.byte_pointer][-1]
                item_list.append(json1)
            result_code = self.bdx_code[last_pointer:self.byte_pointer]
            return {'operation_code': result_code[0], 'means': 'PlaceRuntimeBlockWithChestDataAndUint32RuntimeID',
                    'runtimeId':int.from_bytes(result_code[1:5],'big',signed=False),
                    'item' : item_list}
        else : 
            return (b'').join([IntToByte(self.dict_code['operation_code']),self.dict_code['runtimeId'].to_bytes(4,'big', signed=False),
                               len(self.dict_code['item']).to_bytes(1,'big', signed=False)] + 
                               [(i['item'].encode('utf-8')+b'\0'+i['count'].to_bytes(1,'big', signed=False)+
                                 i['data'].to_bytes(2,'big', signed=False)+i['slotID'].to_bytes(1,'big', signed=False)) for i in self.dict_code['item']])

    def format_AssignDebugData(self,Deserialize : bool) : #起始操作码0x27
        if Deserialize :
            if self.not_pointer_data(0x26) : raise BXDFileDecodeError("AssignDebugData数据解码错误")
            last_pointer = self.byte_pointer
            self.byte_pointer += 1
            count1 = self.get_now_byte(0) << 24 + self.get_now_byte(1) << 16 + (
                self.get_now_byte(2) << 8 + self.get_now_byte(3))
            self.byte_pointer += (4 + count1)
            result_code = self.bdx_code[last_pointer:self.byte_pointer]
            return {'operation_code': result_code[0], 'means': 'AssignDebugData', 'debugData':result_code[5:]}
        else : 
            return (b'').join([IntToByte(self.dict_code['operation_code']),len(self.dict_code['debugData']).to_bytes(4,'big', signed=False),
                               self.dict_code['debugData']])

    def format_PlaceBlockWithChestData(self,Deserialize : bool) : #起始操作码0x28
        if Deserialize :
            if self.not_pointer_data(0x28) : raise BXDFileDecodeError("PlaceBlockWithChestData数据解码错误")
            last_pointer = self.byte_pointer
            self.byte_pointer += 5
            count1 = self.get_now_byte()
            self.byte_pointer += 1
            item_list = []
            for i in range(count1) : 
                json1 = {}
                json1['item'] = self.match_string()[:-1].decode('utf-8')
                self.byte_pointer += 4
                json1['count'] = self.bdx_code[last_pointer:self.byte_pointer][-4]
                json1['data'] = int.from_bytes(self.bdx_code[last_pointer:self.byte_pointer][-3:-1],'big',signed=False)
                json1['slotID'] = self.bdx_code[last_pointer:self.byte_pointer][-1]
                item_list.append(json1)
            result_code = self.bdx_code[last_pointer:self.byte_pointer]
            return {'operation_code': result_code[0], 'means': 'PlaceBlockWithChestData',
                    'blockConstantStringID':int.from_bytes(result_code[1:3],'big',signed=False),
                    'blockData':int.from_bytes(result_code[3:5],'big',signed=False),
                    'item' : item_list}
        else : 
            return (b'').join([IntToByte(self.dict_code['operation_code']),
                               len(self.dict_code['blockConstantStringID']).to_bytes(2,'big', signed=False),
                               len(self.dict_code['blockData']).to_bytes(2,'big', signed=False),
                               len(self.dict_code['item']).to_bytes(1,'big', signed=False)] + 
                               [(i['item'].encode('utf-8')+b'\0'+i['count'].to_bytes(1,'big', signed=False)+
                                 i['data'].to_bytes(2,'big', signed=False)+i['slotID'].to_bytes(1,'big', signed=False)) for i in self.dict_code['item']])
    
    def format_PlaceBlockWithNbtData(self,Deserialize : bool) : #起始操作码0x29
        if Deserialize :
            if self.not_pointer_data(0x29) : raise BXDFileDecodeError("PlaceBlockWithNbtData数据解码错误")
            last_pointer = self.byte_pointer
            self.byte_pointer += 5
            result_code = self.bdx_code[last_pointer:self.byte_pointer]
            newReader = io.BytesIO(result_code[7:])
            return {'operation_code': result_code[0], 'means': 'PlaceBlockWithNbtData', 'BlockConstantStringID ':int.from_bytes(result_code[1:3],'big',signed=False),
                    'BlockStatesConstantStringID ':int.from_bytes(result_code[3:5],'big',signed=False), "nbt": parse(newReader)[0]}
        else : 
            newReader = io.BytesIO(b""); toBytes.MarshalPythonNBTObjectToWriter(newReader, self.dict_code['nbt'], '')
            return (b'').join([IntToByte(self.dict_code['operation_code']),self.dict_code['BlockConstantStringID'].to_bytes(2,'big', signed=False),
                               self.dict_code['BlockStatesConstantStringID'].to_bytes(2,'big', signed=False),
                               newReader.getvalue()])
    
    def format_isSigned(self,Deserialize : bool) : 
        if Deserialize :
            if self.not_pointer_data(0x5a) : raise BXDFileDecodeError("isSigned数据解码错误")
            last_pointer = self.byte_pointer
            self.byte_pointer += 2
            result_code = self.bdx_code[last_pointer:self.byte_pointer]
            return {'operation_code': result_code[0], 'means': 'isSigned', 'signatureSize':result_code[1]}
        else : 
            return (b'').join([IntToByte(self.dict_code['operation_code']),self.dict_code['signatureSize'].to_bytes(1,'big', signed=False)])


    def bytes_to_dict(self,byte_code : bytes) :
        self.bdx_code = byte_code
        self.tramsfor(True)

    def dict_to_bytes(self,dict_1 : dict) :
        self.dict_code = dict_1
        self.tramsfor(False)






if __name__ == "__main__" :
    aaa = BDX_file(os.path.join(base_path,'input\\969+3+972小豆建筑工具.bdx'))
    dict1 = aaa.operation_code_filter(0x22,0x23,0x24,0x1a,0x1b,0x29)
    for i in dict1 : print(dict1[i])
    print(aaa.byte_pointer,aaa.code_len,len(aaa.new_bxd_code),len(dict1))
    #for i in aaa.new_bxd_code[0:300] : print(i)