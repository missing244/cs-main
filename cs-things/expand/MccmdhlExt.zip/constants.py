import tkinter
import mccmdhl

__all__ = ["ALL_WRAPS", "ALL_VERSIONS",
           "BG_UNPRESSED", "BG_PRESSED", "BUTTON_FONT"]

ALL_WRAPS = (tkinter.NONE, tkinter.WORD, tkinter.CHAR)
ALL_VERSIONS = list(mccmdhl.CommandTokenizer.get_all_versions())
ALL_VERSIONS.sort(reverse=True)
BG_UNPRESSED = "#00ff7f"
BG_PRESSED = "#ff4500"
BUTTON_FONT = {
    "background": BG_UNPRESSED,
    "font": ("Arial", 9),
}
