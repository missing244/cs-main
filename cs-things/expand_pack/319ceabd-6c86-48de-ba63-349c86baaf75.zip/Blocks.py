import main_source.package.python_bdx as bdx
import main_source.package.python_nbt as nbt
import json, re, math, itertools
# 设置数组的坐标值，如果没有则自动补齐
def SetArrayValue(Value, Array, Position):
    X, Y, Z = Position['x'], Position['y'], Position['z']
    if len(Array)-1 < X:
        for i in range(X - len(Array)+1): Array.append([])
    if len(Array[X])-1 < Y:
        for i in range(Y - len(Array[X])+1): Array[X].append([])
    if len(Array[X][Y])-1 < Z:
        for i in range(Z - len(Array[X][Y])+1): Array[X][Y].append(None)
    Array[X][Y][Z] = Value

# 获取数组的值，如果没有则返回None
def GetArrayValue(Array, Position):
    X, Y, Z = Position['x'], Position['y'], Position['z']
    try:
        return Array[X][Y][Z]
    except:
        return None

# 获取数组尺寸
def GetArraySize(Array):
    SizeX, SizeY, SizeZ = 0, 0, 0
    SizeX = len(Array)
    for y in Array:
        if len(y) > SizeY: SizeY = len(y)
        for z in y:
            if len(z) > SizeZ: SizeZ = len(z)
    return [SizeX, SizeY, SizeZ]

def GetPosOperations(Pos1, Pos2):
    Pos = [Pos2[i] - Pos1[i] for i in range(3)]
    if not Pos[0] and not Pos[1] and not Pos[2]: return
    OperationList = []
    if Pos[0]:
        if   Pos[0] == 1: OperationList.append(bdx.OperationCode.AddXValue())
        elif Pos[0] == -1: OperationList.append(bdx.OperationCode.SubtractXValue())
        elif -128 <= Pos[0] <= 127: OperationList.append(bdx.OperationCode.AddInt8XValue(Pos[0]))
        elif -32768 <= Pos[0] <= 32767: OperationList.append(bdx.OperationCode.AddInt16XValue(Pos[0]))
        elif -2147483648 <= Pos[0] <= 2147483647: OperationList.append(bdx.OperationCode.AddInt32XValue(Pos[0]))
    if Pos[1]:
        if   Pos[1] == 1: OperationList.append(bdx.OperationCode.AddYValue())
        elif Pos[1] == -1: OperationList.append(bdx.OperationCode.SubtractYValue())
        elif -128 <= Pos[1] <= 127: OperationList.append(bdx.OperationCode.AddInt8YValue(Pos[1]))
        elif -32768 <= Pos[1] <= 32767: OperationList.append(bdx.OperationCode.AddInt16YValue(Pos[1]))
        elif -2147483648 <= Pos[1] <= 2147483647: OperationList.append(bdx.OperationCode.AddInt32YValue(Pos[1]))
    if Pos[2]:
        if   Pos[2] == 1: OperationList.append(bdx.OperationCode.AddZValue())
        elif Pos[2] == -1: OperationList.append(bdx.OperationCode.SubtractZValue())
        elif -128 <= Pos[2] <= 127: OperationList.append(bdx.OperationCode.AddInt8ZValue(Pos[2]))
        elif -32768 <= Pos[2] <= 32767: OperationList.append(bdx.OperationCode.AddInt16ZValue(Pos[2]))
        elif -2147483648 <= Pos[2] <= 2147483647: OperationList.append(bdx.OperationCode.AddInt32ZValue(Pos[2]))
    return OperationList

def GetClassName(Class):
    return Class.__class__.__name__

def GetCommandNBT(operation):
    NBT = {
        'mode': operation.mode,
        'command': operation.command,
        'customName': operation.customName,
        'tickdelay': operation.tickdelay,
        'executeOnFirstTick': operation.executeOnFirstTick,
        'trackOutput': operation.trackOutput,
        'conditional': operation.conditional,
        'needsRedstone': operation.needsRedstone
    }
    return NBT

class Block:
    def __init__(self, BlockID=None, BlockStates=None, BlockData=None, **kwargs):
        self.BlockID = BlockID
        self.BlockStates = self.ParserBlockStates(BlockStates)
        self.BlockData = BlockData
        self.BlockNBT = None
        Mode = kwargs.get('Mode', None)
        Type = kwargs.get('Type', None)
        Name = kwargs.get('Name', None)
        NBT = kwargs.get('NBT', None)
        if Mode == "bdx":
            self.BlockNBT = self.BDXParserNBT(Type, Name, NBT)
    def __str__(self):
        String = {}
        String['BlockID'] = self.BlockID
        String['BlockStates'] = self.BlockStates
        String['BlockData'] = self.BlockData
        String['BlockNBT'] = self.BlockNBT
        return str(String)
    def SetBlockID(self, BlockID):
        ...
    def SetBlockStates(self, BlockStates):
        ...
    def SetBlockData(self, BlockData):
        ...
    def ParserBlockStates(self, BlockStatesString):
        if BlockStatesString is None: return None
        BlockStatesString = re.sub(r'=', ':', BlockStatesString)
        return json.loads('{'+BlockStatesString[1:-1]+'}')
    def BDXParserNBT(self, Type, Name, NBT):
        if Type == "BlockEntity":
            if Name == "Command":
                return self.BDXParserCommandNBT(NBT)
        raise Exception(f"不支持的NBT解析, {Name}, {NBT}")
    def BDXParserCommandNBT(self, NBT):
        ClassNBT = nbt.TAG_Compound()
        ClassNBT['Command'] = nbt.TAG_String(NBT['command'])
        ClassNBT['CustomName'] = nbt.TAG_String(NBT['customName'])
        ClassNBT['ExecuteOnFirstTick'] = nbt.TAG_Byte(NBT['executeOnFirstTick'])
        ClassNBT['LPCommandMode'] = nbt.TAG_Int(NBT['mode'])
        ClassNBT['LPCondionalMode'] = nbt.TAG_Byte(NBT['conditional'])
        ClassNBT['LPRedstoneMode'] = nbt.TAG_Byte(NBT['needsRedstone'])
        ClassNBT['LastExecution'] = nbt.TAG_Long()
        ClassNBT['LastOutput'] = nbt.TAG_String()
        LastOutputParams = nbt.TAG_List(nbt.TAG_String)
        LastOutputParams.append(nbt.TAG_String())
        ClassNBT['LastOutputParams'] = LastOutputParams
        ClassNBT['SuccessCount'] = nbt.TAG_Int()
        ClassNBT['TickDelay'] = nbt.TAG_Int(NBT['tickdelay'])
        ClassNBT['TrackOutput'] = nbt.TAG_Byte(NBT['trackOutput'])
        ClassNBT['Version'] = nbt.TAG_Int(16)
        ClassNBT['auto'] = nbt.TAG_Byte()
        ClassNBT['conditionMet'] = nbt.TAG_Byte()
        ClassNBT['conditionalMode'] = nbt.TAG_Byte()
        ClassNBT['id'] = nbt.TAG_String("CommandBlock")
        ClassNBT['isMovable'] = nbt.TAG_Byte()
        ClassNBT['powered'] = nbt.TAG_Byte()
        ClassNBT['x'] = nbt.TAG_Int()
        ClassNBT['y'] = nbt.TAG_Int()
        ClassNBT['z'] = nbt.TAG_Int()
        
        return ClassNBT
    
    def GetBDX(self, BlockIDPool, BlockStatesPool):
        if self.BlockID is None: return None
        if self.BlockID in ["command_block", "chain_command_block", "repeating_command_block"]:
            if self.BlockStates: raise Exception("没有适配的命令方块方块状态")
            return bdx.OperationCode.PlaceCommandBlockWithCommandBlockData(self.BlockData,
            self.BlockNBT["LPCommandMode"].value, self.BlockNBT["Command"].value, self.BlockNBT["CustomName"].value,
            self.BlockNBT["TickDelay"].value, self.BlockNBT["ExecuteOnFirstTick"].value, self.BlockNBT["TrackOutput"].value,
            self.BlockNBT["LPCondionalMode"].value, self.BlockNBT["LPRedstoneMode"].value)
        # 还没有实现的功能
        elif self.BlockID in ["chest"]:
            pass
        else:
            try:
                IndexID = BlockIDPool.index(self.BlockID)
            except ValueError:
                IndexID = len(BlockIDPool)
                BlockIDPool.append(self.BlockID)
            if self.BlockData and self.BlockStates: raise Exception("方块不能同时有特殊值和状态")
            if self.BlockData and not self.BlockStates:
                return bdx.OperationCode.PlaceBlock(IndexID, self.BlockData)
            if not self.BlockData and self.BlockStates:
                States = '['+str(self.BlockStates)[1:-1]+']'
                try:
                    IndexStates = BlockStatesPool.index(States)
                except ValueError:
                    IndexStates = len(BlockStatesPool)
                    BlockStatesPool.append(States)
                return bdx.OperationCode.PlaceBlockWithBlockStates1(IndexID, IndexStates)
            
    
    

class ParserBlocks:
    def __init__(self, List, Size):
        self.Blocks = List
        self.Size = Size
    
    def GetBlocksSize(self):
        return GetArraySize(self.Blocks)
    
    def GetBlocksValue(self, Pos):
        return GetArrayValue(self.Blocks, Pos)
    
    @classmethod
    def FromBDX(cls, BDX, RunTimeIds=None):
        Position = {'x': 0, 'y': 0, 'z': 0}
        ListBlockID, Blocks, RunTimeBlocks = [], [], []
        for operation in BDX.operation_list:
            Name = GetClassName(operation)
            if Name in ["CreateConstantString"]:
                ListBlockID.append(operation.string)
            elif Name in ["PlaceBlockWithBlockStates1"]:
                blockName = ListBlockID[operation.blockConstantStringID]
                blockStates = ListBlockID[operation.blockStatesConstantStringID]
                block = Block(blockName, blockStates)
                SetArrayValue(block, Blocks, Position)
            elif Name in ["PlaceBlockWithBlockStates2"]:
                blockName = ListBlockID[operation.blockConstantStringID]
                blockStates = operation.blockStatesString
                block = Block(blockName, blockStates)
                SetArrayValue(block, Blocks, Position)
            elif Name in ["PlaceBlock"]:
                blockName = ListBlockID[operation.blockConstantStringID]
                blockData = operation.blockData
                block = Block(blockName, None, blockData)
                SetArrayValue(block, Blocks, Position)
            elif Name in ["PlaceBlockWithCommandBlockData"]:
                DataNBT = GetCommandNBT(operation)
                blockName = ListBlockID[operation.blockConstantStringID]
                blockData = operation.blockData
                block = Block(blockName, None, blockData, Mode="bdx", Type="BlockEntity", Name="Command", NBT=DataNBT)
                SetArrayValue(block, Blocks, Position)
            elif Name in ["UseRuntimeIDPool"]:
                if operation.pool == 117: RunTimeBlocks = RunTimeIds
            elif Name in ["PlaceRuntimeBlock", "placeBlockWithRuntimeId"]:
                Pool = RunTimeBlocks[operation.runtimeId]
                block = Block(Pool[0], None, Pool[1])
                SetArrayValue(block, Blocks, Position)
            elif Name in ["PlaceRuntimeBlockWithCommandBlockData", "PlaceRuntimeBlockWithCommandBlockDataAndUint32RuntimeID"]:
                DataNBT = GetCommandNBT(operation)
                Pool = RunTimeBlocks[operation.runtimeId]
                block = Block(Pool[0], None, Pool[1], Mode="bdx", Type="BlockEntity", Name="Command", NBT=DataNBT)
                SetArrayValue(block, Blocks, Position)
            elif Name in ["PlaceCommandBlockWithCommandBlockData"]:
                DataNBT = GetCommandNBT(operation)
                blockData = operation.data
                block = Block("command_block", None, blockData, Mode="bdx", Type="BlockEntity", Name="Command", NBT=DataNBT)
                SetArrayValue(block, Blocks, Position)
            elif Name in ["PlaceRuntimeBlockWithChestData", "PlaceRuntimeBlockWithChestDataAndUint32RuntimeID"]:
                Pool = RunTimeBlocks[operation.runtimeId]
                block = Block(Pool[0], None, Pool[1], Mode="bdx", Type="BlockEntity", Name="ChestData", NBT=ChestData)
                SetArrayValue(block, Blocks, Position)
            elif Name in ["PlaceBlockWithChestData"]:
                blockName = ListBlockID[operation.blockConstantStringID]
                blockData = ListBlockID[operation.blockData]
                block = Block(blockName, None, blockData, Mode="bdx", Type="BlockEntity", Name="ChestData", NBT=ChestData)
                SetArrayValue(block, Blocks, Position)
            elif Name in ["PlaceBlockWithNBTData"]:
                blockName = ListBlockID[operation.blockConstantStringID]
                blockStates = ListBlockID[operation.blockStatesConstantStringID]
                block = Block(blockName, blockStates, None, Mode="NBT", NBT=operation.nbt)
                SetArrayValue(block, Blocks, Position)
            elif Name in ["AddXValue"]:
                Position["x"] += 1
            elif Name in ["SubtractXValue"]:
                Position["x"] -= 1
            elif Name in ["AddInt8XValue", "AddInt16XValue", "AddInt32XValue"]:
                Position["x"] += operation.value
            elif Name in ["AddYValue"]:
                Position["y"] += 1
            elif Name in ["SubtractYValue"]:
                Position["y"] -= 1
            elif Name in ["AddInt8YValue", "AddInt16YValue", "AddInt32YValue"]:
                Position["y"] += operation.value
            elif Name in ["AddZValue", "SubtractZValue0"]:
                Position["z"] += 1
            elif Name in ["SubtractZValue"]:
                Position["z"] -= 1
            elif Name in ["AddInt8ZValue", "AddInt16ZValue", "AddInt32ZValue", "AddInt16ZValue0", "AddInt32ZValue0"]:
                Position["z"] += operation.value
            elif Name in ["Terminate"]:
                break
            else:
                raise Exception("没有匹配到任何操作")
        Size = GetArraySize(Blocks)
        return cls(Blocks, Size)

def WriteBDX(Path, BlocksPool):
    if not isinstance(BlocksPool, ParserBlocks): raise TypeError("不正确的方块池类型")
    Size = GetArraySize(BlocksPool.Blocks)
    Position = [0, 0, 0]
    BlockIDPool = []
    BlockStatesPool = []
    PlaceBlockPool = []
    for x, y, z in itertools.product(range(Size[0]),range(Size[1]),range(Size[2])):
        if (Block := GetArrayValue(BlocksPool.Blocks, {'x':x, 'y':y, 'z':z})):
            if (BlockBDX := Block.GetBDX(BlockIDPool, BlockStatesPool)):
                if (PosOperations := GetPosOperations(Position, [x, y, z])):
                    PlaceBlockPool += PosOperations
                    Position = [x, y, z]
                PlaceBlockPool.append(BlockBDX)
    File = bdx.BDX_File(Path, "wb")
    for ID in BlockIDPool: File.operation_list.append(bdx.OperationCode.CreateConstantString(ID))
    for States in BlockStatesPool: File.operation_list.append(bdx.OperationCode.CreateConstantString(States))
    File.operation_list += PlaceBlockPool
    File.save_as(Path)

def WriteMcstructure(Path, BlockPool):
    pass


