import os, sys, time, webbrowser, math, json, traceback, re, datetime
import tkinter as tk; import tkinter.filedialog, tkinter.messagebox
PackageLoadsErrorList = []
try:
    import main_source.package.python_nbt as nbt
    import main_source.package.python_bdx as bdx
    from main_source.bedrock_edition.command_class import CommandParser
except: PackageLoadsErrorList.append("软件包依赖项加载失败\n" + traceback.format_exc())
sys.path.append(os.path.realpath(os.path.join(__file__, os.pardir)))
try:
    import NBTeditConstants as Constants
    import MinecraftNBT as ClassNBT
    import ClassUI as ClassUI
    import Blocks as ClassBlocks
except: PackageLoadsErrorList.append("拓展包原生库加载失败\n" + traceback.format_exc())

class ImageLoadError(Exception): pass
class blockPoolLoadError(Exception): pass
class FileParserError(Exception): pass

class pack_class:
    def __init__(self): pass
    
    # 在实例化pack_class对象中，该方法是提供每0.5秒循环一次的功能。
    def loop_method(self): pass
    
    # 在实例化pack_class对象中，该方法是提供重启拓展包时执行代码的功能。
    def reload_method(self): pass
    
    # 在实例化pack_class对象中，该方法是提供离开拓展包界面时执行代码的功能。
    def exit_method(self): pass
    
    # 初始化
    def init(self, MainWin, MainWinFrame):
        self.MainWin = MainWin
        self.MainWinFrame = MainWinFrame
        
        self.MoveFrameClick = []
        self.MoveClass = []
        self.EditClass = []
        self.EditClassDestroyPool = []
        self.TaskFrameList = []
        self.Version = [1, 20, 0]
        self.ClipBoardList = [["空",None] for _ in range(6)]
        
        self.ClassBlocks = ClassBlocks
        self.Constants = Constants
        self.nbt = nbt
        try:
            self.LoadPicture()
            self.LoadBlockPool()
        except Exception:
            self.MainWinFrame.after(1000, lambda e: self.TraceError("Throw", "初始化加载错误", e), traceback.format_exc())
    
    # 加载图片
    def LoadPicture(self):
        self.Picture = {}
        for Name in Constants.LoadPictureList:
            try:
                Picture = tk.PhotoImage(file=f'{Constants.NBTeditPath}picture/{Name[1]}_90.png')
                if self.MainWin.platform == "windows": self.Picture[Name[1]] = Picture.subsample(Name[0]*2, Name[0]*2)
                if self.MainWin.platform == "android": self.Picture[Name[1]] = Picture
            except:
                try:
                    Picture = tk.PhotoImage(file=f'{Constants.NBTeditPath}picture/{Name[1]}.png')
                    if self.MainWin.platform == "windows": self.Picture[Name[1]] = Picture.subsample(Name[0], Name[0])
                    if self.MainWin.platform == "android": self.Picture[Name[1]] = Picture.zoom(Name[0], Name[0]) # *** 可能有适配问题
                except:
                    raise ImageLoadError(f"图片加载错误 {Name}，请检查Picture内的图片")
    
    # 加载BDX方块池
    def LoadBlockPool(self):
        try:
            with open(f"{Constants.NBTeditPath}BlockPool/RunTimeIds.json") as file:
                BlockPool = json.loads(file.read())
        except:
            raise blockPoolLoadError("方块池加载错误，请检查BlockPool内的文件")
        self.BlockPool = BlockPool
    
    # 获取一个装饰器，跟踪错误方法或抛出错误
    def TraceError(self, Mode="Function", ErrorText="捕获未知错误", Method=None, *args):
        def ThrowError(Text, Error):
            ClassUI.PromptUI(self, f"{Text}：日志已保存\n$#9c1414Error:\n    {Error}")
            Time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M")
            with open(f"{Constants.NBTeditPath}log/{Time}.log", "a") as File:
                File.write(Error)
        def Decorator(Function):
            def DecoratorFunction(*args, **kwargs):
                try: return Function(*args, **kwargs)
                except Exception: ThrowError(ErrorText, traceback.format_exc())
            return DecoratorFunction
        if Mode == "Function": return Decorator
        if Mode == "Method":
            try: Return = Method(*args); return Return
            except Exception: ThrowError(ErrorText, traceback.format_exc())
        if Mode == "Throw": ThrowError(ErrorText, Method)
    
    # 设置一个移动函数
    def GetMoveFrame(self, MoveCanvas, WinWidth, Mode, Width):
        class MoveClass:
            def __init__(self, MainPack, MoveCanvas, WinWidth, Mode, Width):
                self.MainPack, self.MoveCanvas, self.WinWidth, self.Mode, self.Width = MainPack, MoveCanvas, WinWidth, Mode, Width
                self.isMove = True
                self.ClickCommand = True
            def AddMoveFrame(self, MainMove, command=None, Mode=None):
                def on_release_click(event):
                    if self.isMove and command and not Mode: command()
                    if self.isMove and command and Mode: command(event.widget)
                def on_canvas_click(event):
                    self.isMove = True
                    self.MoveCanvas.scan_mark(event.x_root-self.MoveCanvas.winfo_rootx(), event.y_root-self.MoveCanvas.winfo_rooty())
                    self.MoveCanvas.config(scrollregion=(0, 0, self.MoveCanvas.bbox(self.WinWidth)[2]+self.Width, self.MoveCanvas.bbox(self.WinWidth)[3]+self.Width))
                    for ClickCommand in self.MainPack.MoveFrameClick:
                        try:
                            ClickCommand()
                        except Exception:
                            ClassUI.PromptUI(self, f"创建编辑菜单失败\n$#9c1414Error:\n    {traceback.format_exc()}")
                def on_canvas_drag(event):
                    self.isMove = False
                    if self.Mode == "x": self.MoveCanvas.scan_dragto(event.x_root-self.MoveCanvas.winfo_rootx(), 0, gain=1)
                    if self.Mode == "xy": self.MoveCanvas.scan_dragto(event.x_root-self.MoveCanvas.winfo_rootx(), event.y_root-self.MoveCanvas.winfo_rooty(), gain=1)
                MainMove.bind("<ButtonPress-1>", on_canvas_click)
                MainMove.bind("<B1-Motion>", on_canvas_drag)
                MainMove.bind("<ButtonRelease>",on_release_click)
            def ReCanvas(self, Command):
                self.ClickCommand.append(Command)
        self.MoveClass.append(MoveClass(self, MoveCanvas, WinWidth, Mode, Width))
        return self.MoveClass[-1]
    
    # 绑定事件
    def AddMoveFrameClick(self, Command):
        self.MoveFrameClick.append(Command)
    
    # 绑定事件执行
    def RunCommandMoveFrame(self):
        for ClickCommand in self.MoveFrameClick: ClickCommand()
    
    # 输入框绑定事件
    def SetInput(self, Entry):
        Entry.bind("<FocusIn>",lambda a :self.MainWin.set_focus_input(a))
    
    # 用数字索引获取图片名
    def GetPictureName(self, Number):
        return list(self.Picture.keys())[Number]
    
    # 用数字索引获取图片
    def GetPicture(self, Number):
        return self.Picture[list(self.Picture.keys())[Number]]
    
    # 获取一个属性(用于设置像素)
    def GetInt(self, Number):
        return Number if self.MainWin.platform == "android" else Number//3.6
    
    # 获取一个UI
    def GetUI(self, Name):
        return self.TraceError("Method", "获取UI类失败", getattr, ClassUI, Name)
    
    # 根据序号和数据获取一个nbt
    def GetNBT(self, Number, Data=None):
        Class = list(nbt.TAGLIST.values())[Number]
        if Data and Number in [1, 2, 3, 4]: return Class(int(Data))
        if Data and Number in [5, 6]: return Class(float(Data))
        if Data and Number in [8]: return Class(str(Data))
        if Data and Number in [7, 11, 12]: return
        if Data and Number in [9]: return
        if Data and Number in [10]: return
        return Class()
    
    # 根据方块ID，方块特殊值，方块状态获取一个图片
    def GetBlockPicture(self, BlockID, BlockData=None, BlockStates=None, BlockNBT=None):
        if BlockID in ["command_block", "chain_command_block", "repeating_command_block"]:
            return self.Picture[Constants.CommandBlockMap[str(BlockNBT["LPCommandMode"])][BlockData]]
        return self.Picture["Block"]
    
    # 解析文件
    def ParserFile(self, Path):
        Format = Path.split("/")[-1].split(".")[-1]
        with open(Path, "rb") as File:
            Data = File.read()
        if Format == "bdx":
            Data = ClassBlocks.ParserBlocks.FromBDX(bdx.BDX_File(Path, "rb"), self.BlockPool)
        elif Format == "mcstructure":
            Data = nbt.read_from_nbt_file(Data, False, "little")
        elif Format == "dat":
            Data = nbt.read_from_nbt_file(Data[8:], False, "little")
        elif Format == "nbt":
            Data = nbt.read_from_nbt_file(Data, "big")
        else:
            try: Data = ClassBlocks.ParserBlocks.FromBDX(bdx.BDX_File(Path, "rb"), self.BlockPool)
            except:
                try: Data = nbt.read_from_nbt_file(Data, "little")
                except:
                    try: Data = nbt.read_from_nbt_file(Data[8:], "little")
                    except:
                        try: Data = nbt.read_from_nbt_file(Data, "big")
                        except: raise FileParserError("解析错误: 自动匹配没有匹配到任何格式\n请尝试添加后缀")
        return Format, Data
    
    # 编译文件
    def WriteFile(self, Path, Type, Data):
        if Type == "mcstructure":
            nbt.write_to_nbt_file(Path, Data, False, "little")
        if Type == "nbt":
            nbt.write_to_nbt_file(Path, Data, True, "big")
        if Type == "bdx":
            ClassBlocks.WriteBDX(Path, Data)
        return
    
    # 检查语法
    def GrammarParser(self, Data, Back=None):
        ResList = []
        PosList = []
        Version = (self.Version[0], self.Version[1], self.Version[2])
        @self.TraceError("Function", "语法检测失败")
        def Task(Number):
            Number -= 1
            y = Number // (Data.Size[0] * Data.Size[2])
            Number -= y * Data.Size[0] * Data.Size[2]
            z = Number // Data.Size[0]
            x = Number % Data.Size[0]
            Block = ClassBlocks.GetArrayValue(Data.Blocks, {'x': x, 'y': y, 'z': z})
            if Block == None: return
            if Block.BlockID not in ['command_block', 'chain_command_block', 'repeating_command_block']: return
            Error = CommandParser.Start_Tokenizer(Block.BlockNBT['Command'].value, Version)
            if isinstance(Error, tuple):
                String1 = Block.BlockNBT['Command'].value[:Error[1].pos[0]] + '       '
                String2 = Block.BlockNBT['Command'].value[Error[1].pos[0]:Error[1].pos[1]]
                String3 = Block.BlockNBT['Command'].value[Error[1].pos[1]:] + '       '
                String = String1[:7] + '$#9c1414>' + String2 + '<$#ffffff' + String3[:7]
                ResList.append(String + f" 位于:{Error[1].pos[0]}~{Error[1].pos[1]}, 坐标:{x},{y},{z}\n")
                PosList.append({'x': x, 'y': y, 'z': z})
        @self.TraceError("Function", "语法检测返回失败")
        def Res():
            if len(ResList):
                ClassUI.PromptUI(self, f"版本：{self.Version}\n$#9c1414发现错误:\n$#ffffff" + ''.join(ResList))
                Back(PosList)
            else: ClassUI.PromptUI(self, f"版本：{self.Version}\n没有发现语法错误")
        Number = Data.Size[0]*Data.Size[1]*Data.Size[2]
        if Number < 1: return
        ClassUI.TaskUI(self, Task, Res, Number, "正在检测命令语法")
    
    # 检测字符串是否合法
    def TestString(self, Mode, String):
        if Mode == "Block":
            return re.match(r'^(\w+\:)?[\w\.]+$', String)
    
    # 菜单栏
    def Tool(self, Number):
        self.RunCommandMoveFrame()
        if Number == 1:
            file = tk.filedialog.askopenfilename()
            if file: self.EditClass.append(ClassUI.EditFrame(self, file, self.Edit, self.WinFrame))
        if Number == 2:
            for Class in self.EditClass:
                if Class.EditShow and Class.Name == "    引导    ": return
                elif Class.EditShow: break
            @self.TraceError("Function", "保存失败")
            def Return(Name, Type):
                if Type in ["dat", "json"]: ClassUI.PromptUI(self, "$#ffffff还没做完"); return
                Path = tk.filedialog.asksaveasfilename(initialfile="保存文件", defaultextension="", filetypes=[("所有文件", ".*"),("NBT", ".nbt"), ("Structure", ".mcstructure"), ("BDX", ".bdx"), ("DAT", ".dat"), ("JSON", ".json")])
                Path = '/'.join(Path.split("/")[:-1])+'/'+Name+'.'+Type
                File = self.WriteFile(Path, Type, Class.GetData())
            ClassUI.SaveUI(self, Return)
        if Number == 3:
            ClassUI.PromptUI(self, "$#ffffff还没做完")
        if Number == 4:
            for Class in self.EditClass:
                if Class.EditShow:
                    try: self.GrammarParser(Class.Data, Class.UI.SetError)
                    except Exception: self.TraceError("Throw", "语法检查启动失败", f"{traceback.format_exc()}")
        if Number == 5:
            self.ClipBoard.Click()
        if Number == 6:
            def SetVersion(Data):
                try:
                    Data = Data.split(",")
                    self.Version[0] = int(Data[0])
                    self.Version[1] = int(Data[1])
                    self.Version[2] = int(Data[2])
                except Exception:
                    ClassUI.PromptUI(self, f"错误的格式\n$#9c1414Error:\n    {traceback.format_exc()}")
            ClassUI.EntryUI(self, "输入版本", SetVersion, ','.join(map(str, self.Version)))
    
    
def UI_set(main_win, tkinter_Frame):
    # 检查错误并抛出
    for Error in PackageLoadsErrorList:
        Time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M")
        with open(f"expand_pack/NBTedit/log/{Time}.log", "a") as File: File.write(Error)
        tk.messagebox.showerror("Error", f"日志已保存:\n{Error}")
    # 主包初始化
    MainPack = main_win.get_expand_pack_class_object("319ceabd-6c86-48de-ba63-349c86baaf75")
    MainPack.init(main_win, tkinter_Frame)
    # 主布局
    MainFrame = tk.Frame(tkinter_Frame, width=MainPack.GetInt(1080), height=MainPack.GetInt(1993), bg="#2B303B")
    MainFrame.pack_propagate(0); MainFrame.pack(fill="both")
    # 帮助
    def ToHelp(): webbrowser.open("http://localhost:32323/?pack=319ceabd-6c86-48de-ba63-349c86baaf75&page=help")
    # 顶栏
    TopFrame = tk.Frame(MainFrame, bg="grey")
    tk.Button(TopFrame,text="帮助",fg='black',width=70,height=1,bg="grey",borderwidth=0,highlightthickness=0,command=ToHelp,image=MainPack.Picture["Help"],compound="top").pack(side="left",fill="both")
    TitleText = tk.Label(TopFrame,text="NBT编辑器",fg='black',font=('',20),width=12,height=1,bg="grey"); TitleText.bind("<ButtonPress-1>", lambda a: MainPack.RunCommandMoveFrame()); TitleText.pack(side="left")
    tk.Button(TopFrame,text="功能",fg='black',width=200,height=1,bg="grey",borderwidth=0,highlightthickness=0,command=lambda: MainPack.ToolMenu.Click(),image=MainPack.Picture["ToolMenu"],compound="top").pack(side="left",fill="both")
    TopFrame.pack(fill="x")
    # 功能
    MainPack.ToolMenu = MainPack.TraceError("Method", "菜单加载失败", ClassUI.ToolMenu, MainPack)
    # 文件列表栏
    ListFrame = tk.Frame(MainFrame, bg="#2B303B")
    ListCanVas = tk.Canvas(ListFrame, height=MainPack.GetInt(110), scrollregion=(0, 0, 0, 0), bg="#2B303B")
    ListCanVas.pack()
    WinFrame = tk.Frame(ListCanVas, bg="#2B303B")
    ListWidth = ListCanVas.create_window(MainPack.GetInt(10), MainPack.GetInt(10),anchor="nw", window=WinFrame)
    MainPack.GetMoveFrame(ListCanVas, ListWidth, "x", 10).AddMoveFrame(ListCanVas)
    ListFrame.pack(fill="x")
    # 编辑器界面
    Edit = tk.Frame(MainFrame, bg="#2B303B",height=MainPack.GetInt(1740))
    Edit.pack(fill="both")
    # 粘贴板
    MainPack.ClipBoard = MainPack.TraceError("Method", "剪切板加载失败", ClassUI.ClipBoard, MainPack)
    
    MainPack.Edit = Edit
    MainPack.WinFrame = WinFrame
    
    MainPack.EditClass.append(ClassUI.EditFrame(MainPack, "    引导    ", Edit, WinFrame))
    
    