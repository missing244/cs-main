from .FrameUI import FrameUI
import tkinter as tk
import traceback, json, copy

class SetNBT(FrameUI):
    def __init__(self, MainPack, LastFrame):
        super().__init__(MainPack)
        self.MainFrame = tk.Frame(MainPack.MainWinFrame, bg="#151515", bd=self.MainPack.GetInt(50))
        self.LastFrame = LastFrame
        self.StringValue = tk.StringVar()
        
        if self.LastFrame.Type in ["Root", "Key", "ListKey", "Value", "ListValue"]: self._SetTopTool()
        if self.LastFrame.Type in ["Root", "Key", "ListKey", "Value", "ListValue"]: self._SetNBType()
        if self.LastFrame.Type in ["Root", "Key", "Value", "ListValue", "ValueNBT"]: self._SetValue()
        if self.LastFrame.Type in ["Root", "Key", "ListKey"]: self._SetListType()
        # if isinstance(self.LastFrame.ListUI, (dict, list)): self._SetListType()
        self.Reset()
        
        tk.Button(self.MainFrame, text="确定保存", bg="#151515", fg="#ffffff", command=self.Save).pack(side="bottom")
        tk.Button(self.MainFrame, text="取消返回", bg="#151515", fg="#ffffff", command=self.Hide).pack(side="bottom")
        self.Show()
        MainPack.AddMoveFrameClick(self.Hide)
    
    def _SetTopTool(self):
        self.TopTool = tk.Frame(self.MainFrame, bg="#151515", bd=self.MainPack.GetInt(15), highlightthickness=0)
        self.TopTool.pack()
        tk.Button(self.TopTool, bg="#151515",fg="#ffffff", bd=0, text="复制",font=("",6), width=self.MainPack.GetInt(20), compound="top", image=self.MainPack.Picture["Copy"], command=self.NBTCopy).pack(side="left")
        tk.Button(self.TopTool, bg="#151515",fg="#ffffff", bd=0, text="粘贴",font=("",6), width=self.MainPack.GetInt(20), compound="top", image=self.MainPack.Picture["Paste"], command=self.NBTPaste).pack(side="left")
        tk.Button(self.TopTool, bg="#151515",fg="#ffffff", bd=0, text="剪切",font=("",6), width=self.MainPack.GetInt(20), compound="top", image=self.MainPack.Picture["Cut"], command=self.NBTCut).pack(side="left")
        tk.Button(self.TopTool, bg="#151515",fg="#ffffff", bd=0, text="删除",font=("",6), width=self.MainPack.GetInt(20), compound="top", image=self.MainPack.Picture["Delete"], command=self.NBTDelete).pack(side="left")
    def _SetNBType(self):
        self.NBType = tk.Frame(self.MainFrame, bg="#151515", bd=self.MainPack.GetInt(20), highlightthickness=0)
        self.NBType.pack()
        tk.Label(self.NBType, text="改变当前标签类型", bg="#151515", fg="#ffffff", bd=0, highlightthickness=0).pack()
        ButtonList = tk.Frame(self.NBType, bg="#151515", bd=0, highlightthickness=0)
        ButtonList2 = tk.Frame(self.NBType, bg="#151515", bd=0, highlightthickness=0)
        ButtonList.pack(); ButtonList2.pack()
        for i in range(0, 6): tk.Button(ButtonList, image=self.MainPack.GetPicture(i), command=lambda i=i: self.ChangeNBType(i)).pack(side="left")
        for i in range(6, 12): tk.Button(ButtonList2, image=self.MainPack.GetPicture(i), command=lambda i=i: self.ChangeNBType(i)).pack(side="left")
    def _SetValue(self):
        self.Value = tk.Frame(self.MainFrame, bg="#151515", bd=self.MainPack.GetInt(15), highlightthickness=0)
        self.Value.pack()
        tk.Label(self.Value, text="值:", font=("",10), fg="#ffffff", bg="#151515").pack(side="left")
        self.Entry = tk.Entry(self.Value, textvariable=self.StringValue, fg="#ffffff", bg="#151515", insertbackground="#ffffff")
        self.MainPack.SetInput(self.Entry)
        self.Entry.pack(side="left",fill="both")
    def _SetListType(self):
        self.ListType = tk.Frame(self.MainFrame, bg="#151515", bd=self.MainPack.GetInt(20), highlightthickness=0)
        self.ListType.pack()
        tk.Label(self.ListType, text="添加标签到当前元素内", bg="#151515", fg="#ffffff", bd=0, highlightthickness=0).pack()
        ButtonList = tk.Frame(self.ListType, bg="#151515", bd=0, highlightthickness=0)
        ButtonList2 = tk.Frame(self.ListType, bg="#151515", bd=0, highlightthickness=0)
        ButtonList.pack(); ButtonList2.pack()
        for i in range(0, 6): tk.Button(ButtonList, image=self.MainPack.GetPicture(i), command=lambda i=i: self.ChangeListType(i)).pack(side="left")
        for i in range(6, 12): tk.Button(ButtonList2, image=self.MainPack.GetPicture(i), command=lambda i=i: self.ChangeListType(i)).pack(side="left")
    
    def Reset(self):
        if self.LastFrame.Type in ["Root"]: self.StringValue.set(self.LastFrame.RootFrame.Name)
        if self.LastFrame.Type in ["Key", "ListKey", "Value"]: self.StringValue.set(self.LastFrame.Path[-1])
        if self.LastFrame.Type in ["ListValue", "ValueNBT"]: self.StringValue.set(self.LastFrame.GetNBT().value)
    
    def Save(self):
        Value = self.StringValue.get()
        try:
            if self.LastFrame.Type in ["Root", "Key", "ListKey", "Value"]:
                self.LastFrame.SetNBT(Value, "Name")
            if self.LastFrame.Type in ["ValueNBT", "ListValue"]:
                NBT = self.LastFrame.GetNBT()
                if NBT.id in [1, 2, 3, 4]: NBT.value = int(Value)
                if NBT.id in [5, 6]: NBT.value = float(Value)
                if NBT.id in [8]: NBT.value = Value
                self.LastFrame.SetNBT(NBT)
        except Exception :
            self.MainPack.TraceError("Throw", "保存错误", f"{traceback.format_exc()}")
            self.Hide()
            return
        self.Hide()
    
    def ChangeNBType(self, Number):
        @self.MainPack.TraceError("Function", "改变标签类型失败")
        def Run(Number):
            NBT = self.MainPack.GetNBT(Number+1)
            self.LastFrame.SetNBT(NBT)
            self.Hide()
        Run(Number)
    
    def ChangeListType(self, Number):
        @self.MainPack.TraceError("Function", "添加标签失败")
        def Run(Number):
            NBT = self.LastFrame.GetNBT()
            if NBT.id in [7, 9, 11, 12]: NBT.append(self.MainPack.GetNBT(Number+1))
            if NBT.id in [10]: NBT['第'+str(len(list(NBT.keys()))+1)+'个元素'] = self.MainPack.GetNBT(Number+1)
            self.LastFrame.SetNBT(NBT)
            self.Hide()
        Run(Number)
    
    def NBTCopy(self):
        ClipBoardName = f"NBT:{self.StringValue.get()}"
        self.MainPack.ClipBoardList.pop(0)
        self.MainPack.ClipBoardList.insert(5, [ClipBoardName,copy.deepcopy(self.LastFrame.GetNBT())])
        self.MainPack.ClipBoard.ResetString()
        def Res(): self.MainPack.ClipBoard.Show(False)
        self.MainPack.GetUI("ClipBoardAnim")(self.MainPack, Res)
        self.Close()
    def NBTPaste(self):
        if self.LastFrame.Type == "Root": return
        NBT = self.MainPack.ClipBoardList[5][1]
        if not isinstance(NBT, tuple(self.MainPack.nbt.TAGLIST.values())): return
        try: self.LastFrame.SetNBT(copy.deepcopy(NBT))
        except: self.MainPack.TraceError("Throw", "粘贴错误", f"{traceback.format_exc()}")
        self.Hide()
    def NBTCut(self):
        if self.LastFrame.Type == "Root": return
        ClipBoardName = f"NBT:{self.StringValue.get()}"
        self.MainPack.ClipBoardList.pop(0)
        self.MainPack.ClipBoardList.insert(5, [ClipBoardName,copy.deepcopy(self.LastFrame.GetNBT())])
        self.MainPack.ClipBoard.ResetString()
        def Res(): self.MainPack.ClipBoard.Show(False)
        self.MainPack.GetUI("ClipBoardAnim")(self.MainPack, Res)
        try: self.LastFrame.DelNBT()
        except: self.MainPack.TraceError("Throw", "删除错误", f"{traceback.format_exc()}")
        self.Close()
    def NBTDelete(self):
        if self.LastFrame.Type == "Root": return
        try: self.LastFrame.DelNBT()
        except: self.MainPack.TraceError("Throw", "删除错误", f"{traceback.format_exc()}")
        self.Hide()
    
    def Show(self):
        width, height, x, y = 0, 0, 0.5, 0.5
        def Show():
            nonlocal width, height, x, y
            if width < 0.76: width += 0.025
            if height < 0.6: height += 0.02
            if x > 0.12: x -= 0.0126
            if y > 0.2: y -= 0.01
            if width < 0.76: self.MainFrame.after(5, Show)
            self.MainFrame.place(relwidth=width,relheight=height,relx=x,rely=y)
        Show()
    
    def Hide(self):
        width, height, x, y = 0.76, 0.6, 0.12, 0.2
        def Hide():
            nonlocal width, height, x, y
            if width > 0: width -= 0.025
            if height > 0: height -= 0.02
            if x < 0.5: x += 0.0126
            if y < 0.5: y += 0.01
            if width > 0:
                self.MainFrame.place(relwidth=width,relheight=height,relx=x,rely=y)
                self.MainFrame.after(5, Hide)
            else:
                self.Close()
        Hide()
    
    def Close(self):
        self.MainFrame.destroy()
        del self.MainPack.MoveFrameClick[self.MainPack.MoveFrameClick.index(self.Hide)]

