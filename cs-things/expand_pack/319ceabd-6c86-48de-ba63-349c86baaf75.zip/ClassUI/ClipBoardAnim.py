from .FrameUI import FrameUI
import tkinter as tk

class ClipBoardAnim(FrameUI):
    def __init__(self, MainPack, Res):
        super().__init__(MainPack)
        from .FrameUI import FrameUI
        self.MainFrame = tk.Frame(MainPack.MainWinFrame, bg="#151515", bd=self.MainPack.GetInt(50))
        self.Start(Res)
    
    def Start(self, Res):
        width, height, x, y = 0.76, 0.6, 0.12, 0.2
        def Start():
            nonlocal width, height, x, y
            if width > 0.2: width -= 0.0186
            if height > 0.1: height -= 0.0166
            if x < 0.8: x += 0.0226
            if y < 0.9: y += 0.0233
            if width > 0.2 or height > 0.1 or x < 0.8 or y < 0.9:
                self.MainFrame.place(relwidth=width,relheight=height,relx=x,rely=y)
                self.MainFrame.after(10, Start)
            else:
                Res()
                self.Close()
        Start()
    
    def Close(self):
        self.MainFrame.destroy()