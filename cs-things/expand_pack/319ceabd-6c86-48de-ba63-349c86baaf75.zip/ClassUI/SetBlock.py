from .FrameUI import FrameUI
import tkinter as tk
import traceback, json

class SetBlock(FrameUI):
    def __init__(self, MainPack, RootFrame, Position):
        super().__init__(MainPack)
        self.MainFrame = tk.Frame(MainPack.MainWinFrame, bg="#151515", bd=self.MainPack.GetInt(50))
        self.RootFrame = RootFrame
        self.Position = Position
        self.Block = MainPack.ClassBlocks.GetArrayValue(RootFrame.Data.Blocks, {'x':Position[0], 'y':Position[1], 'z':Position[2]})
        if not self.Block: self.Block = MainPack.ClassBlocks.Block()
        
        self.StringID = tk.StringVar()
        self.StringData = tk.StringVar()
        self.StringStates = tk.StringVar()
        self.StringID.set(self.Block.BlockID)
        self.StringData.set(self.Block.BlockData)
        self.StringStates.set(self.Block.BlockStates)
        
        
        self._SetTopTool()
        self._SetBlockID()
        self._SetBlockData()
        self._SetBlockState()
        self._SetBlockNBT()
        self._SetBlockInfo()
        
        
        tk.Button(self.MainFrame, text="确定保存", bg="#151515", fg="#ffffff", command=self.Save).pack(side="bottom")
        tk.Button(self.MainFrame, text="取消返回", bg="#151515", fg="#ffffff", command=self.Hide).pack(side="bottom")
        self.Show()
        MainPack.AddMoveFrameClick(self.Hide)
    
    def _SetTopTool(self):
        self.TopTool = tk.Frame(self.MainFrame, bg="#151515", bd=self.MainPack.GetInt(20), highlightthickness=0)
        self.TopTool.pack()
        tk.Button(self.TopTool, bg="#151515",fg="#ffffff", bd=0, text="复制",font=("",6), width=self.MainPack.GetInt(20), compound="top", image=self.MainPack.Picture["Copy"], command=self.BlockCopy).pack(side="left")
        tk.Button(self.TopTool, bg="#151515",fg="#ffffff", bd=0, text="粘贴",font=("",6), width=self.MainPack.GetInt(20), compound="top", image=self.MainPack.Picture["Paste"], command=self.BlockPaste).pack(side="left")
        tk.Button(self.TopTool, bg="#151515",fg="#ffffff", bd=0, text="剪切",font=("",6), width=self.MainPack.GetInt(20), compound="top", image=self.MainPack.Picture["Cut"], command=self.BlockCut).pack(side="left")
        tk.Button(self.TopTool, bg="#151515",fg="#ffffff", bd=0, text="删除",font=("",6), width=self.MainPack.GetInt(20), compound="top", image=self.MainPack.Picture["Delete"], command=self.BlockDelete).pack(side="left")
    def _SetBlockID(self):
        self.BlockID = tk.Frame(self.MainFrame, bg="#151515", bd=self.MainPack.GetInt(20), highlightthickness=0)
        self.BlockID.pack()
        tk.Label(self.BlockID, text="方块ID:", font=("",10), fg="#ffffff", bg="#151515").pack(side="left")
        self.EntryID = tk.Entry(self.BlockID, textvariable=self.StringID, fg="#ffffff", bg="#151515", insertbackground="#ffffff")
        self.MainPack.SetInput(self.EntryID)
        self.EntryID.pack(side="left",fill="both")
    def _SetBlockData(self):
        self.BlockData = tk.Frame(self.MainFrame, bg="#151515", bd=self.MainPack.GetInt(20), highlightthickness=0)
        self.BlockData.pack()
        tk.Label(self.BlockData, text="方块特殊值:", font=("",10), fg="#ffffff", bg="#151515").pack(side="left")
        self.EntryData = tk.Entry(self.BlockData, textvariable=self.StringData, fg="#ffffff", bg="#151515", insertbackground="#ffffff")
        self.MainPack.SetInput(self.EntryData)
        self.EntryData.pack(side="left",fill="both")
    def _SetBlockState(self):
        self.BlockStates = tk.Frame(self.MainFrame, bg="#151515", bd=self.MainPack.GetInt(20), highlightthickness=0)
        self.BlockStates.pack()
        tk.Label(self.BlockStates, text="方块状态:", font=("",10), fg="#ffffff", bg="#151515").pack(side="left")
        self.EntryStates = tk.Entry(self.BlockStates, textvariable=self.StringStates, fg="#ffffff", bg="#151515", insertbackground="#ffffff")
        self.MainPack.SetInput(self.EntryStates)
        self.EntryStates.pack(side="left",fill="both")
    def _SetBlockNBT(self):
        self.BlockNBT = tk.Frame(self.MainFrame, bg="#151515", bd=self.MainPack.GetInt(20), highlightthickness=0)
        self.BlockNBT.pack()
        tk.Label(self.BlockNBT, text="方块NBT:", font=("",9), fg="#ffffff", bg="#151515").pack(side="left")
        self.NBTCopy = tk.Button(self.BlockNBT, image=self.MainPack.Picture["Copy"], command=self.BlockNBTCopy, fg="#ffffff", bg="#151515")
        self.NBTPaste = tk.Button(self.BlockNBT, image=self.MainPack.Picture["Paste"], command=self.BlockNBTPaste, fg="#ffffff", bg="#151515")
        self.NBTCut = tk.Button(self.BlockNBT, image=self.MainPack.Picture["Cut"], command=self.BlockNBTCut, fg="#ffffff", bg="#151515")
        self.NBTDelete = tk.Button(self.BlockNBT, image=self.MainPack.Picture["Delete"], command=self.BlockNBTDelete, fg="#ffffff", bg="#151515")
        self.NBTGoto = tk.Button(self.BlockNBT, image=self.MainPack.Picture["Goto"], command=self.BlockNBTGoto, fg="#ffffff", bg="#151515")
        self.NBTCopy.pack(side="left",fill="both")
        self.NBTPaste.pack(side="left",fill="both")
        self.NBTCut.pack(side="left",fill="both")
        self.NBTDelete.pack(side="left",fill="both")
        self.NBTGoto.pack(side="left",fill="both")
    def _SetBlockInfo(self):
        self.BlockInfo = tk.Frame(self.MainFrame, bg="#151515", bd=self.MainPack.GetInt(20), highlightthickness=0)
        self.BlockInfo.pack()
        Data = "有" if self.Block.BlockData else "无"
        States = "有" if self.Block.BlockStates else "无"
        NBT = "有" if self.Block.BlockNBT else "无"
        tk.Label(self.BlockInfo, text=f"坐标\n{self.Position[0]}, {self.Position[1]}, {self.Position[2]}", font=("",7), bd=self.MainPack.GetInt(20), highlightthickness=1, fg="#ffffff", bg="#151515").pack(side="left")
        tk.Label(self.BlockInfo, text=f"特殊值\n{Data}", font=("",7), bd=self.MainPack.GetInt(20), highlightthickness=1, fg="#ffffff", bg="#151515").pack(side="left")
        tk.Label(self.BlockInfo, text=f"状态\n{States}", font=("",7), bd=self.MainPack.GetInt(20), highlightthickness=1, fg="#ffffff", bg="#151515").pack(side="left")
        tk.Label(self.BlockInfo, text=f"NBT\n{NBT}", font=("",7), bd=self.MainPack.GetInt(20), highlightthickness=1, fg="#ffffff", bg="#151515").pack(side="left")
    
    def Save(self):
        ID = self.StringID.get()
        Data = self.StringData.get()
        States = self.StringStates.get()
        try:
            TestID = self.MainPack.TestString("Block", ID) if not ID == "None" else None
            TestData = int(Data) if not Data == "None" else None
            TestStates = json.loads(States) if not States == "None" else None
        except Exception :
            self.MainPack.TraceError("Throw", "保存错误", f"{traceback.format_exc()}")
            self.Hide()
            return
        self.Block.BlockID = TestID.group() if TestID else None
        self.Block.BlockData = TestData if TestData else None
        self.Block.BlockStates = TestStates if TestStates else None
        self.MainPack.ClassBlocks.SetArrayValue(self.Block, self.RootFrame.Data.Blocks, {'x':self.Position[0], 'y':self.Position[1], 'z':self.Position[2]})
        self.Hide()
        self.RootFrame.ShowBlocks()
    
    def BlockCopy(self):
        ClipBoardName = f"B:{self.StringID.get()},{self.Position}"
        self.MainPack.ClipBoardList.pop(0)
        self.MainPack.ClipBoardList.insert(5, [ClipBoardName,self.Block])
        self.MainPack.ClipBoard.ResetString()
        def Res(): self.MainPack.ClipBoard.Show(False)
        self.MainPack.GetUI("ClipBoardAnim")(self.MainPack, Res)
        self.Close()
    def BlockPaste(self):
        Block = self.MainPack.ClipBoardList[5][1]
        if not isinstance(Block, self.MainPack.ClassBlocks.Block): Block = None
        self.MainPack.ClassBlocks.SetArrayValue(Block, self.RootFrame.Data.Blocks, {'x':self.Position[0], 'y':self.Position[1], 'z':self.Position[2]})
        self.Hide()
        self.RootFrame.ShowBlocks()
    def BlockCut(self):
        ClipBoardName = f"B:{self.StringID.get()},{self.Position}"
        self.MainPack.ClipBoardList.pop(0)
        self.MainPack.ClipBoardList.insert(5, [ClipBoardName,self.Block])
        self.MainPack.ClipBoard.ResetString()
        def Res(): self.MainPack.ClipBoard.Show(False)
        self.MainPack.GetUI("ClipBoardAnim")(self.MainPack, Res)
        self.MainPack.ClassBlocks.SetArrayValue(None, self.RootFrame.Data.Blocks, {'x':self.Position[0], 'y':self.Position[1], 'z':self.Position[2]})
        self.Close()
        self.RootFrame.ShowBlocks()
    def BlockDelete(self):
        self.MainPack.ClassBlocks.SetArrayValue(None, self.RootFrame.Data.Blocks, {'x':self.Position[0], 'y':self.Position[1], 'z':self.Position[2]})
        self.Hide()
        self.RootFrame.ShowBlocks()
    
    def BlockNBTCopy(self):
        ClipBoardName = f"NBT:{self.StringID.get()},{self.Position}"
        self.MainPack.ClipBoardList.pop(0)
        self.MainPack.ClipBoardList.insert(5, [ClipBoardName,self.Block.BlockNBT])
        self.MainPack.ClipBoard.ResetString()
        def Res(): self.MainPack.ClipBoard.Show(False)
        self.MainPack.GetUI("ClipBoardAnim")(self.MainPack, Res)
        self.Close()
    def BlockNBTPaste(self):
        NBT = self.MainPack.ClipBoardList[5][1]
        if not isinstance(NBT, self.MainPack.ClassBlocks.nbt.TAG_Compound): NBT = None
        self.Block.BlockNBT = NBT
        self.Hide()
    def BlockNBTCut(self):
        ClipBoardName = f"NBT:{self.StringID.get()},{self.Position}"
        self.MainPack.ClipBoardList.pop(0)
        self.MainPack.ClipBoardList.insert(5, [ClipBoardName,self.Block.BlockNBT])
        self.MainPack.ClipBoard.ResetString()
        def Res(): self.MainPack.ClipBoard.Show(False)
        self.MainPack.GetUI("ClipBoardAnim")(self.MainPack, Res)
        self.Block.BlockNBT = None
        self.Close()
    def BlockNBTDelete(self):
        self.Block.BlockNBT = None
        self.Hide()
    def BlockNBTGoto(self):
        if self.Block.BlockNBT is None: return
        self.MainPack.TraceError("Method", "创建编辑菜单失败", self.MainPack.EditClass.append, self.MainPack.GetUI("EditFrame")(self.MainPack, self.Block, self.MainPack.Edit, self.MainPack.WinFrame))
        self.Hide()
    
    def Show(self):
        width, height, x, y = 0, 0, 0.5, 0.5
        def Show():
            nonlocal width, height, x, y
            if width < 0.76: width += 0.025
            if height < 0.6: height += 0.02
            if x > 0.12: x -= 0.0126
            if y > 0.2: y -= 0.01
            if width < 0.76: self.MainFrame.after(5, Show)
            self.MainFrame.place(relwidth=width,relheight=height,relx=x,rely=y)
        Show()
    
    def Hide(self):
        width, height, x, y = 0.76, 0.6, 0.12, 0.2
        def Hide():
            nonlocal width, height, x, y
            if width > 0: width -= 0.025
            if height > 0: height -= 0.02
            if x < 0.5: x += 0.0126
            if y < 0.5: y += 0.01
            if width > 0:
                self.MainFrame.place(relwidth=width,relheight=height,relx=x,rely=y)
                self.MainFrame.after(5, Hide)
            else:
                self.Close()
        Hide()
    
    def Close(self):
        self.MainFrame.destroy()
        del self.MainPack.MoveFrameClick[self.MainPack.MoveFrameClick.index(self.Hide)]

