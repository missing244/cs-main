from .FrameUI import FrameUI
import tkinter as tk

class ClipBoard(FrameUI):
    def __init__(self, MainPack):
        super().__init__(MainPack)
        
        self.State = False
        self.ListState = False
        self.Relx, self.Rely, self.Width, self.Height = 1, 0.9, 0.18, 0.1
        self.StringList = [tk.StringVar() for _ in range(6)]
        
        self.MainFrame = tk.Frame(MainPack.MainWinFrame,bg="#151515",bd=5)
        
        self._SetBottomTool()
        self._SetList()
        self.ResetString()
        MainPack.AddMoveFrameClick(self.CloseList)
    
    def _SetBottomTool(self):
        self.BottomToolFrame = tk.Frame(self.MainFrame, bg="#151515")
        self.BottomToolFrame.pack(side="bottom",fill="x")
        tk.Button(self.BottomToolFrame,image=self.MainPack.Picture["ClipBoard"],fg="#ffffff",bg="#151515",bd=0,highlightthickness=1,command=lambda: self.ListClick()).pack(side="right")
        tk.Button(self.BottomToolFrame,text="隐藏",fg="#ffffff",bg="#151515",bd=0,highlightthickness=1,command=lambda: self.Hide()).pack(side="right",fill="both")
        tk.Label(self.BottomToolFrame,text=self.MainPack.Constants.ClipBoardText,font=("",5),fg="#ffffff",bg="#151515",bd=0,highlightthickness=1).pack(side="right",fill="both")
    
    def _SetList(self):
        self.ListFrame = tk.Frame(self.MainFrame, bg="#151515")
        self.ListFrame.pack()
        self.ListFrameList = []
        for i in range(6):
            self.ListFrameList.insert(i,tk.Frame(self.ListFrame, bg="#151515"))
            self.ListFrameList[i].pack(fill="x")
            Entry = tk.Entry(self.ListFrameList[i], textvariable=self.StringList[i], bg="#151515",insertbackground="#ffffff",fg="#ffffff",font=("",12),bd=0,highlightthickness=1,width=14)
            self.MainPack.SetInput(Entry) ;Entry.pack(side="left",fill="x")
            Button = tk.Button(self.ListFrameList[i], text=str(i), image=self.MainPack.Picture["NBTListOpen"],bg="#151515",bd=0,highlightthickness=1)
            Button.bind("<ButtonRelease>", self.SortList); Button.pack(side="left")
    
    def SortList(self, event):
        self.SaveList()
        Data = self.MainPack.ClipBoardList[int(event.widget.cget("text"))]
        self.MainPack.ClipBoardList.pop(int(event.widget.cget("text")))
        self.MainPack.ClipBoardList.insert(5, Data)
        self.ResetString()
    
    def ResetString(self):
        for i in range(6): self.StringList[i].set(self.MainPack.ClipBoardList[i][0])
    
    def SaveList(self):
        for i in range(6): self.MainPack.ClipBoardList[i][0] = self.StringList[i].get()
    
    def Click(self):
        if self.State: self.Hide()
        else: self.Show()
    
    def ListClick(self):
        if self.ListState: self.CloseList()
        else: self.OpenList()
    
    def GetSpeed(self, X, Y, W, H, S):
        SpeedX = abs(self.Relx-X)/S
        SpeedY = abs(self.Rely-Y)/S
        SpeedW = abs(self.Width-W)/S
        SpeedH = abs(self.Height-H)/S
        return [SpeedX, SpeedY, SpeedW, SpeedH]
    
    def ReSize(self, X, Y, W, H, SpeedX, SpeedY, SpeedW, SpeedH):
        if self.Relx > X: self.Relx -= SpeedX
        if self.Rely > Y: self.Rely -= SpeedY
        if self.Width > W: self.Width -= SpeedW
        if self.Height > H: self.Height -= SpeedH
        if self.Relx < X: self.Relx += SpeedX
        if self.Rely < Y: self.Rely += SpeedY
        if self.Width < W: self.Width += SpeedW
        if self.Height < H: self.Height += SpeedH
    
    def Show(self, Anim=True):
        self.State = True
        if not Anim:
            self.MainFrame.place(relwidth=0.17,relheight=0.09,relx=0.82,rely=0.9)
            return
        Speed = self.GetSpeed(0.82, 0.9, 0.17, 0.09, 15)
        n = 0
        def Show():
            nonlocal n, Speed
            n += 1
            self.ReSize(0.82, 0.9, 0.17, 0.09, *Speed)
            self.MainFrame.place(relwidth=self.Width,relheight=self.Height,relx=self.Relx,rely=self.Rely)
            if not self.State: return
            if n < 15: self.MainFrame.after(5, Show)
        Show()
    
    def Hide(self):
        self.SaveList()
        self.State = False
        self.ListState = False
        Speed = self.GetSpeed(1, 0.9, 0.17, 0.09, 15)
        n = 0
        def Hide():
            nonlocal n, Speed
            n += 1
            self.ReSize(1, 0.9, 0.17, 0.09, *Speed)
            self.MainFrame.place(relwidth=self.Width,relheight=self.Height,relx=self.Relx,rely=self.Rely)
            if self.State: return
            if n < 15: self.MainFrame.after(5, Hide)
        Hide()
    
    def OpenList(self):
        self.ListState = True
        Speed = self.GetSpeed(0.4, 0.6, 0.6, 0.4, 30)
        n = 0
        def Open():
            nonlocal n, Speed; n += 1
            self.ReSize(0.4, 0.6, 0.6, 0.4, *Speed)
            self.MainFrame.place(relwidth=self.Width,relheight=self.Height,relx=self.Relx,rely=self.Rely)
            if self.ListState and n < 30: self.MainFrame.after(5, Open)
            if n >= 30: self.MainFrame.place(relwidth=0.6,relheight=0.4,relx=0.4,rely=0.6)
        Open()
    
    def CloseList(self):
        self.SaveList()
        if not self.State: return
        self.ListState = False
        Speed = self.GetSpeed(0.82, 0.9, 0.17, 0.09, 30)
        n = 0
        def Close():
            nonlocal n, Speed; n += 1
            self.ReSize(0.82, 0.9, 0.17, 0.09, *Speed)
            self.MainFrame.place(relwidth=self.Width,relheight=self.Height,relx=self.Relx,rely=self.Rely)
            if not self.ListState and n < 30: self.MainFrame.after(5, Close)
            if n >= 30: self.MainFrame.place(relwidth=0.17,relheight=0.09,relx=0.82,rely=0.9)
        Close()
    







