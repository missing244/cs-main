from .FrameUI import FrameUI
import traceback
import tkinter as tk


class TaskUI(FrameUI):
    def __init__(self, MainPack, Task, Res, Number, Text="正在执行任务", Text2="取消"):
        super().__init__(MainPack)
        
        self.State = True
        self.ResetRelyState = False
        self.x=0
        self.Number = Number
        self.String = tk.StringVar()
        self.String.set(f"0/{self.Number}")
        self.MainFrame = tk.Frame(self.MainPack.MainWinFrame, bg="#151515", bd=self.MainPack.GetInt(20))
        tk.Label(self.MainFrame, text=" "*3+Text, bg="#151515", fg="#ffffff").pack(side="left")
        tk.Label(self.MainFrame, text=" "*3, bg="#151515", fg="#ffffff").pack(side="left")
        tk.Label(self.MainFrame, textvariable=self.String, bg="#151515", fg="#ffffff").pack(side="left")
        tk.Button(self.MainFrame, image=self.MainPack.Picture["Delete"], bg="#151515", command=self.Hide).pack(side="right")
        tk.Button(self.MainFrame, text=Text2, bg="#151515", fg="#ffffff", command=self.Close).pack(side="right")
        self.AddList()
        self.Show()
        self.RunTask(Task, Res)
    
    def AddList(self):
        self.MainPack.TaskFrameList.insert(0, self)
        self.Rely = 0.9-(0.1*self.MainPack.TaskFrameList.index(self))
        for i in range(len(self.MainPack.TaskFrameList)):
            if not self.MainPack.TaskFrameList[i-1].ResetRelyState: self.MainPack.TaskFrameList[i-1].ResetRely()
    
    def ResetRely(self):
        def ResetRely():
            self.ResetRelyState = True
            Index = self.MainPack.TaskFrameList.index(self)
            if self.Rely < 0.9-(0.1*Index): self.Rely += 0.01
            if self.Rely > 0.9-(0.1*Index): self.Rely -= 0.01
            self.MainFrame.place(relwidth=0.89,relheight=0.08,relx=self.x,rely=self.Rely)
            if not 0.9-(0.1*Index)-0.01 < self.Rely < 0.9-(0.1*Index)+0.01:
                self.MainFrame.after(20, ResetRely)
            else:
                self.ResetRelyState = False
        ResetRely()
    
    def RunTask(self, Task, Res):
        Pointer = 1
        @self.MainPack.TraceError("Function", "任务执行失败")
        def Run():
            nonlocal Pointer
            Task(Pointer)
            self.String.set(f"{Pointer}/{self.Number}")
            if Pointer < self.Number and self.State:
                Pointer += 1
                self.MainFrame.after(1, Run)
            else:
               self.String.set("任务结束")
               Res()
               self.Hide()
        Run()
    
    def Show(self):
        self.x = -1
        def Show():
            if self.x < 0: self.x += 0.04
            if self.x < 0: self.MainFrame.after(10, Show)
            self.MainFrame.place(relwidth=0.89,relheight=0.08,relx=self.x,rely=self.Rely)
        Show()
    
    def Hide(self):
        self.x = 0
        def Hide():
            if self.x > -1: self.x -= 0.04
            if self.x > -1:
                self.MainFrame.after(10, Hide)
                self.MainFrame.place(relwidth=0.89,relheight=0.08,relx=self.x,rely=self.Rely)
            else:
                del self.MainPack.TaskFrameList[self.MainPack.TaskFrameList.index(self)]
                self.MainFrame.destroy()
                for i in range(len(self.MainPack.TaskFrameList)):
                    self.MainPack.TaskFrameList[i-1].ResetRely()
        Hide()
    
    def Close(self):
        self.State = False