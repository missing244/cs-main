from .FrameUI import FrameUI
import traceback, math, json, copy
import tkinter as tk


class NBTagUI(FrameUI):
    def __init__(self, MainPack, RootFrame, LastFrame, Path):
        super().__init__(MainPack)
        self.RootFrame = RootFrame
        self.LastFrame = LastFrame
        
        self.StringName = tk.StringVar()
        self.StringPage = tk.StringVar()
        self.Path = Path
        self.Type = self.GetType()
        self.ListState = False
        self.ListPage = 1
        self.MaxListPage = 1
        
        self._SetUI()
        self.Reset()
        # self.Show()
        # self.PageFrame.pack()
    
    def GetPicture(self):
        Number = self.GetNBT().id
        return self.MainPack.Picture[self.MainPack.GetPictureName(Number-1)]
    
    def GetType(self):
        if isinstance(self.LastFrame, self.MainPack.GetUI("EditFrame")): return "Root"
        if not isinstance(self.LastFrame, self.MainPack.GetUI("NBTagUI")): raise Exception("上一层类型不正确")
        if isinstance(self.LastFrame.ListUI, dict) and self.GetNBT().id in [7, 9, 10, 11, 12]: return "Key"
        if isinstance(self.LastFrame.ListUI, list) and self.GetNBT().id in [7, 9, 10, 11, 12]: return "ListKey"
        if isinstance(self.LastFrame.ListUI, dict): return "Value"
        if isinstance(self.LastFrame.ListUI, list): return "ListValue"
        if self.LastFrame.ListUI is None: return "ValueNBT"
        raise Exception("类型异常")
    
    def _SetUI(self):
        self._SetMainFrame()
        if self.Type in ["Root", "Key", "ListKey", "Value", "ListValue"]: self._SetTag()
        if self.Type in ["Root", "Key", "ListKey", "Value", "ListValue", "ValueNBT"]: self._SetName()
        if self.Type in ["ValueNBT"]: self._SetEdit()
        if self.Type in ["Root", "Key", "ListKey", "Value"]: self._SetList()
        if self.Type in ["Root", "Key", "ListKey"]: self._SetPage()
        
    
    def _SetMainFrame(self):
        self.MainFrame = tk.Frame(self.LastFrame.SubFrame,bg="#898C8E",borderwidth=0,highlightthickness=0)
        self.SubFrame = tk.Frame(self.LastFrame.SubFrame,bg="#2B303B",borderwidth=0,highlightthickness=0)
        Line = tk.Frame(self.SubFrame, width=self.MainPack.GetInt(90), bg="#2B303B"); Line.pack(side="left",fill="y")
        self.RootFrame.SetMainEditMove.AddMoveFrame(self.MainFrame)
        self.RootFrame.SetMainEditMove.AddMoveFrame(self.SubFrame)
        self.RootFrame.SetMainEditMove.AddMoveFrame(Line)
    
    def _SetTag(self):
        self.TagButton = tk.Button(self.MainFrame, image=self.GetPicture(), bg="#898C8E",borderwidth=0,highlightthickness=0)
        self.TagButton.pack(side="left")
        # self.RootFrame.SetMainEditMove.AddMoveFrame(self.TagButton)
        self.RootFrame.SetMainEditMove.AddMoveFrame(self.TagButton, self.SetNBTUI)
        # self.SetMainEditMove(self.TagButton, self.SetNBTUI)
    
    def _SetName(self):
        self.Name = tk.Label(self.MainFrame, textvariable=self.StringName,bg="#898C8E",borderwidth=0,highlightthickness=0)
        self.Name.pack(side="left")
        self.RootFrame.SetMainEditMove.AddMoveFrame(self.Name)
    
    def _SetEdit(self):
        self.Edit = tk.Button(self.MainFrame, image=self.MainPack.Picture["Edit"], bg="#898C8E",borderwidth=0,highlightthickness=0)
        self.Edit.pack(side="left")
        # self.RootFrame.SetMainEditMove.AddMoveFrame(self.Edit)
        self.RootFrame.SetMainEditMove.AddMoveFrame(self.Edit, self.SetNBTUI)
    
    def _SetList(self):
        self.ListFrame = tk.Frame(self.MainFrame, bg="#898C8E",borderwidth=0,highlightthickness=0)
        # self.ListFrame = tk.Frame(self.MainFrame, width=self.MainPack.GetInt(90), height=self.MainPack.GetInt(90), bg="#898C8E",borderwidth=0,highlightthickness=0)
        # self.ListFrame.pack_propagate(0)
        self.ListFrame.pack(side="left")
        self.List = tk.Button(self.ListFrame, image=self.MainPack.Picture["NBTListOpen"], bg="#898C8E",borderwidth=0,highlightthickness=0)
        self.List.pack(side="left")
        self.RootFrame.SetMainEditMove.AddMoveFrame(self.List, self.ClickList)
    
    def _SetPage(self):
        self.PageFrame = tk.Frame(self.SubFrame,bg="#898C8E",borderwidth=0,highlightthickness=0)
        UpPage = tk.Button(self.PageFrame, bg="#393C3E", text="上一页")
        NextPage = tk.Button(self.PageFrame, bg="#393C3E", text="下一页")
        self.TextPage = tk.Label(self.PageFrame, textvariable=self.StringPage)
        UpPage.pack(side="left", fill="y")
        self.TextPage.pack(side="left")
        NextPage.pack(side="left", fill="y")
        self.RootFrame.SetMainEditMove.AddMoveFrame(UpPage, lambda: self.MovePage(-1))
        self.RootFrame.SetMainEditMove.AddMoveFrame(NextPage, lambda: self.MovePage(1))
        self.RootFrame.SetMainEditMove.AddMoveFrame(self.TextPage)
    
    def ClickList(self):
        @self.MainPack.TraceError("Function", "列表改变失败")
        def Run():
            if not hasattr(self, "ListUI"): self.InitList()
            if self.ListState: self.CloseList()
            else: self.OpenList()
        Run()
        self.Reset()
    
    def InitList(self):
        self.ListState = False
        NBT = self.GetNBT()
        if NBT.id in [10]:
            self.ListUI = {}
            for Key in NBT:
                Path = self.Path[:]; Path.append(Key)
                self.ListUI[Key] = self.MainPack.TraceError("Method", "创建列表失败", self.MainPack.GetUI("NBTagUI"), self.MainPack, self.RootFrame, self, Path)
            return
        if NBT.id in [7, 9, 11, 12]:
            self.ListUI = []
            for i in range(len(NBT)):
                Path = self.Path[:]; Path.append(i)
                self.ListUI.append(self.MainPack.TraceError("Method", "创建列表失败", self.MainPack.GetUI("NBTagUI"), self.MainPack, self.RootFrame, self, Path))
            return
        if NBT.id in [1, 2, 3, 4, 5, 6, 8]:
            self.ListUI = None
            Path = self.Path[:]
            self.ListUI = self.MainPack.TraceError("Method", "创建列表失败", self.MainPack.GetUI("NBTagUI"), self.MainPack, self.RootFrame, self, Path)
            return
        raise Exception("列表展开初始化失败")
    
    def OpenList(self):
        self.ListState = True
        MaxLen = self.MainPack.Constants.NBTagFrameMaxList
        if isinstance(self.ListUI, list): List = self.ListUI
        if isinstance(self.ListUI, dict): List = list(self.ListUI.values())
        if isinstance(self.ListUI, (dict, list)): self.ResetMaxPage()
        if isinstance(self.ListUI, (dict, list)) and len(List) >= MaxLen:
            self.PageFrame.pack()
            for i in range(MaxLen):
                try: List[self.ListPage*MaxLen-MaxLen+i].Show()
                except: pass
        if isinstance(self.ListUI, (dict, list)) and len(List) < MaxLen:
            for Frame in List: Frame.Show()
        if not isinstance(self.ListUI, (dict, list)): self.ListUI.Show()
        
    
    def CloseList(self):
        self.ListState = False
        if not hasattr(self, "ListUI"): return
        if isinstance(self.ListUI, list): List = self.ListUI
        if isinstance(self.ListUI, dict): List = list(self.ListUI.values())
        if isinstance(self.ListUI, (dict, list)):
            for Frame in List:
                Frame.CloseList()
                Frame.Hide()
                Frame.Reset()
            self.PageFrame.pack_forget()
        if not isinstance(self.ListUI, (dict, list)): self.ListUI.Hide()
    
    def MovePage(self, Number):
        self.ResetMaxPage()
        if Number == 1 and self.ListPage < self.MaxListPage: self.ListPage += 1
        if Number == -1 and self.ListPage > 1: self.ListPage -= 1
        self.Reset()
        self.ClickList()
        self.ClickList()
    
    def ResetMaxPage(self):
        MaxLen = self.MainPack.Constants.NBTagFrameMaxList
        if isinstance(self.ListUI, list): List = self.ListUI
        if isinstance(self.ListUI, dict): List = list(self.ListUI.values())
        self.MaxListPage = math.ceil(len(List)/MaxLen)
    
    def SetNBTUI(self):
        if not hasattr(self, "ListUI"): self.ClickList(); self.ClickList()
        self.MainPack.TraceError("Method", "创建编辑菜单失败", self.MainPack.GetUI("SetNBT"), self.MainPack, self)
    
    def Reset(self):
        if self.Type in ["Root", "Key", "ListKey", "Value", "ListValue"]: self.TagButton.config(image=self.GetPicture())
        if self.Type in ["Key", "Value"]: self.StringName.set(str(self.Path[-1]))
        if self.Type in ["ListValue", "ValueNBT"]: self.StringName.set("  "+str(self.GetNBT().value)+"  ")
        if self.Type in ["Root"]: self.StringName.set(" 根标签:"+self.RootFrame.Name+" ")
        if self.Type in ["Root", "Key", "ListKey", "Value"]: self.List.config(image=self.MainPack.Picture["NBTListOpen"] if not self.ListState else self.MainPack.Picture["NBTListClose"])
        self.StringPage.set(f"第{self.ListPage}页\n共{self.MaxListPage}页")
    
    def GetNBT(self):
        try:
            if not self.RootFrame.Type == 'bdx-nbt': Data = self.RootFrame.Data
            else: Data = self.RootFrame.Data.BlockNBT
            for Index in self.Path:
                Data = Data[Index]
            if Data is None: raise Exception("获取数据错误")
            return Data
        except Exception:
            self.MainPack.TraceError("Throw", "更改NBT错误", f"{traceback.format_exc()}")
    
    def SetNBT(self, Value, Mode="Value"):
        @self.MainPack.TraceError("Function", "获取NBT数据失败")
        def Run(Value, Mode):
            if not self.RootFrame.Type == 'bdx-nbt': Data = self.RootFrame.Data
            else: Data = self.RootFrame.Data.BlockNBT
            if Mode == "Name":
                if self.Type == "Root": return
                for Index in self.Path[:-1]: Data = Data[Index]
                Temp = Data[self.Path[-1]]
                del Data[self.Path[-1]]
                Data[Value] = Temp
                self.ChangePath(len(self.Path)-1, Value)
            if self.Type == "Root" and self.RootFrame.Type == 'bdx-nbt': self.RootFrame.Data.BlockNBT = Value
            if self.Type == "Root" and not self.RootFrame.Type == 'bdx-nbt': self.RootFrame.Data = Value
            if self.Type == "Root": self.CloseList()
            else: self.LastFrame.CloseList()
            if Mode == "Value" and not self.Type == "Root":
                for Index in self.Path[:-1]: Data = Data[Index]
                Data[self.Path[-1]] = Value
            if self.Type == "Root":
                del self.ListUI
                self.ClickList()
            else:
                del self.LastFrame.ListUI
                self.LastFrame.ClickList()
            if Data is None: raise Exception("数据设置错误")
        Run(Value, Mode)
    
    def DelNBT(self):
        @self.MainPack.TraceError("Function", "删除NBT数据失败")
        def Run():
            if self.Type == "Root": return
            if not self.RootFrame.Type == 'bdx-nbt': Data = self.RootFrame.Data
            else: Data = self.RootFrame.Data.BlockNBT
            for Index in self.Path[:-1]: Data = Data[Index]
            self.LastFrame.CloseList()
            del Data[self.Path[-1]]
            del self.LastFrame.ListUI
            self.LastFrame.ClickList()
        Run()
    
    def ChangePath(self, Number, Value):
        self.Path[Number] = Value
        if not hasattr(self, "ListUI"): return
        if isinstance(self.ListUI, list): List = self.ListUI
        if isinstance(self.ListUI, dict): List = list(self.ListUI.values())
        if isinstance(self.ListUI, (list, dict)):
            for UI in List: UI.ChangePath(Number, Value)
        if not isinstance(self.ListUI, (list, dict)): self.ListUI.ChangePath(Number, Value)
    
    def Show(self):
        self.MainFrame.pack(anchor="nw")
        self.SubFrame.pack(anchor="nw")
    
    def Hide(self):
        self.MainFrame.pack_forget()
        self.SubFrame.pack_forget()