from .FrameUI import FrameUI
import tkinter as tk

class PromptUI(FrameUI):
    def __init__(self, MainPack, RawText):
        super().__init__(MainPack)
        self.MainFrame = tk.Frame(MainPack.MainWinFrame, bg="#151515", bd=self.MainPack.GetInt(50))
        self.Text = tk.Text(self.MainFrame, width=64, bg="#151515", fg="#ffffff", bd=0, highlightthickness=0, font=("",6))
        self.Text.pack()
        tk.Label(self.MainFrame, text="<点击区域外返回>", bg="#151515", fg="#ffffff").pack(side="bottom")
        self.ParserRawText(RawText)
        self.Text.config(state="disabled")
        self.Show()
        MainPack.AddMoveFrameClick(self.Hide)
    
    def ParserRawText(self, RawText):
        List = RawText.split("$")
        if isinstance(List, str): List = [List]
        Index = 0
        for String in List:
            Index += 1
            if not String == "" and String[0] == "#":
                self.Text.insert("end", String[7:])
                self.Text.tag_add(str(Index), f"insert-{str(len(String)-7)}c", f"insert+{str(len(String)-7)}c")
                self.Text.tag_config(str(Index), foreground=String[0:7])
            else:
                self.Text.insert("end", String)
    
    def Show(self):
        width, height, x, y = 0, 0, 0.5, 0.5
        def Show():
            nonlocal width, height, x, y
            if width < 0.76: width += 0.025
            if height < 0.6: height += 0.02
            if x > 0.12: x -= 0.0126
            if y > 0.2: y -= 0.01
            if width < 0.76: self.MainFrame.after(5, Show)
            self.MainFrame.place(relwidth=width,relheight=height,relx=x,rely=y)
        Show()
    
    def Hide(self):
        width, height, x, y = 0.76, 0.6, 0.12, 0.2
        def Hide():
            nonlocal width, height, x, y
            if width > 0: width -= 0.025
            if height > 0: height -= 0.02
            if x < 0.5: x += 0.0126
            if y < 0.5: y += 0.01
            if width > 0:
                self.MainFrame.place(relwidth=width,relheight=height,relx=x,rely=y)
                self.MainFrame.after(5, Hide)
            else:
                self.Close()
        Hide()
    
    def Close(self):
        self.MainFrame.destroy()
        del self.MainPack.MoveFrameClick[self.MainPack.MoveFrameClick.index(self.Hide)]

