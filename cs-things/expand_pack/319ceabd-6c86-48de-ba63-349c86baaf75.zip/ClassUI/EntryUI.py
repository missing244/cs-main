from .FrameUI import FrameUI
import tkinter as tk


class EntryUI(FrameUI):
    def __init__(self, MainPack, Text, Command, EntryText=""):
        super().__init__(MainPack)
        self.Command = Command
        self.MainFrame = tk.Frame(MainPack.MainWinFrame, bg="#151515", bd=self.MainPack.GetInt(50))
        tk.Label(self.MainFrame, text=Text, bg="#151515", fg="#ffffff", bd=self.MainPack.GetInt(35), font=("",10)).pack()
        self.Entry = tk.Entry(self.MainFrame, width=64, bg="#151515", fg="#ffffff", font=("",10), insertbackground="#ffffff")
        self.Entry.insert(0, EntryText)
        self.MainPack.SetInput(self.Entry)
        self.Entry.pack()
        tk.Button(self.MainFrame, text="确定保存", bg="#151515", fg="#ffffff", command=self.Hide).pack(side="bottom")
        self.Show()
        MainPack.AddMoveFrameClick(self.Hide)
    
    def Show(self):
        width, height, x = 0, 0, 0.5
        def Show():
            nonlocal width, height, x
            if width < 0.76: width += 0.025
            if height < 0.3: height += 0.02
            if x > 0.12: x -= 0.0126
            if width < 0.76: self.MainFrame.after(5, Show)
            self.MainFrame.place(relwidth=width,relheight=height,relx=x,rely=0.2)
        Show()
    
    def Hide(self):
        width, height, x = 0.76, 0.3, 0.12
        def Hide():
            nonlocal width, height, x
            if width > 0: width -= 0.025
            if height > 0: height -= 0.02
            if x < 0.5: x += 0.0126
            if width > 0:
                self.MainFrame.place(relwidth=width,relheight=height,relx=x,rely=0.2)
                self.MainFrame.after(5, Hide)
            else:
                self.Command(self.Entry.get())
                self.Close()
        Hide()
    
    def Close(self):
        self.MainFrame.destroy()
        del self.MainPack.MoveFrameClick[self.MainPack.MoveFrameClick.index(self.Hide)]

