import tkinter, tkinter.messagebox, os, threading
import io, re, sys, webbrowser, traceback, functools
from tkinter import ttk
from typing import List,Dict,Literal,Union
sys.path.append(os.path.realpath(os.path.join(__file__, os.pardir)))
base_path = os.path.dirname(os.path.abspath(__file__))

import package.python_nbt as python_nbt
import package.MCStructureManage.StructureBDX as python_bdx
import package.tk_tool as tk_tool
import package.file_operation as file_IO
from package.MCStructureManage import CommonStructure, getStructureType
from transform_core import Analysis_Setting, Command_Str_Transfor

SandBoxPath = file_IO.PathSandBox("[EXP]Commannd_Upgrade")
SUPPORT_FILE = re.compile("(\\.mcfunction|\\.txt|\\.bdx|\\.json|\\.fhbuild|\\.kbdx|\\.reb|\\.building|\\.mcstructure)$")
COMMAND_VERSION = ((1,19,0), (1,19,50))
OUTPUT_VERSION  = ((1,19,50), (1,19,70), (1,20,10))
tkinter_component = {}


class pack_class : pass


def Setting_Info() :
    Trans_Command = (tkinter_component["transform_execute"](), 
                     tkinter_component["transform_block_command"](), 
                     tkinter_component["transform_summon"](),
                     tkinter_component["transform_structure"]())
    Start_Version:tuple = tkinter_component["command_version"]()
    End_Version:tuple = tkinter_component["output_version"]()
    Analysis_Setting( (Trans_Command, Start_Version, End_Version) )

def Open_Test(Menu:tkinter.Frame, Trans:tkinter.Frame) :
    global InputTextHashSave

    test1 = tkinter_component["transform_execute"]()
    test2 = tkinter_component["transform_block_command"]()
    test3 = tkinter_component["transform_summon"]()
    if not(test1 or test2 or test3) : 
        tkinter.messagebox.showerror("Error", "请选择需要转换的命令")
        return None
    
    test4 = tkinter_component["command_version"]()
    test5 = tkinter_component["output_version"]()
    if test4 == 1 and test5 == 0 :
        tkinter.messagebox.showerror("Error", "命令版本与导出版本不能相同")
        return None
    
    InputTextHashSave = None
    Setting_Info()
    Menu.pack_forget() ; Trans.pack()
    
def UI_set(main_win, tkinter_Frame:tkinter.Frame) :
    global Root_Win, InputMethod
    Root_Win = main_win.window
    InputMethod = main_win.set_focus_input

    if "主界面" :
        Menu_Frame = tkinter.Frame(tkinter_Frame)
        tkinter.Label(Menu_Frame, text="   ", font=tk_tool.get_default_font(4), height=1).pack()
        tkinter.Label(Menu_Frame,text="语法转换升级",fg='black',font=tk_tool.get_default_font(25)).pack()

        tkinter.Label(Menu_Frame, text="   ", font=tk_tool.get_default_font(4), height=3).pack()
        tkinter.Label(Menu_Frame,text=tk_tool.platform_string("选择需要转换的命令"),fg='white',bg='#8c0000',font=tk_tool.get_default_font(13)).pack()
        middle_frame_1 = tkinter.Frame(Menu_Frame)
        checkbutton_var1 = tkinter.IntVar(middle_frame_1, 1) ; checkbutton_var2 = tkinter.IntVar(middle_frame_1, 1)
        checkbutton_var3 = tkinter.IntVar(middle_frame_1, 1) ; checkbutton_var4 = tkinter.IntVar(middle_frame_1, 1)
        tkinter.Checkbutton(middle_frame_1, text="execute 命令",font=tk_tool.get_default_font(11), variable=checkbutton_var1, onvalue=1, offvalue=0).pack(anchor="w")
        tkinter.Checkbutton(middle_frame_1, text="fill 等方块类命令",font=tk_tool.get_default_font(11), variable=checkbutton_var2, onvalue=1, offvalue=0).pack(anchor="w")
        tkinter.Checkbutton(middle_frame_1, text="summon 命令",font=tk_tool.get_default_font(11), variable=checkbutton_var3, onvalue=1, offvalue=0).pack(anchor="w")
        tkinter.Checkbutton(middle_frame_1, text="structure 命令",font=tk_tool.get_default_font(11), variable=checkbutton_var4, onvalue=1, offvalue=0).pack(anchor="w")
        middle_frame_1.pack()

        tkinter.Label(Menu_Frame, text="   ", font=tk_tool.get_default_font(10), height=1).pack()
        middle_frame_1 = tkinter.Frame(Menu_Frame) ; middle_frame_1.pack()
        tkinter.Label(middle_frame_1,text=tk_tool.platform_string("原命令版本"),fg='white',bg='#008c00',font=tk_tool.get_default_font(11)).grid(row=0, column=0)
        version1 = ttk.Combobox(middle_frame_1, font=tk_tool.get_default_font(11), width=8, state='readonly', justify='center')
        version1["value"] = tuple("%s.%s.%s"%i for i in COMMAND_VERSION) ; version1.current(0) ; version1.grid(row=0, column=1)

        tkinter.Label(Menu_Frame, text="   ", font=tk_tool.get_default_font(4), height=2).pack()
        middle_frame_1 = tkinter.Frame(Menu_Frame) ; middle_frame_1.pack()
        tkinter.Label(middle_frame_1,text=tk_tool.platform_string("导出后版本"),fg='white',bg='#008c00',font=tk_tool.get_default_font(11)).grid(row=0, column=0)
        version2 = ttk.Combobox(middle_frame_1, font=tk_tool.get_default_font(11), width=8, state='readonly', justify='center')
        version2["value"] = tuple("%s.%s.%s"%i for i in OUTPUT_VERSION) ; version2.current(2) ; version2.grid(row=0, column=1)

        tkinter.Label(Menu_Frame, text="   ", font=tk_tool.get_default_font(10), height=1).pack()
        middle_frame_2 = tkinter.Frame(Menu_Frame)
        tkinter.Button(middle_frame_2,text=' 帮助文档 ',font=tk_tool.get_default_font(12),bg='#9ae9d1', command=
            lambda:webbrowser.open("http://localhost:32323/?pack=b96d85f5-789c-4812-895c-b1751c150adc&page=help")).pack(side="left")
        tkinter.Label(middle_frame_2, text="    ",fg='black',font=tk_tool.get_default_font(5)).pack(side="left")
        tkinter.Button(middle_frame_2,text=' 打开转换 ',font=tk_tool.get_default_font(12),bg='#9ae9d1',
            command=lambda:Open_Test(Menu_Frame, Transfor_Frame) ).pack(side="left")
        middle_frame_2.pack()
        tkinter.Label(Menu_Frame, text="第一次使用请阅读 帮助文档", font=tk_tool.get_default_font(11), fg="red").pack()

    if "转换界面" :
        Transfor_Frame = tkinter.Frame(tkinter_Frame)
        tkinter.Label(Transfor_Frame, text="  ", font=tk_tool.get_default_font(9), height=1).pack()

        middle_frame_3 = tkinter.Frame(Transfor_Frame)
        tkinter.Button(middle_frame_3, text=tk_tool.platform_string("返回"), background="#959cff", font=tk_tool.get_default_font(10),
            command=lambda:[Transfor_Frame.pack_forget(), Menu_Frame.pack()]).pack(side="left")
        tkinter.Label(middle_frame_3, text="  ", font=tk_tool.get_default_font(5), height=1).pack(side="left")
        tkinter.Button(middle_frame_3,text=tk_tool.platform_string('文本转换'),font=tk_tool.get_default_font(10),bg='#4ae9d1',
            command=lambda:[TransTextFrame.pack(),TransFileFrame.pack_forget()]).pack(side="left")
        tkinter.Label(middle_frame_3, text="   ",fg='black',font=tk_tool.get_default_font(5)).pack(side="left")
        tkinter.Button(middle_frame_3,text=tk_tool.platform_string('文件转换'),font=tk_tool.get_default_font(10),bg='#4ae9d1',
            command=lambda:[TransTextFrame.pack_forget(),TransFileFrame.pack()]).pack(side="left")
        middle_frame_3.pack()
        tkinter.Label(Transfor_Frame, text="  ", font=tk_tool.get_default_font(9), height=1).pack()

        TransTextFrame = tkinter.Frame(Transfor_Frame)
        middle_frame_4 = tkinter.Frame(TransTextFrame) ; middle_frame_4.pack()
        tkinter.Label(middle_frame_4, text=tk_tool.platform_string("命令输入区"), bg='aqua',fg='black',font=tk_tool.get_default_font(13), height=1).pack(side="left")
        tkinter.Label(middle_frame_4, text="           ", font=tk_tool.get_default_font(9), height=1).pack(side="left")
        tkinter.Button(middle_frame_4,text=tk_tool.platform_string('粘贴文本'),font=tk_tool.get_default_font(9),bg='#ef9e00',
            command=lambda:InputText.input_box.event_generate("<<Paste>>")).pack(side="left")
        InputText = tk_tool.tk_Scrollbar_Text(TransTextFrame, horizontal_scrollbar=False,height=9,width=27,font=tk_tool.get_default_font(10),undo=True)
        InputText.input_box.tag_config("syntax_error", background="#ff6161")
        InputText.input_box.bind("<FocusIn>", lambda a : InputMethod(a))
        InputText.pack()
        OutputText = tk_tool.tk_Scrollbar_Text(TransTextFrame, horizontal_scrollbar=False,height=9,width=27,font=tk_tool.get_default_font(10),undo=True)
        OutputText.input_box.tag_config("syntax_error", background="#ff6161")
        OutputText.input_box.bind("<FocusIn>", lambda a : InputMethod(a))
        OutputText.pack()
        middle_frame_4 = tkinter.Frame(TransTextFrame) ; middle_frame_4.pack()
        tkinter.Label(middle_frame_4, text=tk_tool.platform_string("命令输出区"), bg='aqua',fg='black',font=tk_tool.get_default_font(13), height=1).pack(side="left")
        tkinter.Label(middle_frame_4, text="           ", font=tk_tool.get_default_font(9), height=1).pack(side="left")
        tkinter.Button(middle_frame_4,text=tk_tool.platform_string('内容复制'),font=tk_tool.get_default_font(9),bg='#ef9e00',
            command=lambda:tk_tool.copy_to_clipboard( OutputText.input_box.get("0.0", "end-1c") )).pack(side="left")
        TransTextFrame.pack()

        TransFileFrame = tkinter.Frame(Transfor_Frame)
        middle_frame_4 = tkinter.Frame(TransFileFrame); middle_frame_4.pack()
        tkinter.Label(middle_frame_4, text=" 检索到的文件 ", bg='aqua',fg='black',font=tk_tool.get_default_font(13), height=1).pack(side="left")
        tkinter.Label(middle_frame_4, text="        ", font=tk_tool.get_default_font(9), height=1).pack(side="left")
        tkinter.Button(middle_frame_4,text=' 确认转换 ',font=tk_tool.get_default_font(9),bg='#ef9e00',
            command=lambda:Start_Trans_File(main_win.window, OutputFileErrorText.input_box)).pack(side="left")
        InputFile = tk_tool.tk_Scrollbar_ListBox(TransFileFrame, horizontal_scrollbar=False, 
            selectmode=tkinter.MULTIPLE,height=17,width=27,font=tk_tool.get_default_font(10))
        InputFile.pack()
        tkinter.Label(TransFileFrame, text=" ", font=tk_tool.get_default_font(5), height=1).pack()
        middle_frame_4 = tkinter.Frame(TransFileFrame); middle_frame_4.pack()
        tkinter.Button(middle_frame_4, height=1,text=tk_tool.platform_string("全选"),font=tk_tool.get_default_font(11), bg="#ff6cf5",
            command=lambda:[InputFile.input_box.select_set(0, "end")]).pack(side='left')
        tkinter.Label(middle_frame_4, text="  ", font=tk_tool.get_default_font(5), height=1).pack(side='left')
        tkinter.Button(middle_frame_4, height=1,text=tk_tool.platform_string("清空"),font=tk_tool.get_default_font(12), bg="#ff6cf5",
            command=lambda:[InputFile.input_box.select_clear(0, "end")]).pack(side='left')
        tkinter.Label(middle_frame_4, text="  ", font=tk_tool.get_default_font(5), height=1).pack(side='left')
        tkinter.Label(middle_frame_4, text="请选择需\n转换的文件", fg="red", font=tk_tool.get_default_font(8), height=2).pack(side='left')

    if "语法检查错误界面" :
        Transfor_File_Error_Frame = tkinter.Frame(tkinter_Frame)
        tkinter.Label(Transfor_File_Error_Frame, text="   ", font=tk_tool.get_default_font(9), height=1).pack()
        OutputFileErrorText = tk_tool.tk_Scrollbar_Text(Transfor_File_Error_Frame, horizontal_scrollbar=False,
            height=22,width=27,font=tk_tool.get_default_font(10),wrap="char")
        OutputFileErrorText.pack()
        tkinter.Label(Transfor_File_Error_Frame, text="   ", font=tk_tool.get_default_font(5), height=1).pack()
        middle_frame_4 = tkinter.Frame(Transfor_File_Error_Frame)
        tkinter.Button(middle_frame_4,text=' 界面返回 ',font=tk_tool.get_default_font(12),bg='#4ae9d1',
            command=lambda:[Transfor_Frame.pack(), Transfor_File_Error_Frame.pack_forget()]).pack(side="left")
        tkinter.Label(middle_frame_4, text="    ",fg='black',font=tk_tool.get_default_font(5)).pack(side="left")
        tkinter.Button(middle_frame_4,text=' 再次转换 ',font=tk_tool.get_default_font(12),bg='#4ae9d1',
            command=lambda:Start_ReTrans_File(main_win.window)).pack(side="left")
        middle_frame_4.pack()


    tkinter_component["transform_execute"] = checkbutton_var1.get
    tkinter_component["transform_block_command"] = checkbutton_var2.get
    tkinter_component["transform_summon"] = checkbutton_var3.get
    tkinter_component["transform_structure"] = checkbutton_var4.get

    tkinter_component["command_version"] = version1.current
    tkinter_component["output_version"] = version2.current

    tkinter_component["text_input"] = InputText.input_box
    tkinter_component["text_output"] = OutputText.input_box
    tkinter_component["file_input"] = InputFile.input_box
    tkinter_component["file_error"] = OutputFileErrorText.input_box

    tkinter_component["trans_frame"] = Transfor_Frame
    tkinter_component["error_frame"] = Transfor_File_Error_Frame
        
    InputText.input_box.after(500, lambda: Flash_Text_Output(InputText.input_box, OutputText.input_box))
    OutputFileErrorText.input_box.after(500, lambda: Flash_File_Output(InputFile.input_box))
    Menu_Frame.pack()



InputTextHashSave = None
def Flash_Text_Output(Input:tkinter.Text, Output:tkinter.Text) :
    global InputTextHashSave
    Input.after(500, lambda: Flash_Text_Output(Input, Output))

    TextContent = tkinter_component["text_input"].get("0.0", "end-1c")
    TextHash = hash(TextContent)
    if TextHash == InputTextHashSave : return None
    else : InputTextHashSave = TextHash

    Output.delete("0.0", "end")
    Input.tag_remove("syntax_error", "0.0", "end")
    str_list = [] ; error_test = False
    for index, str1 in enumerate( TextContent.split("\n") ) :
        if str1.replace(" ", "").__len__() == 0 : continue
        a = Command_Str_Transfor(str1)
        if not isinstance(a, str) : 
            Text_Syntax_Error_Tag(Input, Output, index+1, a) ; error_test = True
        else : str_list.append(a)
    if not error_test : Output.insert("end", "\n".join( str_list ))

def Text_Syntax_Error_Tag(Input:tkinter.Text, Output:tkinter.Text, lines:int, error:tuple) :
    Output.insert('end',"第%s行发生错误：\n%s\n\n" % (lines, error[0]))
    if hasattr(error[1], "pos") : Input.tag_add("syntax_error", "%s.%s"%(lines, error[1].pos[0]), "%s.end"%lines )
    else : Input.tag_add("syntax_error", "%s.%s"%(lines, 0), "%s.end"%lines )
    Input.mark_set( "my_cursor", "%s.end"%lines )
    Input.see( "%s.0"%lines )


FileHashSave = None
def Flash_File_Output(Listbox:tkinter.Listbox) :
    global FileHashSave
    Listbox.after(500, lambda: Flash_File_Output(Listbox))

    file_list = [('[内部]'+k[2] if k[0]=='internal' else '[外部]'+k[2]) for k in SandBoxPath.list_dirs("all", "") 
        if k[1] == "file" and SUPPORT_FILE.search(k[2])]
    TextHash = hash(" ".join(file_list))
    if TextHash == FileHashSave : return None
    else : FileHashSave = TextHash

    Listbox.delete(0, "end")
    Listbox.insert("end", *file_list)


Error_File_Save:Dict[str, Dict[Literal["file_type", "file_encoder", "file_data", "error"], Union[Literal["txt", "bdx", "other"], list]]] = {}
def Start_Trans_File(TK:tkinter.Tk, Error_Print:tkinter.Text) :
    Error_Print.config(state="normal")
    Error_Print.delete("0.0", "end")
    
    file_name_list = [tkinter_component["file_input"].get(k) for k in tkinter_component["file_input"].curselection()]
    tk_things = tk_tool.tk_Msgbox(TK, TK)
    tkinter.Label(tk_things, text="   ", font=tk_tool.get_default_font(4), height=1).pack()
    msg = tkinter.Label(tk_things, text="   ", font=tk_tool.get_default_font(12), height=2)
    msg.pack()

    threading.Thread(target=Trans_Thread, args=(msg, Error_Print, file_name_list)).start()

def Trans_Thread(Msg:tkinter.Label, Error:tkinter.Text, Name_List:List[str]) :
    Error_File_Save.clear()
    SandBoxPath.make_dir("all", "TransOutput")

    for index1, file_name in enumerate(Name_List) :
        Msg.config(text="正在转换中...\n还剩 %s 个文件待转换" % (len(Name_List)-index1))
        if file_name[-4:] == ".bdx" : 
            Error_File_Save[file_name] = {"file_type":"bdx", "file_data":None, "error":[]}
            Read_Bdx(file_name, Error)
        elif file_name[-4:] in {".mcfunction", ".txt"} : 
            Error_File_Save[file_name] = {"file_type":"txt", "file_data":None, "error":[]}
            Read_Txt(file_name, Error)
        else :
            Error_File_Save[file_name] = {"file_type":"other", "file_data":None, "error":[]}
            Read_Other(file_name, Error)

    Msg.master.destroy()
    File_Syntax_Error_Tag(Error) 
    if Error.get("1.0", "2.end").replace("\n", "").__len__() != 0 :
        tkinter_component["trans_frame"].pack_forget()
        tkinter_component["error_frame"].pack()
        Error.config(state="disabled")
    else :
        tkinter.messagebox.showinfo("Info", "转换已完成")

def Start_ReTrans_File(TK:tkinter.Tk) :
    TkText:tkinter.Text = tkinter_component["file_error"]
    for winName in TkText.window_names() :
        widget = TkText.nametowidget( winName )
        if not isinstance(widget, tkinter.Button) : continue
        if widget.cget("text") != "错误" : continue
        ask = tkinter.messagebox.askokcancel("Ask", "还有命令错误未修改\n是否进行强制转换？")
        if not ask : return None
        break

    tk_things = tk_tool.tk_Msgbox(TK, TK)
    tkinter.Label(tk_things, text="   ", font=tk_tool.get_default_font(4), height=1).pack()
    msg = tkinter.Label(tk_things, text="aaa", font=tk_tool.get_default_font(12), height=2)
    msg.pack()

    threading.Thread(target=ReTrans_Thread, args=(msg, )).start()

def ReTrans_Thread(Msg:tkinter.Label) :
    for index, (fileName, errorData) in enumerate( Error_File_Save.items() ) :
        Msg.config(text="正在转换中...\n还剩 %s 个文件待转换" % (len(Error_File_Save)-index))
        if not errorData["file_data"] : continue
        if errorData["file_type"] == "bdx" : 
            OutputIO = SandBoxPath.file_operate("internal" if fileName.startswith("[内部]") else "outside", 
                os.path.join("TransOutput", fileName[4:]), "wb")
            errorData["file_data"].save_as(OutputIO)
            OutputIO.close()
        elif errorData["file_type"] == "txt" : 
            OutputIO = SandBoxPath.file_operate("internal" if fileName.startswith("[内部]") else "outside", 
                os.path.join("TransOutput", fileName[4:]), "w+", encoding="utf-8")
            OutputIO.write( "\n".join(errorData["file_data"]) )
            OutputIO.close()
        else : 
            OutputIO = SandBoxPath.file_operate("internal" if fileName.startswith("[内部]") else "outside", 
                os.path.join("TransOutput", fileName[4:]), "wb")
            errorData["file_data"].save_as( OutputIO, errorData["file_encoder"] )
            OutputIO.close()

    Msg.master.destroy()
    tkinter.messagebox.showinfo("Info", "再次转换已完成")
    tkinter_component["error_frame"].pack_forget()
    tkinter_component["trans_frame"].pack()


def Search_Command(Operation:list) :
    place_origin = [0, 0, 0]

    for code in Operation :
        oper_code:int = code.operation_code
        if oper_code in {0x06, 0x0c, 0x18, 0x19, 0x1e} : place_origin[2] += code.value
        elif oper_code in {0x16, 0x17, 0x1d} : place_origin[1] += code.value
        elif oper_code in {0x14, 0x15, 0x1c} : place_origin[0] += code.value
        elif oper_code in {0x12, 0x13} : place_origin[2] += 1 if oper_code == 0x12 else -1
        elif oper_code in {0x10, 0x11} : place_origin[1] += 1 if oper_code == 0x10 else -1
        elif oper_code in {0x0e, 0x0f} : place_origin[0] += 1 if oper_code == 0x0e else -1
        elif oper_code in {0x22,0x23,0x24,0x1a,0x1b,0x29} : yield (place_origin[0], place_origin[1], place_origin[2], code)

def Read_Bdx(fileName:str, Error:tkinter.Text) :
    try : 
        if fileName.startswith("[内部]") : fileIO = SandBoxPath.file_operate("internal", fileName[4:], "rb")
        else : fileIO = SandBoxPath.file_operate("outside", fileName[4:], "rb")
        bdx_obj = python_bdx.BDX_File.from_buffer(fileIO)
    except : 
        Error.insert('end', "文件 %s 发生错误：\n%s\n\n" % (fileName, traceback.format_exc()))
        return None

    for operation_info in Search_Command(bdx_obj.operation_list) :
        Oper_Object = operation_info[-1]
        if Oper_Object.operation_code != 0x29 : 
            Command = Oper_Object.command
        else :
            nbt = Oper_Object.nbt
            if ('id' not in nbt) or (nbt['id'].value != 'CommandBlock') or ('Command' not in nbt) : continue
            Command = nbt['Command'].value

        a = Command_Str_Transfor(Command)
        if not isinstance(a, str) : Error_File_Save[fileName]["error"].append( operation_info )
        elif Oper_Object.operation_code != 0x29 : Oper_Object.command = a
        else : Oper_Object.nbt['Command'] = python_nbt.TAG_String(a)

    if Error_File_Save[fileName]["error"] : 
        Error_File_Save[fileName]["file_data"] = bdx_obj
    else : 
        OutputIO = SandBoxPath.file_operate("internal" if fileName.startswith("[内部]") else "outside", 
            os.path.join("TransOutput", fileName[4:]), "wb")
        bdx_obj.save_as(OutputIO)
        OutputIO.close()

def Read_Txt(fileName:str, Error:tkinter.Text) :
    Blank = re.compile("^[ ]{0,}$|^[ ]{0,}#")

    try : 
        if fileName.startswith("[内部]") : fileIO = SandBoxPath.file_operate("internal", fileName[4:], "r", encoding="utf-8")
        else : fileIO = SandBoxPath.file_operate("outside", fileName[4:], "r", encoding="utf-8")
        Contents = fileIO.read().split("\n")
    except : 
        Error.insert('end', "文件 %s 发生错误：\n%s\n\n" % (fileName, traceback.format_exc()))
        return None

    for lines, Command in enumerate(Contents) :
        if Blank.search(Command) : continue
        a = Command_Str_Transfor(Command)
        if not isinstance(a, str) : Error_File_Save[fileName]["error"].append( (lines, Contents) )
        else : Contents[lines] = a
    
    if Error_File_Save[fileName]["error"] : 
        Error_File_Save[fileName]["file_data"] = Contents
    else : 
        OutputIO = SandBoxPath.file_operate("internal" if fileName.startswith("[内部]") else "outside", 
            os.path.join("TransOutput", fileName[4:]), "w+", encoding="utf-8")
        OutputIO.write( "\n".join(Contents) )
        OutputIO.close()

def Read_Other(fileName:str, Error:tkinter.Text) :
    try : 
        if fileName.startswith("[内部]") : fileIO = SandBoxPath.file_operate("internal", fileName[4:], "rb")
        else : fileIO = SandBoxPath.file_operate("outside", fileName[4:], "rb")
        
        Decoder = getStructureType(fileIO)
        Struct1 = CommonStructure.from_buffer( fileIO, Decoder )
        SizeX, SizeY, SizeZ = Struct1.size
        for index, block_nbt in Struct1.block_nbt.items() :
            if ('id' not in block_nbt) or (block_nbt['id'].value != 'CommandBlock') or ('Command' not in block_nbt) : continue
            a = Command_Str_Transfor( block_nbt["Command"].value )

            if not isinstance(a, str) : 
                NBTPosX = (index // (SizeY * SizeZ))
                remain = index % (SizeY * SizeZ)
                NBTPosY = (remain // SizeZ)
                NBTPosZ = (remain % SizeZ)
                Error_File_Save[fileName]["error"].append( (NBTPosX, NBTPosY, NBTPosZ, block_nbt) )
            else : 
                block_nbt["Command"] = python_nbt.TAG_String(a)
                block_nbt["Version"] = python_nbt.TAG_Int(36)
        
        if Error_File_Save[fileName]["error"] : 
            Error_File_Save[fileName]["file_data"] = Struct1
            Error_File_Save[fileName]["file_encoder"] = Decoder
        else : 
            if hasattr(Decoder, "codecs_tag") and getattr(Decoder, "codecs_tag") == "json" :
                OutputIO = SandBoxPath.file_operate("internal" if fileName.startswith("[内部]") else "outside", 
                os.path.join("TransOutput", fileName[4:]), "w+", encoding="utf-8")
            else : OutputIO = SandBoxPath.file_operate("internal" if fileName.startswith("[内部]") else "outside", 
                os.path.join("TransOutput", fileName[4:]), "wb")
            Struct1.save_as( OutputIO, Decoder )
            OutputIO.close()
    except : 
        Error.insert('end', "文件 %s 发生错误：\n%s\n\n" % (fileName, traceback.format_exc()))
        return None

def File_Syntax_Error_Tag(Error:tkinter.Text) :
    for fileName, errorData in Error_File_Save.items() :
        if not errorData["file_data"] : continue
        Error.insert('end', "文件 %s 出现语法错误：\n" % fileName)

        for index, errorInfo in enumerate(errorData["error"]) :
            Button1 = tkinter.Button(Error, font=tk_tool.get_default_font(10), text="错误", fg="#ff0000")
            Button1.config(command=functools.partial(Spawn_TopLevel, errorData["file_type"], errorInfo, Button1))
            Error.window_create("end", window=Button1)
            if index % 4 != 3 : Error.insert("end", " ")
            else : Error.insert("end", "\n")
        Error.insert('end', "\n\n\n")

def Spawn_TopLevel(Type:Literal["txt", "bdx", "other"], errorInfo:tuple, Button1:tkinter.Button) :
    top = tkinter.Toplevel(Root_Win, )
    top.title("MsgBox")
    top.geometry( "%sx%s+%s+%s" % (
        int(Root_Win.winfo_width() * 0.95), int(Root_Win.winfo_height() * 0.6),
        Root_Win.winfo_x(), Root_Win.winfo_y()+50 ))
    top.transient(Root_Win)
    
    ErrorObj = errorInfo[-1]
    if Type == "bdx" : 
        pos_text = "CB坐标 %s\n相对于结构起始位置" % str( (errorInfo[0], errorInfo[1], errorInfo[2]) )
        if ErrorObj.operation_code != 0x29 : Command = ErrorObj.command
        else : Command = ErrorObj.nbt['Command'].value
    elif Type == "txt" : 
        pos_text = "函数文件第 %s 行" % (errorInfo[0] + 1)
        Command = ErrorObj[ errorInfo[0] ]
    else :
        pos_text = "CB坐标 %s\n相对于结构起始位置" % str( (errorInfo[0], errorInfo[1], errorInfo[2]) )
        Command = ErrorObj['Command'].value
    
    tkinter.Label(top, text="   ", font=tk_tool.get_default_font(4), height=1).pack()
    tkinter.Label(top, text=pos_text, font=tk_tool.get_default_font(12), height=2).pack()
    OutputText = tk_tool.tk_Scrollbar_Text(top, horizontal_scrollbar=False, height=8, width=26, font=tk_tool.get_default_font(10),undo=True)
    OutputText.input_box.tag_config("syntax_error", background="#ff6161")
    OutputText.input_box.bind("<FocusIn>", lambda a : InputMethod(a))
    OutputText.input_box.insert("end", Command)
    OutputText.pack()
    Feedback = tkinter.Label(top, text="语法错误， 请修改", font=tk_tool.get_default_font(12), fg="#ff0000")
    Feedback.pack()
    tkinter.Label(top, text="   ", font=tk_tool.get_default_font(4), height=1).pack()
    middle_frame_4 = tkinter.Frame(top)
    tkinter.Button(middle_frame_4,text=' 取消 ',font=tk_tool.get_default_font(12),bg='#4ae9d1',command=top.destroy).pack(side="left")
    tkinter.Label(middle_frame_4, text="      ",fg='black',font=tk_tool.get_default_font(5)).pack(side="left")
    tkinter.Button(middle_frame_4,text=' 忽略 ',font=tk_tool.get_default_font(12),bg='#4ae9d1',command=lambda:Pass()).pack(side="left")
    tkinter.Label(middle_frame_4, text="      ",fg='black',font=tk_tool.get_default_font(5)).pack(side="left")
    tkinter.Button(middle_frame_4,text=' 确定 ',font=tk_tool.get_default_font(12),bg='#4ae9d1',command=lambda:Trans_Test()).pack(side="left")
    middle_frame_4.pack()

    TextHashSave = None
    def Text_Syntax_Error_Tag(Input=OutputText.input_box, wait=True) :
        nonlocal TextHashSave
        if wait : top.after(500, Text_Syntax_Error_Tag)

        TextContent = Input.get("0.0", "end-1c")
        TextHash = hash(TextContent)
        if TextHash == TextHashSave : return None
        else : TextHashSave = TextHash

        a = Command_Str_Transfor(TextContent)
        Input.tag_remove("syntax_error", "0.0", "end")
        if not isinstance(a, str) : 
            if hasattr(a[1], "pos") : Input.tag_add("syntax_error", "1.%s"%a[1].pos[0], "1.end" )
            else : Input.tag_add("syntax_error", "1.0", "1.end" )
            Feedback.config(text="语法错误， 请修改", fg="#ff0000")
        else : Feedback.config(text="语法正确", fg="#00c63c")
    top.after(500, Text_Syntax_Error_Tag)

    def Trans_Test(Input=OutputText.input_box) :
        Text_Syntax_Error_Tag(wait=False)
        if Feedback.cget("text").__len__() > 4 :
            tkinter.messagebox.showerror("Error", "语法错误，无法转换")
            return None

        TextContent = Input.get("0.0", "end-1c")
        c = Command_Str_Transfor(TextContent)

        if Type == "bdx" :
            if ErrorObj.operation_code != 0x29 : ErrorObj.command = c
            else : ErrorObj.nbt['Command'] = python_nbt.TAG_String(c)
        elif Type == "txt" : ErrorObj[errorInfo[0]] = c
        else :
            ErrorObj["Command"] = python_nbt.TAG_String(c)
            ErrorObj["Version"] = python_nbt.TAG_Int(36)

        Button1.config(text="正确", fg="green")
        top.destroy()

    def Pass() :
        Button1.config(text="忽略", fg="#ff7f27")
        top.destroy()



#execute as @s[r=2,hasitem={item=aaa,data=1}] at @s positioned ~ 2 ~4 if block ^ ^ ^ minecraft:bedrock["infiniburn_bit":false] run setblock ~ ~ ~ minecraft:bedrock["infiniburn_bit":true]

