from typing import Dict,Union,List,Tuple,Literal
import re
TOKEN = List[Dict[Literal["type","token"], Union[str,re.Match]]]

New_Execute_Syntax:bool = False
Command_Version:tuple = None
BLOCKSTATE_SYNTAX:bool = False
Command_Parser_Tree = None
SettingSave = None



def Analysis_Setting(Setting) :
    global BLOCKSTATE_SYNTAX, Command_Version, New_Execute_Syntax, Command_Parser_Tree, SettingSave
    
    BLOCKSTATE_SYNTAX = Setting[2] >= 2
    Command_Version = ((1,19,0), (1,19,50))[Setting[1]]
    New_Execute_Syntax = bool(Setting[1])
    Command_Parser_Tree = command_tree.Generate_Parser_Tree(Setting[0], Setting[1], Setting[2])
    SettingSave = Setting

def Command_Str_Transfor(Command:str, FastPath:TOKEN=None) :

    if FastPath is None :
        token_list = Command_Parser_Tree.parser(Command, Command_Version)
        if isinstance(token_list, tuple) : return token_list
        if token_list[0]["type"] == "Any_Command" : return token_list[0]["token"].group()
    else : token_list = FastPath

    if token_list[0]["token"].group() == "execute" :
        if SettingSave[0][0] : return execute.Start_Transformer(BLOCKSTATE_SYNTAX, token_list, New_Execute_Syntax)

        if Command_Version == (1,19,0) : Pass_Execute_Index = transfor.Pass_Command_execute_1_19_0(token_list)
        elif Command_Version == (1,19,50) : Pass_Execute_Index = transfor.Pass_Command_execute_1_19_50(token_list)

        if token_list[Pass_Execute_Index]["token"].group() in {"fill", "setblock", "testforblock", "clone"} :
            a = blocks.Start_Transformer(BLOCKSTATE_SYNTAX, token_list[Pass_Execute_Index:])
            b = Command[0:token_list[Pass_Execute_Index]["token"].start()]
            return "".join((b, a))
        elif token_list[Pass_Execute_Index]["token"].group() == "summon" :
            a = summon.Start_Transformer(token_list[Pass_Execute_Index:])
            b = Command[0:token_list[Pass_Execute_Index]["token"].start()]
            return "".join((b, a))
        else : return Command
    elif token_list[0]["token"].group() in {"fill", "setblock", "testforblock", "clone"} :
        return blocks.Start_Transformer(BLOCKSTATE_SYNTAX, token_list)
    elif token_list[0]["token"].group() == "summon" :
        return summon.Start_Transformer(token_list)
    


from . import command_tree
from . import transfor
from . import execute,blocks,summon