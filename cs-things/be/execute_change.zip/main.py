import tkinter,os,threading,copy,json,re,math
from tkinter.constants import *
import numpy as np
from string import Template

exec(open(os.path.join("main_source","constant.py"),"r",encoding='utf-8').read(),None,globals())
exec(open(os.path.join("main_source","glob_class.py"),"r",encoding='utf-8').read(),None,globals())
exec(open(os.path.join("main_source","game_class.py"),"r",encoding='utf-8').read(),None,globals())
exec(open(os.path.join("main_source","error_class.py"),"r",encoding='utf-8').read(),None,globals())
file_IO = file_operation( )
exec(file_IO.read_a_file(bedrock_command_class_main_path),None,globals())

class pack_class : 
    def __init__(self) -> None : 
        self.check_selector = command_class.selector_system()
        self.enter_times = 0
    
    def check_execute_command(self,command_text,store_list) :
        command_text0 = command_class.match(command_text,0,False,"command")
        if command_text0[0] != "execute" : 
            store_list.append(("command",command_text))
            return None
        store_list.append(("command",command_text0[0]))

        command_text1 = command_class.match(command_text,command_text0[1],True,"selector") #取出目标选择器
        if check_response(command_text1) == 0 : return command_text1 #检查是否有误

        execute_var = {"executer":None,"execute_dimension":"overworld","execute_pos":[0,0,0],"execute_roatate":[0,0]}
        if len(command_text1[0]) == 1:
            selector_list1 = self.check_selector.executing(execute_var,command_text1[0][0],only_check=True)
        else :
            selector_list1 = self.check_selector.executing(execute_var,command_text1[0][0],command_text1[0][1],only_check=True)
        if check_response(selector_list1) == 0 : return selector_list1
        store_list.append(("selector",command_text1[0]))

        command_text2 = command_class.match(command_text,command_text1[1],True,"pos")
        if check_response(command_text2) == 0 : return command_text2 #检查是否有误
        store_list.append(("pos",command_text2[0]))
        
        command_text3 = command_class.match(command_text,command_text2[1],False,"command")
        if check_response(command_text3) == 0 : return command_text3

        if command_text3[0] == "detect" :
            store_list.append(("str",command_text3[0]))

            command_text4 = command_class.match(command_text,command_text3[1],True,"pos")
            if check_response(command_text4) == 0 : return command_text4 #检查是否有误
            store_list.append(("pos",command_text4[0]))
            
            command_text5 = command_class.match(command_text,command_text4[1],True,"ID")
            if check_response(command_text5) == 0 : return command_text5 #检查是否有误
            store_list.append(("str",command_text5[0]))
            
            command_text6 = command_class.match(command_text,command_text5[1],True,"int")
            if check_response(command_text6) == 0 : return command_text6 #检查是否有误
            store_list.append(("int",str(command_text6[0])))

            command_text7 = command_class.match(command_text,command_text6[1],False,"command")
            if check_response(command_text7) == 0 : return command_text7
            if command_text7[0] == "execute" : 
                mid1 = self.check_execute_command(command_text[(command_text7[1]-len(command_text7[0])):],store_list)
                if check_response(mid1) != None : return mid1
            else : store_list.append(("command",command_text[(command_text7[1]-len(command_text7[0])):]))
        
        elif command_text3[0] == "execute" : 
            mid1 = self.check_execute_command(command_text[(command_text3[1]-len(command_text3[0])):],store_list)
            if check_response(mid1) != None : return mid1
        
        else : store_list.append(("command",command_text[(command_text3[1]-len(command_text3[0])):]))

    def exchange_text(self,main_window) :
        result_list = []
        input_text = main_window.expand_ui_1.get("1.0","end")
        input_text = input_text[0:len(input_text)-1].split("\n")
        for i in input_text :
            mid_list = []
            mid1 = self.check_execute_command(i,mid_list)
            if check_response(mid1) != None : 
                main_window.modify_state("转换出错，请查看反馈信息",info,want_record=False,want_display=True)
                main_window.expand_ui_3.delete("1.0",'end')
                main_window.expand_ui_3.insert('end', i + " 发生错误：\n" + mid1.command_msg)
                return None
            result_list.append(mid_list)
        index1 = 0
        for i in list(result_list) :
            change_command,first_1,detect_1 = [],False,False
            for j in i :
                if j[0] == "command" : 
                    if j[1] != "execute" and first_1 : change_command.append("run")
                    if j[1] != "execute" or not first_1: change_command.append(j[1])
                    first_1 = True
                    if j[1] != "execute" : break
                elif j[0] == "selector" : change_command += ["as","".join(j[1]),"at @s"]
                elif j[0] == "pos" : 
                    if not detect_1 : change_command += ["positioned"," ".join(j[1])]
                    else : 
                        detect_1 = False
                        change_command += [" ".join(j[1])]
                elif j[0] == "str": 
                    if j[1] == "detect" : 
                        detect_1 = True
                        change_command.append("if block")
                        continue
                    change_command.append(j[1])
                elif j[0] == "int" : change_command.append(j[1])
            result_list[index1] = " ".join(change_command)
            index1 += 1
        
        main_window.modify_state("转换已完成",info,want_record=False,want_display=True)
        main_window.expand_ui_3.delete("1.0",'end')
        main_window.expand_ui_3.insert('end', "\n".join(result_list))

    def exchange_dir(self,main_window) : 
        if main_window.expand_pack_class.enter_times == 0 :
            main_window.modify_state("二次确认：是否转换在\ninput文件夹下的所有文件？",info,want_record=False,want_display=True)
            main_window.expand_pack_class.enter_times += 1
        else :
            main_window.expand_pack_class.enter_times = 0
            main_window.modify_state("转换已经开始",info,want_record=False,want_display=True)
            loop_list = file_IO.file_in_path(os.path.join(main_window.run_expand_path,"input"))
            for file1 in loop_list:
                result_list = []
                input_text = file_IO.read_a_file(file1).split("\n")
                for i in input_text :
                    mid_list = []
                    mid1 = self.check_execute_command(i,mid_list)
                    if check_response(mid1) != None : 
                        main_window.modify_state("转换出错，请查看反馈信息",info,want_record=False,want_display=True)
                        main_window.expand_ui_3.delete("1.0",'end')
                        main_window.expand_ui_3.insert('end',"文件 " + file1 + " 异常\n\n" + i + " 命令发生错误：\n" + mid1.command_msg)
                        return None
                    result_list.append(mid_list)
                index1 = 0
                for i in list(result_list) :
                    change_command,first_1,detect_1 = [],False,False
                    for j in i :
                        if j[0] == "command" : 
                            if j[1] != "execute" and first_1 : change_command.append("run")
                            if j[1] != "execute" or not first_1: change_command.append(j[1])
                            first_1 = True
                            if j[1] != "execute" : break
                        elif j[0] == "selector" : change_command += ["as","".join(j[1]),"at @s"]
                        elif j[0] == "pos" : 
                            if not detect_1 : change_command += ["positioned"," ".join(j[1])]
                            else : 
                                detect_1 = False
                                change_command += [" ".join(j[1])]
                        elif j[0] == "str": 
                            if j[1] == "detect" : 
                                detect_1 = True
                                change_command.append("if block")
                                continue
                            change_command.append(j[1])
                        elif j[0] == "int" : change_command.append(j[1])
                    result_list[index1] = " ".join(change_command)
                    index1 += 1
                file_IO.write_a_file(file1.replace("input","output",1),"\n".join(result_list))
            
            main_window.modify_state("转换已完成",info,want_record=False,want_display=True)
            

def UI_set(self):
    self.expand_ui_0 = tkinter.Label(self.window, text="输入区" , bg='aqua',fg='black',font=('Arial', 13), width=10, height=1)
    self.expand_ui_1 = tkinter.Text(self.window,show=None,height=8,width=30,font=('Arial', 10))
    self.expand_ui_cv1 = tkinter.Canvas(self.window,width=2000, height=10)
    self.expand_ui_2 = tkinter.Frame()
    self.expand_ui_2_0 = tkinter.Button(self.expand_ui_2, text='转换输入',font=('Arial', 12),
        bg='orange' ,width=8, height=1,command=lambda: self.expand_pack_class.exchange_text(self))
    self.expand_ui_2_1 = tkinter.Canvas(self.expand_ui_2, width=10, height=5)
    self.expand_ui_2_2 = tkinter.Button(self.expand_ui_2, text='批量转换',font=('Arial', 12),
        bg='orange' ,width=8, height=1,command=lambda: self.expand_pack_class.exchange_dir(self))
    self.expand_ui_cv2 = tkinter.Canvas(self.window,width=2000, height=10)
    self.expand_ui_3 = tkinter.Text(self.window,show=None,height=8,width=30,font=('Arial', 10))
    self.expand_ui_4 = tkinter.Label(self.window, text="输出区" , bg='aqua',fg='black',font=('Arial', 13), width=10, height=1)

def intro_UI(self) : 
    self.expand_ui_0.pack()
    self.expand_ui_1.pack()
    self.expand_ui_cv1.pack()
    self.expand_ui_2_0.pack(side=LEFT)
    self.expand_ui_2_1.pack(side=LEFT)
    self.expand_ui_2_2.pack(side=LEFT)
    self.expand_ui_2.pack()
    self.expand_ui_cv2.pack()
    self.expand_ui_3.pack()
    self.expand_ui_4.pack()
    os.makedirs(os.path.join(self.run_expand_path,"input"),exist_ok=True)
    os.makedirs(os.path.join(self.run_expand_path,"output"),exist_ok=True)

def exit_UI(self) : 
    self.expand_pack_class.enter_times = 0
    self.expand_ui_0.pack_forget()
    self.expand_ui_1.pack_forget()
    self.expand_ui_cv1.pack_forget()
    self.expand_ui_2_0.pack_forget()
    self.expand_ui_2_1.pack_forget()
    self.expand_ui_2_2.pack_forget()
    self.expand_ui_2.pack_forget()
    self.expand_ui_cv2.pack_forget()
    self.expand_ui_3.pack_forget()
    self.expand_ui_4.pack_forget()