# Minecraft BE Command Syntax Hightlight Extension for Command Simulator

import sys, os
sys.path.append(os.path.realpath(os.path.join(__file__, os.pardir)))

import tkinter
# IDLE has also implement the calltip feature, which is useful to us for
# showing the errors
from idlelib.calltip_w import CalltipWindow

from mccmdhl import MCCommandHightlighter

BUTTON_FONT = {
    "background": '#00ff7f',
    "font": ("Arial", 9),
}
DEFAULT_WRAP = tkinter.NONE
WRAP_MODES = (tkinter.NONE, tkinter.WORD, tkinter.CHAR)

class pack_class:
    MAX_ERRMSG_LEN = 120
    MAX_ERRMSG_COL = 34

    def init(self, text: tkinter.Text):
        self.text = text
        self.highlighter = MCCommandHightlighter(self.text, self.show_errortip)
        self.calltip_win = CalltipWindow(self.text)

        self.text.bind("<Control-Z>", lambda event: self.undo())
        self.text.bind("<Control-Shift-Z>", lambda event: self.redo())
    
    def show_errortip(self, error_token):
        if error_token is None: # if message is empty
            self.calltip_win.hidetip()
            return
        # Handle message
        error_msg = self.highlighter.errmsg_from_token(error_token)
        ## Strip if too long
        if len(error_msg) > self.MAX_ERRMSG_LEN:
            error_msg = error_msg[:self.MAX_ERRMSG_LEN - 3] + "..."
        ## Add \n when message is too long
        lines = []
        current_length = 0
        current_line = ""
        for char in error_msg:
            current_length += 1 if char.isascii() else 2
            current_line += char
            if current_length > self.MAX_ERRMSG_COL:
                lines.append(current_line)
                current_length = 0
                current_line = ""
        if current_line:
            lines.append(current_line)
        error_msg = "\n".join(lines)
        # Show tip
        lineno = self.highlighter.lineno_from_index(error_token.pos_begin)
        self.calltip_win.showtip(
            error_msg, "%d.0" % lineno, "%d.end" % lineno
        )
        self.calltip_win.label.config(text=error_msg)
    
    def undo(self):
        self.text.edit_undo()
    
    def redo(self):
        self.text.edit_redo()
    
    def change_wrap(self):
        # change wrap mode of Text
        new = WRAP_MODES[(WRAP_MODES.index(self.text.cget("wrap")) + 1) % 3]
        self.text.config(wrap=new)
        return new

def UI_set(self):
    self.expand_ui = tkinter.Frame(self.window)
    lab_title = tkinter.Label(
        self.expand_ui, font=("Arial", 17), text="指令编辑器",
        background="aqua", foreground="black"
    )
    text_scroll_bar_y = tkinter.Scrollbar(self.expand_ui)
    text_scroll_bar_x = tkinter.Scrollbar(
        self.expand_ui, orient=tkinter.HORIZONTAL
    )
    text = tkinter.Text(
        self.expand_ui, font=("Arial", 11), height=21, width=33,
        undo=True, wrap=DEFAULT_WRAP,
        yscrollcommand=text_scroll_bar_y.set,
        xscrollcommand=text_scroll_bar_x.set
    )
    text_scroll_bar_y.config(command=text.yview)
    text_scroll_bar_x.config(command=text.xview)
    self.expand_pack_class.init(text)

    frame_buttons = tkinter.Frame(self.expand_ui)
    bt_undo = tkinter.Button(
        frame_buttons, text="撤销", width=4,
        command=self.expand_pack_class.undo, **BUTTON_FONT
    )
    bt_redo = tkinter.Button(
        frame_buttons, text="恢复", width=4,
        command=self.expand_pack_class.redo, **BUTTON_FONT
    )
    def _handle_wrap():
        new = self.expand_pack_class.change_wrap()
        bt_wrap.config(text=new)
        def _back():
            bt_wrap.config(text="自动换行")
        bt_wrap.after(1000, _back)
    bt_wrap = tkinter.Button(
        frame_buttons, text="自动换行", width=7,
        command=_handle_wrap, **BUTTON_FONT
    )
    bt_undo.grid(row=0, column=0)
    bt_redo.grid(row=0, column=1)
    bt_wrap.grid(row=0, column=2)

    lab_title.grid(row=0, column=0)
    frame_buttons.grid(row=0, column=1)
    text.grid(row=1, column=0, columnspan=2)
    text_scroll_bar_y.grid(row=1, column=2, sticky=tkinter.N+tkinter.S)
    text_scroll_bar_x.grid(
        row=2, column=0, columnspan=2, sticky=tkinter.W+tkinter.E
    )

def intro_UI(self):
    self.expand_ui.pack()

def exit_UI(self):
    self.expand_ui.pack_forget()
