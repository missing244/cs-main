# Minecraft BE Command Syntax Hightlight Extension for Command Simulator

import sys, os
sys.path.append(os.path.realpath(os.path.join(__file__, os.pardir)))

import tkinter
from mccmdhl.gui import MCCommandHightlighter

class pack_class:
    def init(self, text: tkinter.Text, error_var: tkinter.StringVar):
        self.text = text
        self.highlighter = MCCommandHightlighter(self.text, error_var)

def UI_set(self):
    self.expand_ui = tkinter.Frame(self.window)
    lab_title = tkinter.Label(
        self.expand_ui, font=("Arial", 18), text="指令编辑器",
        background="aqua", foreground="black"
    )
    text_scroll_bar = tkinter.Scrollbar(self.expand_ui)
    text = tkinter.Text(
        self.expand_ui, font=("Arial", 12), height=19,
        yscrollcommand=text_scroll_bar.set
    )
    text_scroll_bar.config(command=text.yview)
    error_var = tkinter.StringVar()
    lab_error = tkinter.Label(
        self.expand_ui, textvariable=error_var,
        wraplength=280, font=("Arial", 10), foreground="red"
    )
    self.expand_pack_class.init(text, error_var)

    lab_title.pack()
    text_scroll_bar.pack(side=tkinter.RIGHT, fill=tkinter.Y)
    text.pack(fill=tkinter.X, padx=10)
    lab_error.pack()

def intro_UI(self):
    self.expand_ui.pack(fill=tkinter.X)

def exit_UI(self):
    self.expand_ui.pack_forget()
