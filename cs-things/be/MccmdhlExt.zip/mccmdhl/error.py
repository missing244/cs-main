# Error definitions for Minecraft Command Tokenizer
import enum

__all__ = ["ErrorType", "Error"]

class ErrorType(enum.Enum):
    EXP_TERMINATING_CHAR = "缺少终结字符；请尝试加上空格"
    EXP_WORD = "缺少单词"
    EXP_ID = "缺少命名空间ID"
    EXP_MESSAGE = "缺少一条消息"
    EXP_CHAR = "缺少字符 {char!r}"
    EXP_INTEGER = "缺少整数"
    EXP_NUMBER = "缺少数字"
    EXP_INT_RANGE = "缺少整数范围"
    EXP_BOOL = "缺少布尔值"
    EXP_BOOL_OR_OPTION = "缺少布尔值，或 {options}"
    EXP_POS = "缺少坐标"
    EXP_JSON = "缺少JSON表达式"
    EXP_COMMAND = "缺少命令"
    EXP_BS_DV = "缺少方块状态或数据值"
    EXP_BS_VALUE = "缺少布尔值、整数或字符串"
    EXP_EXECUTE_SUBCMD = "缺少execute子命令"
    EXP_FUNCTION_PATH = "缺少函数路径"
    EXP_SCB_OP = "缺少计分运算符 +=, -=, *=, /=, %=, =, >, <, ><"
    UNCLOSED_STRING = "未闭合的字符串"
    UNCLOSED_BRACE = "未闭合的 '{{'"
    UNCLOSED_BRACKET = "未闭合的 '['"
    TRAILING_COMMA = "尾逗号是不允许的"
    NUMBER_OUT_OF_RANGE = "数字不在范围内：{min}~{max}"
    INT_OVERFLOW = "整数溢出"
    INCOMPLETE_FLOAT = "不完整的小数"
    IMPOSSIBLE_RANGE = "整数范围左边界大于右边界"
    IMPOSSIBLE_RANDOM = "随即范围左边界大于右边界"
    IMPOSSIBLE_TEST = "分数检测范围左边界大于右边界"
    IMPOSSIBLE_SPREAD = "最大范围必须大于分散间距"
    NUMLIKE_WORD = "数字作字符串时必须使用双引号"
    NUMLIKE_ID = "命名空间ID不能是数字"
    ILLEGAL_CHAR_IN_ID = "命名空间ID只能包含 a-z, 0-9, _, -, . 和 :"
    ILLEGAL_CHAR_IN_AXES = "execute align 的参数只能包含字符 'x', 'y' 和 'z'"
    REPEAT_CHAR_IN_AXES = "重复的字符'x', 'y' 或 'z'"
    MULTIPLE_COLONS_IN_ID = "命名空间ID只能包含1个冒号"
    UNKNOWN_COMMAND = "未知的命令：{command!r}"
    TOO_MANY_ARGS = "多余的命令参数"
    TOO_MUCH_JSON = "JSON后多余的字符"
    INVALID_OPTION = "无效的选择：{option!r}; 必须为：{correct}"
    INVALID_HASITEM_ARG = "无效的hasitem参数：{arg!r}"
    HASITEM_MISSING_ITEM = 'hasitem缺少必要的 "item" 参数'
    INVALID_SELECTOR_TYPE = "无效的选择器类型：{var!r}"
    INVALID_SELECTOR_ARG = "无效的选择器参数：{arg!r}"
    INVALID_GAMEMODE_ID = "无效的游戏模式ID"
    LOCAL_POS_FOR_SELECTOR = "局部坐标不能被用于选择器参数'x', 'y' 和 'z'"
    LOCAL_POS_WITH_RELATIVE = "局部坐标和相对坐标不能混用"
    WRONG_EXECUTE_END = "execute必须以 'run', 'if' 或 'unless' 子命令结束"

class Error(Exception):
    def __init__(self, error_type: ErrorType, **kwargs) -> None:
        super().__init__()
        self.type = error_type
        self.error_kwargs = kwargs
    
    def __str__(self) -> str:
        return self.type.value.format(**self.error_kwargs)
