# Editor of Minecraft Command Highlighter for Command Simulator

import tkinter
import tkinter.messagebox
import tkinter.filedialog
from idlelib.calltip_w import CalltipWindow
# IDLE has also implement the calltip feature, which is useful to us for
# showing the errors
from mccmdhl import MCCommandHighlighter

DEFAULT_WRAP = tkinter.NONE

class FileError(Exception): pass

def read_file(path):
    try:
        with open(path, "r", encoding="utf-8") as file:
            return file.read()
    except Exception as err:
        raise FileError

def write_file(path, content):
    try:
        with open(path, "w", encoding="utf-8") as file:
            return file.write(content)
    except:
        raise FileError

class EditorFile:
    # One file
    MAX_ERRMSG_LEN = 120
    MAX_ERRMSG_COL = 34

    def __init__(self, master_widget, platform):
        # master_widget: tkinter.Widget; the widget to put this editor
        # platform: str; UI settings on mobile devices is different
        self.master = master_widget
        self._IS_MOBILE = platform != "windows"
        self.file_path = None # File path (if exists)
        self.file_saved = False # Whether file is saved
        # Create widgets
        text_scroll_bar_y = tkinter.Scrollbar(self.master)
        text_scroll_bar_x = tkinter.Scrollbar(
            self.master, orient=tkinter.HORIZONTAL
        )
        self.text = tkinter.Text(
            self.master, font=("Arial", 11), height=21,
            width=28 if self._IS_MOBILE else 33,
            undo=True, wrap=DEFAULT_WRAP,
            yscrollcommand=text_scroll_bar_y.set,
            xscrollcommand=text_scroll_bar_x.set
        )
        text_scroll_bar_y.config(command=self.text.yview)
        text_scroll_bar_x.config(command=self.text.xview)
        # Grid widgets
        self.text.grid(
            row=0, column=0, columnspan=2, sticky=tkinter.W, padx=(5, 0)
        )
        text_scroll_bar_y.grid(row=0, column=2, sticky=tkinter.N+tkinter.S)
        text_scroll_bar_x.grid(
            row=1, column=0, columnspan=2, sticky=tkinter.W+tkinter.E
        )
        # end widgets
        self.highlighter = MCCommandHighlighter(self.text, self._show_errortip)
        self.calltip_win = CalltipWindow(self.text)
        # We need to know whether a file is changed, so we tweak insert
        # and delete a little bit
        def _on_modify(func):
            def _wrapped(*args, **kw):
                self.file_saved = False
                func(*args, **kw)
            return _wrapped
        self.highlighter.text_insert = _on_modify(self.highlighter.text_insert)
        self.highlighter.text_delete = _on_modify(self.highlighter.text_delete)
        self.highlighter.text_redir.register(
            "insert", self.highlighter.text_insert
        )
        self.highlighter.text_redir.register(
            "delete", self.highlighter.text_delete
        )
    
    @classmethod
    def from_file(cls, file_path, master_widget, platform):
        # Open a file
        inst = cls(master_widget, platform)
        inst.text.insert("insert", read_file(file_path))
        inst.file_saved = True
        inst.file_path = file_path
        return inst
    
    def _show_errortip(self, error_token):
        # Callback from `CalltipWindow`, update the error tip
        if self._IS_MOBILE or error_token is None:
            # 1. Force update calltip on mobile devices, since the calltip
            # may be hidden below the main window (This won't happen easily
            # on PC)
            # 2. On PCs, only hide tip when message is empty
            self.calltip_win.hidetip()
        # If message is empty, return
        if error_token is None:
            return
        # Handle message
        error_msg = self.highlighter.errmsg_from_token(error_token)
        ## Strip if too long
        if len(error_msg) > self.MAX_ERRMSG_LEN:
            error_msg = error_msg[:self.MAX_ERRMSG_LEN - 3] + "..."
        ## Add \n when message is too long
        lines = []
        current_length = 0
        current_line = ""
        for char in error_msg:
            current_length += 1 if char.isascii() else 2
            current_line += char
            if current_length > self.MAX_ERRMSG_COL:
                lines.append(current_line)
                current_length = 0
                current_line = ""
        if current_line:
            lines.append(current_line)
        error_msg = "\n".join(lines)
        # Show tip
        lineno = self.highlighter.lineno_from_index(error_token.pos_begin)
        self.calltip_win.showtip(
            error_msg, "%d.0" % lineno, "%d.end" % lineno
        )
        self.calltip_win.label.config(text=error_msg)
        # Any update of Text means that file is modified
        self.file_saved = False
    def _get_content(self):
        return self.text.get("1.0", "end")

    def edit_undo(self):
        self.text.edit_undo()
    def edit_redo(self):
        self.text.edit_redo()
    
    def _get_copy_pos(self):
        if not self.text.get("sel.first", "sel.last"):
            # no selection -> select the whole line
            lineno = self.highlighter.lineno_from_index(
                self.text.index("insert")
            )
            return "%d.0" % lineno, "%d.end" % lineno
        return "sel.first", "sel.last"
    def edit_copy(self):
        self.text.clipboard_clear()
        self.text.clipboard_append(self.text.get(*self._get_copy_pos()))
    def edit_paste(self):
        try:
            content = self.text.selection_get(selection="CLIPBOARD")
        except tkinter.TclError:
            return
        # Insert the text on clipboard
        self.highlighter.text_insert("insert", content)
        # Also remove the selected text. Since we override the default
        # delete command (See main.pack_class.on_function_pressed),
        # this must be handled by ourselves
        try:
            self.highlighter.orig_del("sel.first", "sel.last")
        except tkinter.TclError:
            pass
    def edit_cut(self):
        pos = self._get_copy_pos()
        self.edit_copy()
        self.highlighter.text_delete(*pos)
    
    def file_close(self):
        # Close this file; return whether succeeded
        if self.file_saved:
            return True
        response = tkinter.messagebox.askyesnocancel("关闭文件", "是否要保存文件?")
        if response is True: # close if saved successfully
            self.file_save()
            return self.file_saved
        elif response is None:
            return False
        elif response is False:
            return True
    def file_save(self):
        # Save this file
        if self.file_path is None:
            # No path given -> Save as a new one
            self.file_save_as()
            return
        write_file(self.file_path, self._get_content())
        self.file_saved = True
    def file_save_as(self):
        # Save this file to another path
        file_path = tkinter.filedialog.asksaveasfilename(
            defaultextension=".mcfunction",
            filetypes=(("MC行为包函数", ".mcfunction"),)
        )
        if file_path:
            write_file(file_path, self._get_content())
            self.file_path = file_path
            self.file_saved = True
